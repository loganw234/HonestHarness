# The study's ledger (HonestHarness: how muse-softfloat ran the methods)

This is the study's record: of its plan while it is drafted and verified, of
the study while it runs, and after it. The plan of record will be
`Rounds/Muse-Softfloat-Study/PLAN.md` in HonestHarness, on the branch
`study-muse`. The study begins only at Logan's approval and go. At its end
the ledger is archived with its timestamps beside the study's report, in
HonestHarness. **Everything here will be published.** No file holds a secret
or any personal data.

Your dispatch message gives the ledger's absolute path, as
`<repos>/honestharness-muse-ledger/`.

**No absolute paths, here or in any commit.** A path names the owner's
machine. Name every place relative to `<repos>` or `<scratch>`, which your
dispatch message defines. The study's sources sit under `<muse>`, which is
`<repos>/Muse-Softfloat`.

**No environment value, ever.** Never print, log, copy or quote any
environment variable's value, nor any part of one. This study makes no API
calls.

## The rules

**One file per author, append only.** Yours is named in your brief: `lead.md`,
`P1.md`, `verifier-P1.md`, and so on.
- Read every file here, and write only to your own.
- Never edit an entry. Correct one by appending a new entry that says which
  entry it corrects.

**Stamps come from the clock, never from memory.** Write every heading with
`date`:

    printf '\n## %s - <headline>\n\nMeasured: ...\nBelieved: ...\nFor: ...\n' "$(date '+%Y-%m-%d %H:%M:%S %z')" >> <your-file>.md

**Values come from the command that measured them**: SHAs, counts, rows,
line numbers. Never type one. Every figure you report names the command or
script that produced it and the commit or file it read.

**Read the whole directory at three moments.** They are the floor, whatever
else brings news:
1. before you start;
2. before you design anything that touches a file your brief calls shared
   or forbidden;
3. before you write your report.

**Write an entry when it would change another agent's work, or the lead's.**
That means:
- facts about the sources or the environment;
- a brief that turned out wrong, the moment you find it;
- a finding that bears on another parcel's question.

Mark which claims you **measured** and which you only **believe**.

**Escalation.** Write the question in your own file first, then message the
lead and wait for its answer. If your runtime cannot message, stop, and make
the question your report. Never hold a problem back for your final report.

**The lead's messages.** Every message the lead sends you is in `lead.md`
first, and its decisions are there before they reach you.

## The sources are read-only

- **Nothing under `<muse>` is written, moved or deleted**, and nothing is
  created there.
- **Its two git repositories** (`<muse>/muse-softfloat`,
  `<muse>/muse-softfloat-toy`) are read at commits only:
  - with `git show`, `git log`, `git ls-tree`, `git cat-file` or
    `git archive`, each with `GIT_OPTIONAL_LOCKS=0`;
  - never with `git status`, checkout, fetch, worktree, or anything that
    writes. Another session may be working there.
- **Its other files** (`ledger/`, `scratch/`, the kit, the case report) are
  read as files.
- **Sibling repositories** (ParcelRound, HonestFramework and the others) are
  read at commits in the same way. Never anything under
  `<repos>/cft-worktrees/`, and never any `Data/runs/`.

## The fence

Until the lead's draft report is verified and the lead lifts the fence in
`lead.md`, no agent opens, lists or searches:
- `audit-bundle/` or `audit-bundle-v2/` in the library repository, at any
  commit;
- any branch, file or bundle that holds the Claude audit reports.

After the fence is lifted, only the lead reads them, for the comparison.

**Searches name their directories.** Never run `find` or `grep -r` from
`<muse>` or from the library repository's root, because both trees hold the
fenced folders.

**A recursive listing or search of the library repository excludes the
fenced folders by pathspec:**

    git ls-tree -r --name-only <sha> -- . ':!audit-bundle' ':!audit-bundle-v2'
    git grep <pattern> <sha> -- . ':!audit-bundle' ':!audit-bundle-v2'

Never read at all:
- the IEEE 754 text (`<muse>/754-2019.pdf`);
- the media files;
- the Muse session transcripts, which are outside the study's scope;
- the lead's folder, `<repos>/honestharness-muse-lead/`.

## Verifiers and planted faults

**Verifiers** read only `lead.md` and this README until they have formed their
own view of the work. After that, they read the parcel's file to check its
claims.

**A verifier's first entry is its provenance.** It quotes its copy's HEAD and
one line that only the copy holds, before any check counts.

**Planted faults.** A verifier may be given a copy of a parcel's work that
holds faults the lead planted. The key's hash goes in `lead.md` before
dispatch. Keys, and any description of their plants, stay out of this ledger
until the study's last planted-copy verifier has reported.

## Your own work

**Your scratch directory** is named in your brief. Work only there and in your
worktree.

**Your findings go in your ledger file first.** Your report comes back as your
final message, and the lead files it verbatim in `reports/`. This harness
refuses a subagent's report file.

**If a pause is announced**, write an entry saying exactly where you are
before you stop.

**Before you report**, stop every background process of your own. Say in
your report that you did.

## Entry format

    ## <date time zone> - <one-line headline>

    Measured: ...
    Believed: ...
    For: <who this is likely to matter to, or "anyone">
