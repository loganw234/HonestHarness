# verifier-PL2's report, its one pass (filed by the lead)

This is verifier-PL2's final message, copied by the lead from the agent's
result. It is verbatim, except that the notification's `&lt;` and `&gt;`
entities are written as `<` and `>`.

---

**verifier-PL2: plan at 0080bef, draft 3 delta. Verdict: NOT READY.**

The change answers pass 2's seven findings and no changed line states a wrong fact. One restate needs a fix before the plan goes to Logan, and the audits-row fix also closes part of pass 2 item 4, which was only partly taken.

**Findings** (plan line numbers are in `<scratch>/verifier-PL2/plan_d3.md`)

1. **RESTATE, line 138 (audits row).** "Six of the audit agents have usage rows, all on Muse models." This is true of the six `auditor-*` agents in `usage.jsonl` at b78af18. But the row also lists `audit-full/`, whose eight auditors (`<muse>/ledger/lead.md` line 879) have no usage row I could match. The seal audit's provenance is also unstated, and pass 2 item 4 asked for it. Fix: "Six `auditor-*` agents have usage rows, all on Muse models. The eight full-audit auditors and `auditor-adherence-seal` have none. The seal's grade is in `<muse>/ledger/auditor-adherence-seal.md` line 3 and RECORD.md line 1251; say who ran it before its contents are used."
2. **NOTE, lines 229-231 (P1 item 4).** "The kit names the classes a and b" is true, but the two cites give only the labels and counts. The definitions are in `<muse>/softfloat-bootstrap-kit/ROLES.md` line 100 and `GLOSSARY.md` lines 27-28. Cite those, and say that a note is a third class and is not counted.
3. **NOTE, fence (line 138).** RECORD.md lines 1252-1253 say the seal report is "frozen into audit-bundle v2", which is fenced. The plan lists `<muse>/scratch/audit-adherence-seal/` as a source. The lead should confirm who ran the seal audit, and that the folder is outside the fence, before any agent reads it.
4. **NOTE, P1 item 5 (lines 232-237).** Five plant rows named `verifier-psbench` (key prefix c7e98cc5, all caught) appear to come from the first bench run, which `lead.md` line 876 says was superseded. Tie-by-key separates them, but the plan does not name them.

**Checked and right**
- Pass 2 item 1: the five `verifier-psbench2` rows in the library's `plants.jsonl` at b78af18 all carry key prefix 0305f97a and are all caught. `lead.md` line 876 gives attempt A as `verifier-psbench2` (void) and attempt B as `verifier-psbench2b`. Lines 232-237 are right.
- Pass 2 item 2: `<repos>/honestharness-muse-ledger/lead.md` line 7 reads "alot of the prior samples came from". Line 52 is an unquoted paraphrase.
- Pass 2 item 3: cached tokens sum to 1,379,156,504 over 128 rows. No row has cached above input. The input plus output total is 1,418,065,198. No source at b78af18 or in the kit says whether cached is inside input. Lines 154-156 are right.
- Toy row (line 136): 44 `dispatched`, 44 `verdict` (220 plants, all caught), 2 `lead_trim`, from `084f98b`. Right.
- "Not recorded" rule (line 65): seven verifiers have neither a usage nor a passes row, holding 35 plant rows. Right.

**What I ran** (all with `GIT_OPTIONAL_LOCKS=0`; scripts with `python -I`; output saved under `<scratch>/verifier-PL2/`)
- `git rev-parse` of 0080bef, b78af18 and 084f98b. `git diff 3345fbd 0080bef -- Rounds/Muse-Softfloat-Study/PLAN.md`, and `git show` of the plan at 0080bef.
- `git show` of b78af18's `docs/metrics/plants.jsonl`, `usage.jsonl`, `passes.jsonl` and `docs/RECORD.md`, and 084f98b's `docs/metrics/plants.jsonl`. Counting and comparison scripts over them.
- `sed -n` on `<muse>/ledger/lead.md` 868-884, RECORD.md 1249-1262, and kit `METRICS.md` 26-34. `python -I` over the kit's `tools/round_metrics.py` docstring. `grep` over kit `METRICS.md`, `ROLES.md`, `GLOSSARY.md`, `WORKFLOW.md`, `BOARD.md`, `HARNESS.md`, and `ls` of the kit's top level, `method/` and `reference/`.
- `git grep -n -i cached b78af18 -- docs tools ':!docs/metrics'`, and `git cat-file -t 751d1d6`.

**Fence disclosure.** I ran a `grep` for "verdict" and "ADHERENT" over `<muse>/ledger/auditor-adherence-seal.md` before I had confirmed its author. I also listed the kit's `reference/` folder, which holds `QRO-Crate.bundle`, and did not open it. I opened nothing else of the fenced kind, and nothing under `audit-bundle/` or `audit-bundle-v2/`.

**Provenance.** The ledger's first entry was written after my first checks had begun, and it says so. The provenance line is `0080bef5e45f74ee9aad32573020af5d53b00438`, quoting "- **Draft 3** takes all seven, each checked first by command. verifier-PL's". The ledger is `<repos>/honestharness-muse-ledger/verifier-PL2.md`. Re-reading the ledger directory before reporting showed no new entries.

**Background processes.** I started none, so none needed stopping.
