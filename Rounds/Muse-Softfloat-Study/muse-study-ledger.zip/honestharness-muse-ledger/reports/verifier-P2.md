# verifier-P2's report, pass 1 (filed by the lead; held until the reveal)

verbatim from the agent's final message, except that the notification's
`&lt;` and `&gt;` entities are written as `<` and `>`.

---

NOT READY

verifier-P2, pass 1 of 2. The full ledger is at `<repos>/honestharness-muse-ledger/verifier-P2.md`: a provenance entry, a re-run entry, a findings entry, and a correction. The findings are below. Each names its evidence and the fix the analysis needs.

**Provenance.** The copy's HEAD is `f4d3b66a838ff3d5e29b09bba1d76edebc90f5c1`, with parent `5197b2ab64acd01fa99ada7b75d2b73e34b16472`. The quoted line is the commit subject, "P2: transfer, escapes, the lead's errors, and the case report against the record".

**Re-run.** The parcel scripts reproduce the committed `data/` tables with no diff. The exception is `search_record.py`. It fails on this console's cp1252 encoding after writing its CSV, and its default `--max 6` truncates `first_hits`. With `-X utf8` and `--max 100`, it reproduces the committed CSV exactly. I restored the copy's file, and `git diff --stat` in the copy is empty. The scripts run from the parcel directory, because their paths are relative to it.

**Sent back (wrong answers).**
- **S1, clause marks (ANALYSIS.md Task 1).** It says "done as written 86". `data/clauses.csv` has DONE 76, by the script and by my recount. The rows sum to 181, not 171. It should say 76.
- **S2, escape table, minor row (Task 2).** It says "not raised 15". `data/escapes.csv` has 16. The row sums to 21, not 22. The "all" row's 32 is right.
- **S3, case-report counts (Task 4).** It says holds 46 and partly 11. `data/case_report_claims.csv` has 47 and 10. The gap is CR36 (S4).
- **S4, CR36's verdict.** The claim is "every brief carried a memory ceiling". 18 of 101 briefs contain the phrase, by my `ls` and `grep -l` over `<muse>/ledger/briefs`. The verdict "holds" is false. It should be partly, as the analysis's text says. Corrected, the counts become 46 and 11, which matches the analysis.
- **S5, M1 citation (Task 2).** It cites `scratch/verifier-readme/report.md:81`. The file has 75 lines. The sentence and its "Agree" mark are at line 18.
- **S6, lead-caught errors (Task 3).** It lists "E01, E08, E14, E17, E18, E20". In `data/lead_errors.csv`, E01 was caught by verifier-phase0. The lead caught E02, E06 and E07 as well. The list should be E02, E06, E07, E08, E14, E17, E18 and E20.
- **S7, adherence auditors (Limits).** It says they "never opened `lead.md`". `scratch/audit-adherence-2/report.md` lines 9 and 25 say the first one read the headings and sampled bodies. The final and seal audits (lines 12 and 11) say they never opened it. The limit should say that.
- **S8, C130 marking (`data/clauses.csv`, not quoted in the analysis).** C130 is marked DONE. The seal audit, `scratch/audit-adherence-seal/report.md` lines 158 to 162, records the rule as NOT met, with no `ledger/board.lock`. The mark should not be DONE. This would change DONE from 76 to 75.

**Restated (sentences stronger than their evidence).**
- **R1, rate comparison (Task 3).** "About twice the rate ... the clearest sign of the weaker model". The analysis gives no denominator. Its own list for this round has five items against round 6's nine. The harness, models and rounds differ. It should state the counts only.
- **R2, quotation (Task 2, M1).** "check every claim in a document" is not the kit's wording. `ROLES.md` line 91 reads "check every claim in a comment, a document or a commit message".
- **R3, gate timing (CR75).** It says "standard 55 to 76 s" and "both ends appear in the record". No 55 s appears in `lead.md`. The record shows 54s (`lead.md` line 127). The 76 s figure is at `scratch/audit-full/REPORT.md` line 16, not lines 17 to 20. The verdict should be partly.

**Notes (verdicts stand, or the citation needs a fix).**
- **N1.** CR62 should cite `lead.md` line 846 for "repo cut silent".
- **N2.** CR09's reason names one of the three wave-0 wonder verifier-like rows. All three are wave 0.
- **N3.** The verifier-w5attr and verifier-w5aug citations need their folder names. The lines exist and match.
- **N4.** CR72's 1,400 RECORD lines is at `a49991f`. At `b78af18` it is 1,418.
- **N5.** `search_record.py` needs `--max` and `-X utf8` to reproduce.

**Confirmed.** These match their cited sources, read by me at the commits or files named:
- `tools/run.sh` at `a49991f` has no TestFloat or Berkeley line.
- `board/read_until.py` line 37 sets the 60-second window.
- ParcelRound `METHOD.md` line 228 and `CASE-STUDY-6.md` lines 254 to 276 at `f42242e` match, including the "nine".
- Several `KICKOFF`, `RECORD` and `lead.md` lines match the analysis.
- A2 section 1 supports the "about 30 of 44" figure.
- The usage recount gives 1,418,065,198 tokens. The metrics recount gives 190 plants, 182 caught, 44/45 at wave 6, and 20/20 post-seal.
- All 216 commits at `a49991f` carry a Co-Authored-By line.
- The method copies differ in four of six files, at the lines the analysis gives.
- The lead-error brief split is 11, 4, 1, 5 and 1, and the ancestry for rows 4 to 7 holds.

**Not checked.** I read all 79 claim reasons and all 171 clause rows as printed, but re-checked only about twenty claims and ten clauses against sources. I did not check the COVERAGE count of 228, the RECORD erratum's "8 of 15", or the escape verdict texts beyond M1, M2 and M4. The RECORD erratum is P1's claim.

**Fence.** I did not open `audit-bundle/` or `audit-bundle-v2/`. `case_report_checks.py` lists the library root's names, including the two fenced folder names, then recurses only into the other entries. I did not run any command over the fenced folders' contents.

**Background processes.** I started none, and none are running from me.

**Commands run.**
- `git rev-parse HEAD` and `git log` in the copy.
- Each P2 script with `python -I`: `method_copies.py`, `extract_candidates.py`, `build_clauses.py`, `harness_table.py`, `parse_full_audit.py`, `search_record.py` (run twice), `build_escapes.py`, `build_lead_errors.py`, `case_report_checks.py`, `build_case_report.py`.
- `git diff --stat` in the copy.
- Python recounts of the clause, harness, escape, lead-error and claim CSVs.
- A `git show` and grep of `tools/run.sh` at `a49991f`.
- Line prints of the cited files, with the `git show` commands for the library, ParcelRound and kit files.
- A per-commit Co-Authored-By check of `a49991f`.
- Recounts of `docs/metrics` at `a49991f`.
- `ls` and `grep -l` over the briefs directory.

---

## Pass 2 (scoped to P2's fix `31d80c2`; filed verbatim by the lead, entities written as `<` and `>`)

NOT READY

Pass 2 of 2, scoped to P2's fix diff from 64325774 to 31d80c2. The full entry is in `<repos>/honestharness-muse-ledger/verifier-P2.md` under "pass 2".

**1. The answers.** Each of the lead's P2 items is answered rightly:
- **E-list:** E02, E06, E07, E08, E14, E17, E18 and E20 are lead-caught, and E01 is verifier-phase0.
- **Adherence auditors:** the limit now says the first audit read `lead.md` headings and sampled bodies, and the final and seal audits did not open it.
- **C130:** now UNKNOWN. The basis, that a lock file is removed on release, is a defensible reason.
- **ROLES.md line 91:** the quotation matches the kit exactly.
- **CR75:** partly. No "55 s" appears in the record.
- **N1 to N5:** the citations and folder names are fixed, and `search_record.py` defaults to `--max 100` with UTF-8 output.

R1 ("twice the rate") is absent from the committed analysis, which fits the coordinator's note that it and S1 to S5 were planted in my copy.

**2. The changed lines.** I exported 31d80c2 to my scratch and re-ran the changed scripts. The outputs match the committed data:
- **Clauses:** DONE 75, UNKNOWN 49, identical to `data/clauses.csv`.
- **Case claims:** holds 45, partly 12, identical to `data/case_report_claims.csv`.
- **Escapes:** identical to `data/escapes.csv`.
- **Search, no flags:** exit 0, and 44 of 44 parsed rows match. The bytes differ only in line endings: the script writes CRLF and the committed file has LF. So "checked by cmp" holds only after normalising line endings on this checkout. That is a limit, not a figure error.

**The one restate.** Line 47 of `ANALYSIS.md`, in the C130 paragraph, says the seal audit found "no parcel or verifier ledger citing" the lock. The audit at `scratch/audit-adherence-seal/report.md` lines 158 to 161 checked only two ledgers, `parcel-w6augint.md` and `verifier-w6augint.md`. The sentence should name those two. Once that is fixed, I found no further error in the delta.

No background processes were started. P2's worktree was not touched. The re-runs used only my scratch export.
