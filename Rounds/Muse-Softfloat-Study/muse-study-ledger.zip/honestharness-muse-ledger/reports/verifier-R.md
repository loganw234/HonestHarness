# verifier-R's reports (filed by the lead)

## Pass 1 (report draft 1, `35873c2`): verbatim from the agent's final message, entities written as `<` and `>`

NOT READY (pass 1 of 2). I found no wrong figure. Eight claims are stated more strongly than their sources, and nine notes need a fix or a citation. My findings are in `<repos>/honestharness-muse-ledger/verifier-R.md`.

**Provenance:** report commit 35873c2486bf1349ee06b29f92b678fb6122ba96, first line "# How muse-softfloat ran the methods (HonestHarness study, report)". The report has 309 lines.

**Restates (sentence stronger than its source)**

1. **Q4 headline, line 35:** "47 errors are the lead's or were caught against it." The owner column in `parcels/P2/data/lead_errors.csv` gives 45 lead rows. Two rows belong to others: a parcel's document and a study agent's figure. Should say "45 of the 47 are the lead's."
2. **Q3, line 32:** "33 had not been raised." The escapes table gives 32 not raised and 1 examined and passed. Line 185 is right; line 32 is not.
3. **Q3, line 33:** C3 glossed as "a claim about what the gate executes that it no longer executes." P2 defines C3 as "declared configuration instead of executed work." "No longer" is not in P2.
4. **Q3 limits omitted, lines 32-34 and 185-195:** P2 states that a no-hit search only shows the terms did not match. 16 of the 33 escapes had no hit at all. The 24 uncaught slips rest partly on the adherence auditors' accounts, and the final and seal audits never opened `lead.md`. None of this is stated.
5. **Q2 erratum, line 153:** "The record's erratum says 7 and 8." The erratum names 8 rows that were not revisions, and 7 is only implied. P1's split (8 revised, 7 not) runs the opposite way from that implication, and the report does not say so.
6. **Q6, lines 261-263:** "Hash-first keys and bit-identical workload proofs left grading little to argue about." P2 marks hash-first as partly held (70 of 190 rows), and the bit-identical claim as not re-run. The report's own Q5 cites the 70 of 190.
7. **Q6, lines 42 and 252-254:** misses were "mostly claims whose meaning was wrong." P1 classes plants by the artifact altered, not by value or meaning. Two misses were value-type faults (a recomputed "855 - correct" figure, and a generator edit left unseen). Should report misses by artifact class: 4 claims in docs, 2 test data, 2 metadata.
8. **Provenance line 13:** "every figure is in a parcel's analysis or read by the lead from the parcels' final commits." Not true of the hackathon end date (KICKOFF line 144), the no-defect-in-arithmetic claim (Muse full audit, which no parcel reads), or "The lead is Claude Opus 5.5" (no source). The seal date of v1.0.0 (2026-11-01) checks out.

**Notes**

1. Lines 27-28 are garbled. The correct statement: of 87 code plants, 86 are tied to Spark and 1 to an unrecorded model, and all 87 were caught.
2. Line 27: the 178 of 185 figure rests on 25 rows attributed from ledger lines. On usage rows alone it is 153 of 160 (0.956), which P1 states. Give both.
3. Line 172: "P1 judges" should be "P1 believes" (P1 §6.4 says "I believe").
4. Line 236: the newer ParcelRound commits are on case-study-7 and touch only a case study and a zip. They are not method commits.
5. Lines 113-114: the case report's observation 12 two-parcel claim is "unverifiable" in P2 (CR48). The report gives no such verdict.
6. Lines 142-143: the claim about the second metadata verifier is uncited. The source sits in a Muse scratch folder I did not read.
7. Line 260: "where P9 and P10 would have the most to catch" is conjecture with no source.
8. Lines 269-270: "all on record." The library's 39 keys are in the Muse lead's folder, and the toy's keys are unavailable.
9. Line 203: "Code defects ... were fixed before the seal" holds for four lead rows. E05 has no recorded fix, and E06 and E07 never reached the seal.

**Checked and held:** the Q1 clause counts (171; 75/35/6/6/49); the Q2 recall figures (187 of 195; 178 of 185; 9 of 10; per-class counts); the Q3 escape families (14/5/2/2/10); the Q5 claim verdicts (45/12/1/21), proposal marks (ABSENT 3, CASE-ONLY 1, PARTIAL 14) and toy counts (1/12/5); the verifier findings counts for P1 (4 wrong, 2 restates), P2 (3 wrong, 2 restates, 5 notes) and P3 (2 wrong, 9 restates); the grading (14 of 15); the round-1 replay (24 of 24; 7 of 16); the round-2 11 of 12. The three parcel trees at the report's final commits are identical to 35873c2.

**Not verified:** citations into the Muse scratch folders and the audit reports (for example "about 30 of 44 lead commits"), because my brief excludes them.

**What I ran:** `git archive` of the study folder at 35873c2 into scratch; `git show` of the report, the three analyses and the data; `python -I recount.py` over the export; `git diff --stat` of each parcel tree against 35873c2 (empty); `git show` of RECORD.md lines 1004-1012, KICKOFF line 144, the ParcelRound case studies at f42242e, HonestHarness R1's CASE-STUDY.md, and round 2's `lead.md` line 2762; reads of this ledger's reports and the Muse `ledger/lead.md` lines 856-880.

**Background processes:** I started none, and none are running.

---

## Pass 2 (report draft 2, `3aae2b2`): verbatim from the agent's final message, entities written as `<` and `>`

NOT READY on pass 2, on five small new faults. Every one of the 17 pass 1 items is answered, and no figure in draft 2 is wrong. The findings are in my ledger under the pass 2 entry (`verifier-R.md`, 11:05:26), with a correction appended for a miscounted headline.

**Pass 1 items**
- **All 8 restates answered rightly.** Q4 now reads 45 of 47 as the lead's. The Q3 count is corrected to 32 not raised plus 1 examined and passed, and the C3 gloss is fixed. The Q3 limits are stated. The erratum now names only the 8 rows, and P1's reversed split is given. The hash-first and bit-identical sentence is removed. The meaning-versus-value claim is replaced with the two value misses. The provenance line now cites each figure.
- **8 of 9 notes answered rightly.** Note 9 is only partly answered (see NEW 1).

**New faults in draft 2**
1. **Line 232:** "the four code defects in the lead's seam." "Seam" is in no source. P2 says correction rows 4 to 7 are the lead's code or tool faults in Phase 0. Row 7 is a smoke control, not a code defect.
2. **Lines 40, 43, 200, 223:** the full audit's file is called "the final audit." P2 uses "full audit" for `audit-full/REPORT.md` and "final adherence audit" for another file.
3. **Line 293:** "distrust a value it has recomputed itself" has no source. Row 56 says the verifier recomputed the slip and endorsed it.
4. **Line 298:** the claim that the wrong-tree attempt was exposed because its scripts were kept is true, but P1 §5 does not say it. The source is the Muse lead's ledger, line 876.
5. **Line 329:** "the allowlist P2 asks for" names no source.

**Checked by command and held**
- plants.jsonl rows 5, 56 and 170 at b78af18: each quote matches the note.
- KICKOFF l144, RECORD from l1004, P1 §3.1.
- The audit's "Verdict shape": "No defect found in the shipped math surface itself."
- P2 CR01 and CR02.
- `briefs/_common.md` l177 for the lead's model.
- The figures 25, 160, 153, 86 plus 1, and 45 of 47.
- No absolute paths or "@" in draft 2.

Each NEW item is a one-line fix and changes no figure. The lead should apply them by command. Logan's cap on verifier loops applies, so the lead should say that the last change was checked by the lead, not a verifier.

**Ran:** `git show` at 3aae2b2 and 35873c2 for the report; `git show b78af18` for `docs/metrics/plants.jsonl`, `docs/KICKOFF.md` and `docs/RECORD.md`; reads of `scratch/audit-full/REPORT.md` (the coordinator's allowed file), `briefs/_common.md` and P2's and P1's data files. Nothing was written outside my ledger and scratch.

**Background processes:** none started, none running.
