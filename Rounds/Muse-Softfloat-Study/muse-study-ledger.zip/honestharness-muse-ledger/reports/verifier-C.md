# verifier-C's reports (filed by the lead)

## Pass 1 (the comparison's draft 1 and the report's draft 4, `bc058e5`): verbatim from the agent's final message, entities written as `<` and `>`

NOT READY

Pass 1 of 2. Findings are in `<repos>/honestharness-muse-ledger/verifier-C.md`, under the entry headed "verifier-C pass 1: five wrong items, five restates and notes". Line numbers below are of `COMPARISON.md` at bc058e5 unless marked otherwise.

**Wrong**

- **W1, line 44 (study cell, Pin P5 row): "Q3: escape" is false.** P2 `data/escapes.csv` row M3 is `escape=no`, `own_verification=partly`. verifier-w5attr raised it and verifier-w5aug cleared it. Q3's 33 escapes exclude it. Should say it was raised, then cleared.
- **W2, line 47 (study cell, data.json stamp row): blank, but N17 is an escape.** escapes.csv N17 is `escape=yes`, family F1, one of Q3's 33. Should read "Q3: escape (F1)".
- **W3, line 47 (Claude C cell): blank, but C L11 has it.** C L11 says "site/data.json's base commit predates the counts it shows." Should read "C L11".
- **W4, line 89: "It happened on 2026-11-02."** The voided attempt is at Muse `ledger/lead.md` line 876, under the heading "2026-11-01" (line 874). The first 2026-11-02 heading is line 889. Should read 2026-11-01.
- **W5, line 116: "The Muse adherence and full audits never opened it. The one audit that did (A)..."** P2 ANALYSIS.md lines 100 to 101 say the first adherence audit read lead.md's 101 headings and sampled its bodies. Only the final and seal adherence audits say they never opened it. The full audit's report does not say either way.

**Restate**

- **R1, line 107: "It also missed the IAS15 parcel's unverified merge."** escapes.csv A03 is `own_verification=raised`, `escape=no`. The clause table has no row, and C085 is SKIPPED, as stated. But the report never mentions IAS15. Should say it was raised in the escape table, has no clause row, and is absent from the report.
- **R2, line 102: "the code held."** The comparison's own library-edges list (lines 67 to 72) gives wrong values for long decimal and hex inputs, double rounding beyond 20 digits, and a normalisation off-by-one. Claude A calls two of them real defects (M8, M7). Should say the arithmetic held on ordinary inputs.
- **R3, line 111: "An external audit found a High in the gate itself that the round's own verification and audits did not."** The Berkeley-gate High (A H2) was found by the Muse full audit (M1, major) and by the case report (observation 8). Only the anchoring High (B F-01, C H2) went unmatched. Should name which High.
- **R4, line 117: the three audits' agreement "suggests their findings are robust."** They share a model family and process, so agreement shows consistency, not verification. A M2 shows a stale binary, not a deleted vector.
- **R5, line 118: "ground truth of real defects."** The study did not verify them, and the comparison's own Limits say so. Should be "claimed defects."

**Notes**

- **N1, line 76:** add C L13 (the MP4 weight) to the media item.
- **N2, line 66:** B F-05 is general mutation testing and does not single out Tier 2. Cite C M9 alone or qualify.
- **N3, lines 54 and 64:** Muse N6 (symbol-scan SKIP-BY-NAME returns PASS) is the same shape as A L15 and C M1. Add it or narrow the sanitize item.
- **N4, line 45:** Muse M4 is an unrunnable bench budget, not an evidence path outside a gate. Loose match.
- **N5, lines 44 and 48:** the Muse cells "(disposition of the audit)" and "(the seal adherence audit's slips)" are not IDs. The matching items are case report lines 342 to 347 and escapes.csv A27.
- **N6, line 114:** "on Windows" is not in the full audit's report. Unverified.
- **N7, Q4's 42 (REPORT.md lines 50 and 239):** the figure is right (45 lead-owned by the owner column, less CJ17 to CJ19), but no P2 file records 42. Cite a source.
- **N8, REPORT.md lines 232 to 233:** the uncorrected "45" and "22 lead's own" still precede the correction block. Amend in place to 42, and 19 of the 22 corrections.
- **N9, Limits (home-path counts):** my counts are A 2 and B 5. The lead says B has 4. The pattern is unrecorded, so this may just be a different pattern.
- **N10, for the lead only:** Claude A M10 says corrections has 22 rows and the twiddledoc fix has no row. At b78af18 there are 24 rows and row 23 is that fix. A's figures are from a2241fc. The comparison does not repeat them.

**Checked and right:** the commit SHA and header line; the three audit hashes (prefix and suffix match `lead.md`) and the brief hash; the corrections 17 to 19 to plants 59, 58, 57 mapping (verified against `docs/metrics/` at b78af18); the 43 full-audit rows split 4/2/22/15; the 33 escapes (32 not raised, 1 examined-passed, 16 with no hit, F1 at 14); the lead-owned count of 45 and the two non-lead rows; all audit counts and volumes; and the quoted summary phrases.

**What I ran:** `git` (`rev-parse`, `show`, `diff`, `merge-base --is-ancestor`) with `GIT_OPTIONAL_LOCKS=0` on the study, the Muse repository and the library; `sha256sum` on the copies and the brief; `python -I` scripts `check_escapes.py`, `check_q3.py` and `check_lead_errors.py` in `<scratch>/verifier-C/`; `grep`, `sed` and `awk` over the three audit copies, `<muse>/ledger/lead.md` and `<muse>/CASE-REPORT-muse-softfloat.md`. I did not open the fenced folders, the keys, or the lead's folder, and I printed no environment values.

**Ledger issue to scrub:** my note N9 (line 67 of `verifier-C.md`) quotes a fragment of a home path from the audit copies. I wrote it in error. The ledger is append-only, so I appended a correction rather than editing it. The lead should remove that fragment before archiving.

**Background processes:** none started, so none to stop.

---

## Pass 2 (the comparison's draft 2 and the report's draft 5, `23b0267`): verbatim from the agent's final message, entities written as `<` and `>`

NOT READY

Pass 2 of 2, on `23b0267`. Findings are in `verifier-C.md`, under "verifier-C pass 2 (last)". Every pass 1 finding landed as the 13:02:05 entry says, and each changed line is true to its source. One restate remains, plus four notes for the lead.

**Restate**

- **R6, COMPARISON.md line 57: "On the protocol row, the Muse adherence audits came first."** A32 comes from the seal audit (freeze `751d1d6`, 2026-11-01), which is after the Claude audits (2026-10-31). Only A2 (2026-10-28) and the final audit (`bc807e6`, 2026-10-29) predate them. Should say the earliest Muse slips came first, and that A32 came after.

**Notes**

- **N11, line 55: "Two columns lean on the full audit there."** Vague. Name the columns or drop the sentence.
- **N12, protocol row: A06 is a key-hash slip, not a verifier-before-merge claim.** It sits under "On the record", which is accurate. Fit note only.
- **N13: the prefix "A" is used twice in the same table.** Muse adherence slips are A01 to A36; Claude audit A's IDs are "A H1", "A M2". A distinct prefix would remove the risk of confusion.
- **N14: two supported details were dropped from the comparison.** "Wave 1's merges came before their verdicts" and the IAS15 citation (`l303`) are gone. Both are true; the second is now in REPORT Q1. Restore them or say they moved.

**Checked and right**

- The Limits counts: 14 of A's 18 Medium, 11 of B's 14, 7 of C's 9, and every High. Recounted by script from the table and prose.
- The two new protocol-row citations, A H1 and B F-17 (a), and C L12, which carries the smoke timing and width items the Limits cite.
- The media row, with A L19, B F-09, C L13 and N22.
- The adherence audits' row: dates and commits match the freeze lines in each report's header.
- Q4 in REPORT draft 5: 19 = 11 + 4 + 4 and 22 = 11 + 4 + 7. The IAS15 lines in Q1 cite `d9718cf` and `l303`, as they should.
- The N10 note: at `a2241fc` the corrections file has 22 rows, and rows 17 to 19 match `b78af18`.
- The 24 slips with escape=yes in the adherence rows, which matches REPORT line 229.
- No absolute paths or home-directory strings in either new text.

**Not verified this pass**

- The home-path line counts in the Limits ("2 and 4 lines, 2 and 5 matches"). Checking them needs the pattern the rule now forbids. The match counts (2 in A, 5 in B) agree with pass 1; the line counts were not checked.

**Ledger**

- My pass 1 note N9, on line 67 of `verifier-C.md`, still contains a fragment of the home path. The ledger is append-only, so I did not edit it. Per the lead's plan, the archived copy must redact it.

**What I ran:** `git rev-parse`, `show` and `diff` at `bc058e5`, `23b0267`, `a2241fc` and `b78af18`, with `GIT_OPTIONAL_LOCKS=0`; `python -I` scripts `count_mapped.py` and the escape counts in `<scratch>/verifier-C/`; `sha256sum` on the audit copies and the brief (unchanged); reads of the three adherence audit headers in `<muse>/scratch/`; and reads of the Muse lead ledger and the library's corrections file. Fenced folders were not touched.

**Background processes:** none started, so none to stop.
