# Ledger: verifier-R (the muse-softfloat study)

## 2026-11-08 10:46:43 -0700 - provenance: the report at 35873c2, draft 1, pass 1

Measured: the report commit, as `git rev-parse` prints it, is 35873c2486bf1349ee06b29f92b678fb6122ba96. Its first line, by `git show <sha>:Rounds/Muse-Softfloat-Study/REPORT.md`, is "# How muse-softfloat ran the methods (HonestHarness study, report)". The file has 309 lines. No check had counted before this entry.
Believed: this is pass 1 of at most 2.
For: verifier-R; the lead

## 2026-11-08 10:53:41 -0700 - pass 1 findings on the report at 35873c2: NOT READY, eight restates and nine notes, no wrong figure

Measured: every table in REPORT.md's answers was recounted by `python -I recount.py <scratch>/Rounds/Muse-Softfloat-Study`, over the parcels' data/ at 35873c2, which is the study folder exported by `git archive` into scratch. Counts that agree with the report: Q1 171 clauses, 75/35/6/6/49; Q2 195 plants, 187 caught, 185 Spark rows with 178 caught, 10 unrecorded with 9 caught, code 87/87, claim in docs 60/56, test data 34/32, metadata 8/6; Q3 43 findings (raised 6, partly 4, examined-passed 1, not-raised 32), 33 escapes, families 14/5/2/2/10; adherence slips 36 (24 not raised); Q4 47 rows, 24 corrections; Q5 79 claims (45/12/1/21), 18 proposals (ABSENT 3, CASE-ONLY 1, PARTIAL 14), 9 labelled new, toy PRACTISED 1, PARTLY 12, SILENT 5; sent_back 15 with 8 revisions; the earlier-round figures HH R1 24/24 and 7/16 (HonestHarness main, Rounds/HonestHarness-R1/CASE-STUDY.md lines 222-228), HH R2 11/12 (round 2 lead.md line 2762), ParcelRound 5 and 6 (CASE-STUDY-5.md line 158, CASE-STUDY-6.md line 152 at f42242e). The three parcel trees at the report's final commits (83a1889, 06f1a45, 5c8f4f9) are identical to their trees at 35873c2 (git diff --stat, empty).

Believed: the report is NOT READY. I found no wrong figure. I found restates, all in Q3, Q4 and Q6 plus the report's own provenance line, and notes. Each finding names its report line (REPORT.md at 35873c2), its source, and the fix. Parcel analyses are cited by their section; the lead's ledger lines are cited as the lead wrote them.

For: the lead; Logan

Findings (pass 1 of at most 2; class by the brief's classes):

RESTATE 1, Q4 headline, REPORT.md line 35. The report says "47 errors are the lead's or were caught against it." Source: parcels/P2/data/lead_errors.csv, column owner. 45 rows are owned by the lead; row 22 is owned by a study agent ("a figure in a study, not a brief") and row 23 by a parcel ("parcel-w5twiddledoc's document, not a brief"). Those two were caught by a parcel and a verifier, not against the lead. P2 ANALYSIS.md line 111 says the same. Fix: "45 of the 47 rows are the lead's; 2 are another agent's."

RESTATE 2, Q3 headline, REPORT.md line 32. The report says "33 had not been raised by the round's own verification." Source: parcels/P2/data/escapes.csv, full-audit rows with escape=yes: own_verification is not-raised 32 and examined-passed 1. The report's own line 185 gives the split correctly. Fix: "32 were not raised and 1 was examined and passed."

RESTATE 3, Q3 family gloss, REPORT.md line 33. The report glosses C3 as "a claim about what the gate executes that it no longer executes (5)." Source: P2 escapes.csv failure_family and mechanism, and P2 ANALYSIS.md lines 86-88: C3 is "declared configuration instead of executed work." Nothing in P2 says the claim "no longer" holds. Fix: "a claim about executed work that rests on declared configuration (5)," as the report's own line 188 has it.

RESTATE 4, Q3 limits omitted, REPORT.md lines 32-34, 185-195. P2 ANALYSIS.md states: a no-hit search "shows only that my terms did not match" (line 100; line 174); 16 of the 33 escapes had no search hit at all (line 82, and escapes.csv search_hits = 0 for 16); the 24 "not raised" slips rely for many rows on the adherence auditors' own accounts, and the final and seal audits did not open lead.md (lines 100-103). The report states these counts without any of these limits. Fix: state the limit beside the escape counts.

RESTATE 5, Q2 erratum, REPORT.md line 153. The report says "The record's erratum says 7 and 8." The erratum at b78af18 (docs/RECORD.md from line 1004) names 8 early send-back rows that were not parcel revision rounds, and reads sent_back as true only on proven revisions; the 7 is implied, not stated. P1 ANALYSIS.md section 4.3 (lines 306-307) finds 8 rows with a revision and 7 without. That reverses the erratum's implied split (7 proven, 8 not). The report does not say so. Fix: state the erratum's wording and the direction of P1's split, and that the two disagree.

RESTATE 6, Q6, REPORT.md lines 261-263. "Hash-first keys and bit-identical workload proofs left grading little to argue about," under "Structure substituted for model strength where it was enforced." Source: P2 case_report_claims.csv, CR63 is "partly" (hash-first covers 70 of 190 rows; "never gamed" cannot be shown by absence), and CR04 is "holds, not re-run". The report's own Q5 (line 221) cites the 70 of 190. The study's own grading left 2 plants unclear (P1 ANALYSIS.md section 3.4, lines 264-268). Fix: state the case report's claims as partly held, or drop the sentence.

RESTATE 7, Q6 miss pattern, REPORT.md lines 42 and 252-254. The report says a smaller verifier "caught value faults (code, figures, citations) nearly always, and missed mostly claims whose meaning was wrong." P1 classes plants by the artifact altered (ANALYSIS.md section 2.1), not by value versus meaning; "figures" and "citations" are not plant classes. The misses include value-type faults: the sf2 plant 1 that the verifier recomputed as "855 - correct" (P1 section 3.4, line 267, L04), and w5alg1 plant 3, a generator edit with no sign of it (line 267, L06). Fix: report the misses by artifact class (4 claims in docs, 2 test data, 2 metadata) and say that a meaning-versus-value split is the lead's reading, not measured.

RESTATE 8, the report's provenance line, REPORT.md line 13. The report says "Every figure here is either in a parcel's analysis, with its script and source, or was read by the lead by command from the parcels' final commits." Figures outside that: "a hackathon that ran to 2026-11-04" (library docs/KICKOFF.md line 144 at b78af18, cited only in lead.md's first look); "sealed at v1.0.0 on 2026-11-01" (git log of 957fdae, 2026-11-01 17:49 -0700, which I confirmed, but no parcel cites it); "No defect was found in the shipped arithmetic" (REPORT.md line 195, from the Muse full audit's report, which no parcel reads; the lead's first look in lead.md gives the wording "shipped math surface"); "The lead is Claude Opus 5.5" (line 3, no source). Fix: cite each, or narrow line 13's sentence.

NOTE 1, Q2 garbled sentence, REPORT.md lines 27-28. "That includes every code plant tied to it: 86 of the round's 87, and the other 87th was caught too." The count is right (P1 ANALYSIS.md section 6.4, line 378: all 87 code plants caught; 86 on Spark rows and 1 on an unrecorded row), but the sentence is garbled. Fix: "86 of the 87 code plants are tied to Spark; the other, tied to an unrecorded model, was caught."

NOTE 2, Q2 basis, REPORT.md line 27. The 178 of 185 figure rests on 25 rows whose model comes from ledger lines, not usage rows (P1 data model_source: usage.jsonl 160, ledger line 25, none 10). On usage rows alone it is 153 of 160 (0.956), which P1 section 2.3 (line 228) states. The report omits both. Fix: give the 0.956 alongside, as P1 does.

NOTE 3, REPORT.md line 172. "P1 judges the Claude rounds' figures not distinguishable from Spark's." P1 section 6.4 says "I believe ...", and adds that the confounds mean the sample cannot show it. Fix: "P1 believes."

NOTE 4, REPORT.md line 236. "The only newer method commit is ParcelRound's case study 7." P3 section 2 (lines 117-126): the two newer ParcelRound commits (8b6d6d4, 894d125) touch only CASE-STUDY-7.md and an archive zip; they are not method commits. Fix: "the only newer ParcelRound commits are on case-study-7."

NOTE 5, REPORT.md lines 113-114. The report says the case report's observation 12 "describes the cost of skipping it: two parcels each invented the same override." P2 case_report_claims.csv, CR48 (observation 12): "unverifiable" (searched "MSF_LEDGER"). The report gives no such verdict. Fix: "P2 could not verify the two-parcel detail."

NOTE 6, REPORT.md lines 142-143. "The second counted rows against the list it expected and never read the field it was meant to check, as the case report's observation 2 says." No parcel analysis states this. The verifier's report is in a Muse scratch folder, which this verifier does not read. Fix: cite it, or drop it.

NOTE 7, REPORT.md line 260. "Those are the cases where the case report's P9 and P10 ... would have the most to catch." No source. P3 marks P9 PARTIAL and says nothing about P10's catching power. Fix: say it is a conjecture, or drop it.

NOTE 8, REPORT.md lines 269-270. "The keys, the copies' commits and the plants' classes are all on record (P1's data/)." The library's 39 keys sit in the Muse lead's folder, not in P1's data, and the toy's keys are unavailable (P1 section 2.4). Fix: say where the keys are and that the toy's are not available.

NOTE 9, REPORT.md line 203. "Code defects the lead introduced were fixed before the seal." Four of the lead's code or tool rows (CJ04 to CJ06 and E18) are fixed before the seal. E05 (a lead test row) has no recorded fix, and E06 and E07 (script rows) did not reach the seal. Fix: scope the sentence to the four.

Not checked by me: the parcel analyses cite Muse agents' scratch files (for example the adherence audits, "A2:32") and the full audit's report. My brief excludes those folders, so the citations into them (for example "about 30 of 44 lead commits") I could not verify. Their wording enters the report only through P2.

Verdict: NOT READY, on restates 1 to 8. No wrong figure was found.

## 2026-11-08 10:53:41 -0700 - what verifier-R ran for pass 1, and what it could not check

Measured: `git archive 35873c2 Rounds/Muse-Softfloat-Study` into scratch (GIT_OPTIONAL_LOCKS=0); `git show` of REPORT.md, the three ANALYSIS.md files and the data; `python -I recount.py` over that export (every table in the report, by the parcels' data); `git diff --stat` of each parcel's tree at its final commit against 35873c2 (empty for all three); `git show b78af18:docs/RECORD.md` lines 1004 to 1012, `git show b78af18:docs/KICKOFF.md` line 144 and the date of 957fdae; `git show` of ParcelRound CASE-STUDY-5 and -6 at f42242e and HonestHarness R1 CASE-STUDY.md on main; `git show` of the round 2 ledger lead.md line 2762; reads of this ledger's reports/ (verifier-P1, -P2, -P3 and grading-wave1) and of the Muse ledger lead.md lines 856 to 880 (read as a file). Every count above was produced by a command; none was typed from the report.
Believed: the parcels' tables and the grading agree with the report except as the findings say.
Not read: the audit-bundle folders; the Muse scratch folders (the adherence audits, the full audit report, the verifiers' reports); the key files; 754-2019.pdf; the lead's folder. So the report's citations into those folders are unverified by this verifier.
Background processes: none started by verifier-R; none running.
For: the lead; Logan

## 2026-11-08 11:05:26 -0700 - pass 2 on draft 2 (3aae2b2): NOT READY on five small new faults; all 17 pass 1 items answered, eight of them fully

Measured: draft 2 is `git show 3aae2b2:Rounds/Muse-Softfloat-Study/REPORT.md`, saved to scratch; `git diff 35873c2 3aae2b2 -- Rounds/Muse-Softfloat-Study/REPORT.md` gives the changes. Checks, by command:
- plants.jsonl at b78af18 (`git show b78af18:docs/metrics/plants.jsonl`, 195 records, row = record number): row 5 note "regen drift seen ... but filed benign"; row 56 note "verifier recomputation repeated the slip (822+27 read as 855) and endorsed it"; row 170 note "coverage counted appended agents by expected list (5+11+19) without checking per-row wave fields". Each quote in the report matches.
- KICKOFF.md l144 at b78af18: "the hackathon window (ends 2026-11-04)". Matches.
- RECORD.md from l1004 at b78af18: the erratum names 8 rows where the planted verdict was not a parcel revision round. Matches the new send-back text.
- P1 §3.1 (keys): 39 key files match the rows' key hashes. Matches.
- `<muse>/scratch/audit-full/REPORT.md`, "Verdict shape" (read; the coordinator named this file as readable): "No defect found in the shipped math surface itself". Matches the new Q3 sentence.
- P2 CR01 (849 = 783 + 66, at a49991f) holds; CR02 (tag v1.0.0 at 957fdae, 2026-11-01) holds. Both match the new setting bullets.
- `briefs/_common.md` l177: the lead's model is "taken from your own system prompt". Matches the new sentence that cites it.
- Abs-path and "@" scan of draft 2: none.
- Recount of the new figures: 25 ledger rows, 160 usage rows, 153 caught (0.956), 86 + 1 code plants, 45 of 47 lead-owned: all match pass 1's recount.

Believed: the pass 1 items are answered rightly, with three small exceptions below. The new text adds three small errors, each a wording or citation fault and no figure.

For: the lead; Logan

Pass 2 answers, item by item (pass 1 items as numbered in my pass 1 entry):

RESTATE 1 (Q4 45 of 47): answered rightly.
RESTATE 2 (Q3 33 escaped, 32 never raised, 1 examined): answered rightly. Note "never raised" is slightly stronger than P2's "not raised by the record" (see NEW 2).
RESTATE 3 (C3 wording): answered rightly.
RESTATE 4 (Q3 limits: no-hit search, auditors' accounts, final and seal audits never opened lead.md): answered rightly.
RESTATE 5 (erratum says 8; P1's split runs the other way): answered rightly. The text now says the erratum names none, and P1 finds the reverse split.
RESTATE 6 (hash-first and bit-identical grading): answered rightly. The sentence is gone; the 70 of 190 and the not-re-run status are given.
RESTATE 7 (meaning versus value): answered rightly for the miss pattern. The two values are supported by plants.jsonl rows 56 and 5. One new inference remains: see NEW 3.
RESTATE 8 (provenance line): answered rightly. The hackathon date is cited to KICKOFF l144, the seal to CR02, the no-defect claim to the audit's "Verdict shape", and the lead's model to briefs/_common.md l177.
NOTE 1 (garbled code-plant sentence): answered rightly.
NOTE 2 (25 ledger rows, 153 of 160): answered rightly.
NOTE 3 ("P1 believes"): answered rightly.
NOTE 4 (newer commits are on case-study-7, change no method text): answered rightly.
NOTE 5 (CR48 unverifiable): answered rightly.
NOTE 6 (second verifier's counting): answered rightly; the uncited sentence is replaced by row 170's note.
NOTE 7 (P9 and P10 would catch): answered rightly; "not tested here" is stated.
NOTE 8 (keys "on record"): answered rightly; the report now says where the keys sit and that the toy's were not found.
NOTE 9 (code defects fixed before the seal): PARTLY answered. The scope is now four rows, which is right, but the words "in the lead's seam" are not in any source (see NEW 1).

NEW 1 (Q4, line 232): "The four code defects in the lead's seam (correction rows 4 to 7)". P2 ANALYSIS.md Task 3 (lines 113 and 117-118) says rows 4 to 7 are "the lead's own code or tool ... in P0". "Seam" appears in no source. Row 7 is a smoke control, which P2 calls a tool, not a code defect. Fix: "The four code or tool faults in Phase 0 (correction rows 4 to 7)."

NEW 2 (Q3, lines 40, 43, 200, 223): the report calls the full-audit file "the final audit" (its 43 findings and its "no defect"). P2 uses "full audit" for `audit-full/REPORT.md` and "final adherence audit" for a different file (P2 lines 100-103). A reader can take "final" for the adherence audit. Fix: "the full audit" in all four places. The "no defect" sentence is otherwise right.

NEW 3 (Q6, line 293): "Together they suggest the weakest ground is where a verifier must judge prose against its sources, or distrust a value it has recomputed itself." The first half is supported by the three sources. "Distrust a value it has recomputed" is not in any source: plants.jsonl row 56 says the verifier recomputed the slip and endorsed it, which is the opposite of distrust. Fix: drop the second clause, or say that a recomputed value that is wrong went unseen.

NEW 4 (Q6, line 298): "The wrong-tree attempt was exposed because its scripts were kept. Its successor passed a provenance gate (P1 §5)." The first clause is true, but P1 §5 does not say it. The source is the Muse lead's ledger, lines 856 to 880 (line 876: "from its retained scripts/logs"). Fix: cite lead.md l876, or cite P1 §5 for the second clause only.

NEW 5 (Q3, line 329): "the fence stayed short of the allowlist P2 asks for." Neither P2's analysis nor the report's own text names an allowlist for the fence. P3 §2 has an allowlist clause for case-report proposal P2, which is a different matter. Fix: name the source or drop the clause.

Verdict on pass 2: NOT READY, on NEW 1 to NEW 5. Each is a single-line fix; none changes a figure. The loop cap (Logan's 2026-10-02 rule) applies, so the lead should apply these by command and state that the final change was checked by the lead, not by a verifier.

Background processes: none started by verifier-R; none running.

## 2026-11-08 11:05:36 -0700 - correction to the pass 2 headline (11:05:26): the headline says "eight of them fully"; the body says sixteen answered rightly and one, NOTE 9, partly

Measured: the pass 2 body lists 16 items answered rightly and NOTE 9 partly answered (the scope is right; the words "lead's seam" are not in the source; see NEW 1). The headline's count is wrong.
For: the lead; Logan
