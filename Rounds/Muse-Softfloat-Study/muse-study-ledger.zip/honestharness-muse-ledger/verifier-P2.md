# verifier-P2: ledger (pass 1 of at most 2)

Append only. Each entry's heading is stamped from the clock.

## 2026-11-08 09:53:13 -0700 - verifier-P2: provenance. The copy's HEAD and one line the copy holds, before any check

Measured:
- The copy at `<repos>/honestharness-worktrees-muse/vP2`. `git rev-parse HEAD` prints `f4d3b66a838ff3d5e29b09bba1d76edebc90f5c1`. Its one parent, from `git log -1 --format=%P`, is `5197b2ab64acd01fa99ada7b75d2b73e34b16472`, the approved plan's commit, as the brief names.
- One line the copy holds, from `git log -1 --format=%s` in the copy: "P2: transfer, escapes, the lead's errors, and the case report against the record". The lead's ledger (09:52:36) says the copy holds no object of the parcel's own commit, so this commit is the copy's, and its message is the parcel's own.
- Read before this entry: the ledger README, `lead.md`, `briefs/_verifier.md`, `briefs/verifier-P2.md`, `briefs/P2.md`, and the plan `Rounds/Muse-Softfloat-Study/PLAN.md` as it stands in the copy.
- Not yet read: the parcel's ledger file `P2.md`, and its work (`ANALYSIS.md`, `scripts/`, `data/`). They come after my own view of the brief's standard is formed.

Believed:
- The copy's HEAD and parent are as the brief states. No check has counted yet.

For: the lead; verifier-P2's report

## 2026-11-08 10:00:18 -0700 - verifier-P2 (pass 1): the re-run, and what reproduces. The scripts run in the parcel's directory, the copy's data restored

Measured (commands run in the copy's parcel directory, because each script's usage paths are relative to it; the roots as arguments, `python -I`):
- `method_copies.py`, `extract_candidates.py`, `build_clauses.py`, `harness_table.py`, `parse_full_audit.py`, `build_escapes.py`, `build_lead_errors.py`, `case_report_checks.py` and `build_case_report.py` each ran and wrote the committed data byte for byte: `git -C <copy> diff --stat` showed no change in their outputs.
- `search_record.py` wrote `data/escape_search.csv` and then failed on a print: the console is cp1252 and cannot print the character U+2192 (exit 1). Its CSV is written before the print, so the file is whole. Its hit counts match the committed file for all 44 rows.
- Its first_hits do not match the committed file under the default `--max 6`, which the script's docstring does not mention. With `python -I -X utf8` and `--max 100` (run into my scratch, not the copy), the committed CSV reproduces exactly: 44 of 44 rows. So the search is reproducible, with two flags the usage line omits.
- I restored the copy's `data/escape_search.csv` from the committed blob. `git -C <copy> diff --stat` now shows no change.
- Method copies: four of six differ from their pins (ParcelRound `METHOD.md` at 24 lines, first at 107; HonestFramework `METHOD.md` at 248; `WITH-PARCELROUND.md` at 3; `FAILURE-MODES.md` at 352). `ADOPTION.md` and `ADOPTING.md` are identical. Line counts are equal in all six. The analysis's account is right.
- Clauses: 171 rows, DONE 76, ADAPTED 35, SKIPPED 6, NA 6, UNKNOWN 48 (`clauses.csv`, my recount by `csv` read); 638 candidate lines in 3,704 kit lines; 176 distinct lines and 255 with `also_in`.
- Harness: 14 rows; the analysis's grouping of them into held, limit, failed, no contact, partly and unknown matches `harness.csv`.
- Full audit: 43 findings (4 major, 2 major-suspected, 22 minor, 15 nits). 33 are escapes: F1 14, C3 5, F2 2, E1 2, none 10. 16 escapes have no search hit. All confirmed by my own tally of `escapes.csv`.
- Lead errors: 47 rows (24 from `corrections.jsonl`, 23 more). Of the 22 lead-owned corrections rows: brief faults 11 (CJ01-03, 08-13, 15-16), code or tool 4 (CJ04-07), SF-0 text 1 (CJ14), SF-2 draft 5 (CJ17-21), merge body 1 (CJ24). The ancestry for CJ04-07 holds: fixes at `53acb1a` and `b37fb12`, both ancestors of the seal.
- Case report: 79 claims, 17 observations, 14 setting and 12 cost-table claims. Recounts at `a49991f`: 190 plant rows, 182 caught, wave6 44/45, postseal 20/20; 128 usage rows; 131 passes; 49 briefs; input 1,410,803,658 plus output 7,261,540 = 1,418,065,198; RECORD 1,400 lines (1,418 at `b78af18`); 216 of 216 commits carry a Co-Authored-By line (checked per commit); 17 numbered observations in the report; 18 files contain no "memory ceiling" phrase, 18 of 101 contain it (`ls` and `grep -l` over the briefs directory).
- The copy's HEAD is unchanged (`f4d3b66`). No background process was started.

Believed:
- The scripts are sound in their own logic, and the counts that the scripts print are the counts the data hold. The errors below are in the analysis's prose and in some curated verdicts, not in the scripts.

For: the lead; P2

## 2026-11-08 10:04:51 -0700 - verifier-P2 (pass 1): NOT READY. Eight wrong answers, four restated sentences and a set of notes, each with its evidence. Correction to the entry at 10:00:18: of the 101 brief files, 18 contain "memory ceiling" and 83 do not

Measured (each by the command or file named; the copy is `f4d3b66`, the sources at the commits named):

Sent back (a wrong answer):
- **S1, the clause marks (ANALYSIS.md, Task 1).** The marking table says "done as written | 86". `data/clauses.csv` has DONE 76, by `build_clauses.py` and by my recount. The table's rows sum to 181, not 171. The analysis's own spot-check line says 76. It should say 76.
- **S2, the escape table, minor row (ANALYSIS.md, Task 2).** It says "minor (22) ... not raised 15". `data/escapes.csv` has 16 minor rows not raised (script and my recount). The row sums to 21. The "all" row's 32 is right. It should say 16.
- **S3, the case report's holds and partly (ANALYSIS.md, Task 4).** It says "holds 46" and "partly 11". `data/case_report_claims.csv` has holds 47 and partly 10, by the script and my recount. The gap is CR36 (S4).
- **S4, CR36's verdict (`data/case_report_claims.csv`).** The claim is "every brief carried a memory ceiling". Its own measure is 18 of 101 briefs (`ls` gives 101; `grep -l "memory ceiling"` over the briefs directory gives 18). A universal that 83 briefs do not meet is not "holds". Its verdict should be partly, which is what the analysis's text says. Corrected, the table gives 46 and 11, and the analysis's counts then stand.
- **S5, the M1 citation (ANALYSIS.md, Task 2).** It cites `scratch/verifier-readme/report.md:81`. That file has 75 lines. The README sentence and its "Agree" mark are at line 18, which CR39 cites correctly.
- **S6, the lead's own errors (ANALYSIS.md, Task 3).** It lists "the lead itself (E01, E08, E14, E17, E18, E20)". In `data/lead_errors.csv`, E01's `caught_by` is verifier-phase0. The lead caught E02, E06, E07, E08, E14, E17, E18 and E20: eight rows. The list should be those eight.
- **S7, the adherence auditors (ANALYSIS.md, Limits).** It says "The adherence auditors never opened `lead.md`". `scratch/audit-adherence-2/report.md` line 9 reads "`ledger/lead.md` 2026-10-28 05:24:40" and line 25 reads "`ledger/lead.md` headings all (101 entries) + sampled bodies". So the first adherence audit did open it. The final audit (`scratch/audit-adherence-final/report.md` line 12) and the seal (`scratch/audit-adherence-seal/report.md` line 11) say they never did. The limit should name those two and say what the first read.
- **S8, the C130 marking (`data/clauses.csv`, not quoted in the analysis).** C130 (BOARD.md line 11, "The lock is a file <ledger>/board.lock") is marked DONE on the lead's mentions, L:123, 183, 249 and 255. Its own note cites the seal audit, `scratch/audit-adherence-seal/report.md` line 153. The section at lines 158 to 162 reads "NOT met: no `board.lock` file in any granted authority (`ledger/board.lock` absent ...)". A DONE mark that the record's audit contradicts. It should not be DONE, on the audit's account. This moves DONE from 76 to 75, if changed.

Restated (a sentence stronger than its evidence):
- **R1, the rate comparison (ANALYSIS.md, Task 3).** It says "Against round 6's nine, this lead overreached at about twice the rate, the clearest sign of the weaker model." The analysis gives no denominator for either round. The items the paragraph itself lists for this round are five (L:27, L:34, E09, E11, E12), which is fewer than round 6's nine, not twice. The harness, models, planted copies and rounds all differ (plan section 8). It should state the counts only, and drop "twice the rate" and "the clearest sign".
- **R2, the quotation (ANALYSIS.md, Task 2, M1 mechanism).** It quotes "check every claim in a document" (`ROLES.md:91`). The kit line reads "check every claim in a comment, a document or a commit message". Quote it whole, or drop the quotation marks.
- **R3, the gate timing (`data/case_report_claims.csv`, CR75).** It says "standard 55 to 76 s ... Both ends appear in the record". No "55 s" appears in `lead.md` (grep). `lead.md` line 127 says "standard 54s". The "76 s" is at `scratch/audit-full/REPORT.md` line 16, not lines 17 to 20 as cited. The verdict should be partly.

Notes (the verdict stands, or the citation needs its file or line):
- **N1 (CR62).** It cites L:856 and L:866. "repo cut silent" is at `lead.md` line 846. Cite 846.
- **N2 (CR09).** Its reason says "one of the 3 is verifier-phase0". All three verifier-like Wonder rows at `a49991f` are wave 0: verifier-phase0, rechecker-phase0 and rechecker2-phase0 (`docs/metrics/usage.jsonl`). The verdict holds.
- **N3 (ANALYSIS.md, Task 2).** It cites "verifier-w5attr ... (:41)" and "the augmented-parcel verifier ... (:120)" without the folder. The lines are `scratch/verifier-w5attr/report.md` 41 and `scratch/verifier-w5aug/report.md` 120. Both exist and say what the analysis says.
- **N4 (CR72).** "RECORD 1,400 lines" is at `a49991f`. At `b78af18`, the analysis's default, it is 1,418 lines. Name the commit.
- **N5 (`search_record.py`).** Its usage line omits `--max` (the default 6 truncates first_hits) and it fails on this console without `-X utf8`. Reproduction needs both. Limit only; the counts reproduce.

Confirmed at the cited line (my own read):
- `tools/run.sh` at `a49991f`: no line names TestFloat or Berkeley (`git show` and `grep -i`; empty).
- `board/read_until.py` line 37 at `a49991f`: `t_end = time.time() + 60`.
- ParcelRound `METHOD.md` line 228 at `f42242e`: "A figure the documents quote has a script in the tree."
- ParcelRound `CASE-STUDY-6.md` lines 254 to 276 at `f42242e`: observation 12, "nine of the lead's own sentences claimed more than their sources".
- `docs/KICKOFF.md` lines 43, 111 to 115, 116, 144, 156 to 163 and 196 to 198 at `b78af18`, and `docs/RECORD.md` lines 1004, 1251 to 1254, 1288 to 1289 and 1340 at `b78af18`, as cited.
- `ledger/lead.md` lines 27, 34, 36, 181, 417, 634, 639, 643 to 645, 676, 691, 839, 856, 866 and 884, as cited.
- A2 section 1 (lines 32 to 57): "about 30 of 44" lead commits reached main unverified, as C085 and the analysis say.
- AF line 90 and AS line 93 are the headings the analysis cites.
- Kit `ROLES.md` line 100 and `METRICS.md` line 30 say what the analysis says.
- The 10 clause rows I read (C018, C033, C056, C060, C085, C088, C110, C115, C130, C154) match their evidence, except C130 (S8).

Not checked, by me, in this pass: the other clause reasons and the other curated verdicts (I sampled about 25 of 79 claims and about 10 of 171 clauses), the COVERAGE count of 228, the escape verdict texts beyond M1, M2 and M4, and the RECORD erratum's "8 of 15", which is P1's claim.

Believed:
- S1 to S8 and R1 to R3 are the findings the lead should fix. S4 and S8 are verdicts, not counts, and need the parcel's own judgement; the rest are figures or citations I reproduced.
- The analysis's structure is sound: the scripts reproduce its data, and most of its curated judgements follow from their evidence. The errors cluster in prose figures and in four verdicts.
- Whether S8 changes the clause count depends on the parcel's reading of the seal audit.

For: the lead; P2; the report

## 2026-11-08 10:01:02 -0700 - verifier-P2: correction to the entry headed 10:04:51. Its heading was not read from the clock, and its sampling count is too high

Measured:
- The entry headed 10:04:51 was not stamped by `date`. Its heading time was my guess. The clock readings bracket it: 10:00:18 (the entry before it, stamped by `date`) and 10:01:02 (this entry, stamped by `date`). It was written between them.
- Its line on sampling says "I sampled about 25 of 79 claims and about 10 of 171 clauses". It is wrong on the claims. I read all 79 reasons in the printed table, and re-checked against their sources about twenty of them. The clause figure is right: I read the ten named rows and the six skipped rows.

Believed:
- Nothing in the findings changes. S1 to S8, R1 to R3 and N1 to N5 stand as written, each with its own evidence.

For: the lead; P2

## 2026-11-08 10:21:01 -0700 - verifier-P2, pass 2 (the last; scoped to P2's fix diff `64325774` to `31d80c2`, no plants): NOT READY on one restate that the fix introduced. Every answer is right; the counts reproduce

Measured (`git -C <HonestHarness> diff 64325774 31d80c2`, 8 files; the parcel exported to `<scratch>/verifier-P2/p2` by `git archive 31d80c2 -- Rounds/Muse-Softfloat-Study/parcels/P2`; P2's worktree never touched):

Answers, each checked against its source:
- **Lead's P2 item 1 (E02, E06, E07, E08, E14, E17, E18, E20; E01 to verifier-phase0).** Right. `data/lead_errors.csv` `caught_by`: E01 verifier-phase0; the eight are "lead" entries.
- **Item 2 (the adherence auditors' reading of `lead.md`).** Right in the limit, and in the body. `audit-adherence-2/report.md` line 25 says "headings all (101 entries) + sampled bodies", and lines 12 (final) and 11 (seal) say "Never opened `ledger/lead.md`". The limit now says so.
- **Item 3 (C130).** Now UNKNOWN, with a basis. The argument is that a lock file is removed on release (BOARD.md's rule, `C131`), so the seal audit's absence is expected. That is a defensible reason, not a reversal of the audit. The basis cites AS l158-162, and the analysis's text cites the same lines. Accepted.
- **Item 4 (ROLES.md l91 quotation).** Right. Kit line 91 reads "check every claim in a comment, a document or a commit message", and the quotation now matches it exactly, in `escapes.csv`, `escapes_curated.txt` and the analysis.
- **Item 5 (CR75).** Right. Verdict partly; `lead.md` l127 "standard 54s"; REPORT l16 "76 s" (grep confirmed the line); no "55 s" in `lead.md` (grep). The citation is now `scratch/audit-full/REPORT.md:16`.
- **Item 6 (N1 to N5).** N1: `lead.md` line 846, "repo cut silent for music licensing" (grep confirmed). N2: all three Wonder rows are wave 0 (usage rows, my recount). N3: folder names added (`scratch/verifier-w5attr/report.md:41`, `scratch/verifier-w5aug/report.md:120`). N4: "1,400 lines at a49991f (1,418 at b78af18)". N5: `search_record.py` now defaults to `--max 100` and reconfigures stdout to UTF-8.
- **Not in the lead's list:** R1 ("twice the rate") is absent from the committed analysis at 31d80c2 and at 64325774, and my copy's S1 to S5 and R1 were planted, as the coordinator says. S1 to S5 are also resolved in the committed data: the committed clause marks, claim counts and escape counts are what I recounted in pass 1, so no answer is owed for them.

Reproduction (re-run in the export, output compared with the committed blobs, line endings normalised for the comparison):
- `build_clauses.py` (with the pass-1 candidates file): marks DONE 75, ADAPTED 35, SKIPPED 6, NA 6, UNKNOWN 49; the output file is identical to `data/clauses.csv` at 31d80c2.
- `build_case_report.py`: holds 45, partly 12, doesn't 1, unverifiable 21; identical to `data/case_report_claims.csv`. CR36 is "partly" in the committed file, and that matches the analysis.
- `build_escapes.py`: identical to `data/escapes.csv`.
- `search_record.py` with no flags, from the export: exit 0. Its parsed rows match the committed `data/escape_search.csv` in 44 of 44 rows. Its bytes do not: the script writes CRLF line endings (Python's csv default) and the committed blob has LF. So the claim "checked by cmp" holds only after line-ending normalisation, on this Windows checkout.

Restate (a fault in the changed lines; the one finding of this pass):
- **P2-P2a, ANALYSIS.md line 47 (the C130 paragraph).** It says the seal audit "finds no ledger/board.lock and no parcel or verifier ledger citing it". `audit-adherence-seal/report.md` lines 158 to 161 say only that `ledger/parcel-w6augint.md` and `ledger/verifier-w6augint.md` do not cite the lock or serial. That is two ledgers, not every parcel and verifier ledger. The sentence claims more than the audit checked. Fix: name the two augint ledgers, as the data row's basis does.

Minor, no figure changed:
- The C130 basis in `data/clauses.csv` and `clauses_curated.txt` reads "neither augint ledger citing the lock or serial". It is clumsy but accurate.
- The CRLF note above is a limit on N5, not an error.

Believed:
- The fix answers each finding of the lead's list rightly, and every count it changes reproduces. The one restate is a single sentence. Once it is fixed by naming the two ledgers, the delta adds no error I can find. NOT READY is for that sentence alone.

For: the lead; P2; the report
