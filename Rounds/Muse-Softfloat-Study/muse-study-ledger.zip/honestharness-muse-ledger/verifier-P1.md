# Ledger: verifier-P1 (pass 1 on P1 planted copy)

## 2026-11-08 09:51:21 -0700 - provenance: copy HEAD and a copy-only line

Measured: in the copy, `git rev-parse HEAD` prints 6cb77d6231e409664d734b4a05f1ead2404f2f3f; its parent is 5197b2ab64acd01fa99ada7b75d2b73e34b16472 (`git rev-parse HEAD~1`). A line that the copy holds and the base does not: the first line of Rounds/Muse-Softfloat-Study/parcels/P1/ANALYSIS.md at HEAD, "# P1: the measurements (muse-softfloat study)". The base 5197b2a has no such file (`git ls-tree` at base shows no parcels/P1/ANALYSIS.md).
Believed: the copy is one commit on the base, as make_copy.py was described to build it.
For: the lead (provenance check).

## 2026-11-08 10:03:57 -0700 - pass 1: the re-run of P1's scripts changes 86 lines in six data files, all of them Wilson intervals, because common.py computes them at z=1.645 (90 percent) and not 95 percent

Measured: in my copy (<repos>/honestharness-worktrees-muse/vP1, HEAD 6cb77d6), `python -I scripts/run_all.py --repos <repos>` ran all 13 scripts to exit 0 and printed "checks: 25 different: 0". `git diff --stat` then showed six data files changed, 86 insertions and 86 deletions: recall_by_class.csv, recall_by_model.csv, recall_by_project.csv, recall_by_verifier.csv, recall_by_wave.csv and data/tables.md. Every changed value is a wilson95_lo or wilson95_hi column. No count, rate, token figure or class value changed, and no other data file changed. The diff is saved at <scratch>/verifier-P1/rerun_data.diff.
The cause is in the committed scripts/common.py, line 90: `def wilson(k, n, z=1.645):`. recall.py is its only caller. ANALYSIS.md (sections 0 and 2.3) and the committed data give 95 percent intervals, which use z=1.96. My own recount (<scratch>/verifier-P1/recount.py, reading docs/metrics at b78af18 with git show) gives, for 187 of 195 library plants, z=1.96 (0.921, 0.979) and z=1.645 (0.929, 0.977). For 87 of 87 code plants, z=1.96 gives a lower bound of 0.9577 and z=1.645 gives 0.9698. The committed values match z=1.96, so the committed tables were not made by the committed script.
Believed: the script, as committed in the copy, does not reproduce the 95 percent intervals the analysis states. Whether a plant or a parcel error, the copy's own scripts give different intervals from the ones it reports.
Class: sent back (a script that does not reproduce its figures).
For: P1 (the constant); the lead (a planted-copy fault candidate; the key stays closed).

## 2026-11-08 10:03:57 -0700 - pass 1: ANALYSIS.md section 2.3 gives the test-data interval as 0.829 to 0.984; the committed table and the 95 percent formula give 0.809 to 0.984

Measured: ANALYSIS.md section 2.3, table T6, row "test data | 34 | 32 | 2 | 0.941 | 0.829 to 0.984". The committed data/tables.md (T6) and the committed recall_by_class.csv both give 0.809 for the lower bound. My recount at z=1.96 gives (0.8091, 0.9837) for 32 of 34.
Believed: a mistyped figure. No table the scripts write holds 0.829.
Class: sent back (a wrong figure).
For: P1.

## 2026-11-08 10:03:57 -0700 - pass 1: ANALYSIS.md section 6.2 gives ParcelRound 6's verifiers as Sonnet 5.5; its source and P1's own earlier_input.csv say Opus 5.5

Measured: CASE-STUDY-6.md at ParcelRound f42242e, lines 48-49, reads "the lead and every verifier on Opus 5.5, the five parcels on Sonnet 5.5". P1's data/earlier_input.csv and data/earlier_rounds.csv (committed) give verifiers "Opus 5.5" for ParcelRound 6. The ANALYSIS.md section 6.2 row for ParcelRound 6 gives "Sonnet 5.5" in its verifiers column. The other cells in that row agree with the source.
Believed: a copying error in the text. No count changes, but section 6.4 relies on which models the earlier verifiers were.
Class: sent back (a claim false against its source).
For: P1; the lead's comparison.

## 2026-11-08 10:03:57 -0700 - pass 1: section 4.1 says 19 findings come from 11 plant passes; findings.csv gives 18, and the section's four bullets sum to 36 against the stated 35

Measured: data/findings.csv (committed) has 35 rows. By pass_row: 14 on the five non-plant passes (rows 8, 13, 16, 42, 43); 18 on the eleven plant passes (rows 25, 26, 32, 67, 71, 87, 94, 96, 98, 116, 131, which carry 1, 1, 1, 2, 2, 2, 1, 4, 1, 2, 1); 2 with no passes row (verifier-psreadme); and 1 note on pass row 110 (verifier-polish1). The bullets in section 4.1 read 14, 19, 2 and 1, which sum to 36 while the paragraph says 35. My tie-out (passes.jsonl and plants.jsonl at b78af18, with a+b less the findings equals the caught plants on 43 of 46 verifier passes, the note on row 110 not counted, and the exceptions at rows 63, 98 and 121 explained as the section says) agrees with section 4.2's 43 and 3.
Believed: 19 is a miscount for 18. Section 4.2 is right.
Class: sent back (a figure the data do not reproduce).
For: P1.

## 2026-11-08 10:03:57 -0700 - pass 1: section 1.6 cites docs/RECORD.md lines 1268-1270 for the statement that the seal sessions are unrowed by design; the statement is at lines 1286-1288

Measured: docs/RECORD.md at b78af18, lines 1286-1288: "the seal sessions after the metrics cutoff (the two seal parcels, their two verifiers, this auditor) are unrowed in usage/passes by design and named here." Lines 1268-1270 concern escalation rows and the briefs count. The other citations in the same bullets are right (1251-1254 for the seal audit, 1326 for the seal-parcel cutoff).
Class: sent back (a citation that does not say what is claimed).
For: P1.

## 2026-11-08 10:03:57 -0700 - pass 1: the plan's section 4 check has 43 entries, not the 41 the analysis states

Measured: data/figures.json (committed) holds plan_s4_check with 43 entries, all agrees true, and plan_s4_disagreements is empty. ANALYSIS.md section 1.8 says "41 figures" and section 9 says "all 41 figures I recomputed". Those 43 entries include the toy and verifier figures.
Class: sent back (a count the data do not give).
For: P1.

## 2026-11-08 10:03:58 -0700 - pass 1: section 1.7 says the toy's last cumulative lags the file by 3 parcels and 15 plants; by the figures in the same paragraph the plant gap is 20

Measured: section 1.7 gives the toy file as 44 verdict rows holding 220 plants. The toy's docs/RECORD.md at 084f98b gives its last cumulative as "200/200 across 41 parcels" (the line "Five toy5 parcels, all planted-verified 5/5 (cumulative 200/200 across 41 parcels)"). 220 minus 200 is 20. The section's "3 parcels (15 plants)" does not follow from its own numbers.
Believed: the parenthesis is wrong. The record's own cumulative is also off by a step: 41 parcels at five plants each would be 205, which the section does not mention.
Class: sent back (a figure the stated sources do not give).
For: P1.

## 2026-11-08 10:03:58 -0700 - pass 1: section 6.4 attributes 87 code plants and 8 misses to muse-spark-1.3; by the usage rows Spark has 86 code plants and 7 misses

Measured: data/plants_classed.csv (committed), joined to its model column: muse-spark-1.3 has 185 rows, 178 caught and 7 missed; "not recorded" has 10 rows, 9 caught and 1 missed. The code class has 87 rows: 86 with muse-spark-1.3 and 1 with "not recorded". The one miss with no recorded model is in metadata. Section 6.4 reads: "muse-spark-1.3 ... including every code plant (87 of 87), and its 8 misses are all in docs, test data and metadata." The 87 should be 86 and the 8 should be 7. The claim that Spark's misses all fall in docs, test data and metadata holds.
Class: sent back (a figure attributed to the wrong group).
For: P1; the lead's comparison.

## 2026-11-08 10:03:58 -0700 - pass 1: section 0 counts a documented post-verdict revision after 8 send-backs, but section 4.3 says five of those eight are the lead's own restated prose

Measured: section 4.3 lists lines 8, 13, 16, 42 and 43 under "Revision followed (8)", then says "Lines 8, 13, 16, 42 and 43 are the lead's own text restated in place, not parcel revisions; read strictly as 'parcel revision round' the proven count is 3 (lines 67, 71, 87) or fewer." Section 0 says "I find a documented post-verdict revision after 8 and none after 7", with no such qualification.
Believed: section 0 states more than section 4.3's own reading supports.
Class: restated (a sentence that claims more than its evidence shows).
For: the lead's report; P1.

## 2026-11-08 10:03:58 -0700 - pass 1: section 6.4's 'a Spark verifier does the work as well as a Claude one' goes past its evidence

Measured: section 6.4 sets Spark's 178 of 185 against earlier rounds with n of 4, 10 and 12, and calls the intervals "far wider". The same section's table names the confounds: planter, grader, kind of work, plants per copy and models. "Not distinguishable" is a fair reading of those intervals. "Does the work as well as" claims equal performance, which no comparison in the parcel measures.
Class: restated.
For: the lead's report.

## 2026-11-08 10:03:58 -0700 - pass 1: section 6.4 calls HonestHarness round 2's planter 'an Opus-class lead', which no line the analysis reads records

Measured: HonestHarness round 2's lead.md (<repos>/honestharness-r2-ledger/lead.md), searched for model names: its lines record Haiku for the verifiers and Sonnet for the parcels, and name no model for the lead. Section 6.2's row says "not recorded in the lines read". Section 6.4 says "the planter an Opus-class lead (not recorded in the lines I read)".
Class: restated (a claim stated as fact, with its source hedged in a parenthesis).
For: the lead's report.

## 2026-11-08 10:03:58 -0700 - pass 1: the re-grade spot check: twelve of P1's regrade rows, eight misses and catches among them, agree with the cited verifier reports

Measured: I opened the cited lines of the verifier reports under <muse>/scratch/verifier-*/ for regrade_input.csv rows L01, L02, L03, L04, L05, L07, L09, L16, L17, L26, L28 and L33, and read P1's key_plants.csv rows for the eight misses (rows 5, 54, 56, 60, 73, 114, 124, 170). The reports say what P1 says:
- misses: L01 (polish1, the "all four" sentence reconciled, line 26), L02 (readme, the deferred list marked Agree, line 27), L03 (w1f32, "benign drift", lines 98-106), L04 (sf2, "855 - correct", line 26): all missed.
- unclear: L05 (sf2, the pow/powr deferral named as U7 "unsourced" but not called a contradiction, lines 166-170) and L07 (w5metrics, UNRESOLVED U1, "not a fabrication finding", lines 88-100): P1's unclear grade stands.
- catches: L09 (polish1, the TWIDDLES link named, line 17), L16 (w5demo, the expected-kissfft row, line 39), L17 (w1f64, F_UNF 0x04, lines 40-42), L26 (w5exp2, the exp2 zero cut, lines 20-28), L28 (w5metrics, a base SHA that does not exist, line 111), L33 (w6judgemap, the map's 180 s 1920x1080, lines 21-24).
I also recounted P1's sample: 9 claim in docs, 8 code, 7 test data, 3 metadata, 2 record arithmetic, 1 other among the 30 catches, and the wave allocation 2, 4, 1, 1, 1, 1, 2, 4, 7, 7, both matching regrade_input.csv. The 36 agreements and 2 unclear rows match regrade.csv.
I read the keys only through P1's derived key_plants.csv and by hashing the key files. I opened no key file.
Believed: P1's grades for these rows are right.
For: anyone relying on the 36 of 38 agreement.

## 2026-11-08 10:03:58 -0700 - pass 1: what I recounted and found consistent, so the lead can see the coverage of this pass

Measured, by <scratch>/verifier-P1/recount.py and recount2.py (library metrics at b78af18 and toy plants at 084f98b, read with git show), each agreeing with the analysis:
- usage 128 rows; input+output 1,418,065,198; cached 1,379,156,504; muse-spark-1.3 59 rows and muse-wonder-full-1.0 69; no row with cached above input; the role table of section 1.2 (author 28, author+fixer 1, fixer 3, surveyor 50, verifier 46).
- passes 131: author 31, fixer 4, surveyor 50, verifier 46; verdicts NOT READY 37, READY 9; sent_back true 15; a 109 and b 78; the wave table of section 1.3 and T4.
- verifier passes by usage-row model: muse-spark-1.3 43, muse-wonder-full-1.0 3; the three Wonder passes have no plant rows.
- plants 195: caught 187, missed 8, graded_by lead on all 195, checked_by integration on 65 (rows 1 to 65, by wave as stated), 174 with a note, 39 distinct key hashes; the eight misses by verifier and wave as stated.
- escalations 23: test 11 (6 answered; min 19, median 179, max 438 s), real 12 (all answered; min 38, median 141.5, max 3864 s); the five unanswered rows are the ones named.
- corrections 24, all accepted; briefs 50; escalation means all "file".
- toy: 90 rows; 44 dispatched with 44 distinct heads and 44 distinct key hashes; 44 verdict rows holding 220 plants, all 5 caught; 18 verdict rows with extra findings, 26 in all; lead_trim 2; parcels by prefix 15, 12, 3, 8, 6.
- keys: all 78 files hashed (sha256 of the bytes); 39 key-*.json match the 39 row hashes; the 39 drafts match none; the 44 toy key hashes match none; plant_keys.sha256 has 15 hashes covering 75 rows and 2 of the 8 misses.
- the bench rows: verifier-psbench2 (5, key 0305f97a, all caught) and verifier-psbench (5, key c7e98cc5, all caught), as section 3.2 says.
- Spark: 160 usage-row plant rows, 153 caught; with the ledger-named rows 185 and 178. Recall intervals by class, wave, verifier, model and project: all match the committed tables except the test-data lower bound (entry above).
- the classing: 195 rows, 176 shape-equal and 19 not (rows 49, 51, 52, 55 to 60, 66, 67, 69, 74, 81, 181 to 185); 147 decided on shape, 48 on the key file; 27 rows differ from the path rule; 70 tie-break rows with the counts stated; the TB7 rows (120, 136, 140, 143, 192), TB9 (124, 130) and TB6 (58) as stated. I found no row whose class contradicts its rubric, and the blind and final classes agree on all 195.
- the earlier-rounds citations I opened: ParcelRound CASE-STUDY-3 line 149 and 108-109; CASE-STUDY-4 lines 45 and 245; CASE-STUDY-5 lines 31-34 and 158-166; CASE-STUDY-6 lines 48-49 and 152-164; HonestHarness R1 CASE-STUDY at main, lines 8, 118-123, 220-232; round 2 lead.md lines 1062-1075, 2496 and 2762 (7 of 8, 2 of 2, 2 of 2; total 11 of 12). Each matches the cell in earlier_rounds.csv, except the ParcelRound 6 verifier cell (entry above).
- RECORD.md at b78af18: the erratum from line 1004 (65 integration rows; 8 early sent_back rows); the lines 1390 and 1396 (void attempt; 182/190 after psbench2b); 1251-1254 (seal audit); 1326 (seal-parcel cutoff). The final cumulative is at line 1416 (187/195, post-seal 25/25), which the analysis does not cite; its figures agree with its own counts.
- the kit's ROLES.md line 100, GLOSSARY.md lines 27-28 and METRICS.md line 30 say what section 1.3 and 4 say they say.
- the commit counts and dates: library 221 commits, first author date 2026-10-26 10:50:22, last author date 2026-11-03 04:18:39 (committer 04:20:16); toy 224 commits, 2026-11-03 20:05:02 to 2026-11-07 16:39:34.
Believed: the headline figures in section 0 are reproduced. The faults I found are in the rest of the text and in one script constant.
For: the lead; anyone relying on section 0.

## 2026-11-08 10:03:58 -0700 - pass 1: boundaries kept on this pass

Measured: no fenced path was opened, listed or searched. Library git use was git show, git log and git rev-list at b78af18 and 084f98b, with GIT_OPTIONAL_LOCKS=0; I ran no ls-tree or git grep on the library. Scratch: I listed <muse>/scratch/ at one level, by name only. I read the verifier reports named above under <muse>/scratch/verifier-*/, the round 2 lead.md, ParcelRound case studies at f42242e, HonestHarness R1's case study on main, the toy's RECORD.md at 084f98b, and the kit's ROLES.md, GLOSSARY.md and METRICS.md. I read <muse>/ledger/lead.md at the lines the analysis cites (among them 178, 243, 309, 429, 561, 640, 676, 691, 746, 761, 836, 856, 866, 871, 876, 891) and checked the phrases it names. I wrote nothing under <muse>, and nothing in ParcelRound, HonestHarness or the R2 ledger. No background process was started. The copy's data/ holds my re-run output, uncommitted, and the copy was not committed.
Believed: the study's lead.md changed on disk during this pass; its new lines (09:52 onward) are about other parcels.
For: the lead.

## 2026-11-08 10:04:04 -0700 - pass 1: a correction to the spot-check entry above; its headline miscounts the rows

Corrects: the entry headed "the re-grade spot check: twelve of P1's regrade rows, eight misses and catches among them" (the same clock minute, above). Its headline says "eight misses and catches", but the twelve rows it lists are four misses (L01, L02, L03, L04), two unclear rows (L05, L07) and six catches (L09, L16, L17, L26, L28, L33). The body of that entry is right; only the headline's count was wrong.
For: anyone reading the spot-check entry.

## 2026-11-08 10:18:56 -0700 - pass 2: P1's fix (83a1889, on 264294c) answers my genuine findings rightly, and the eight new lines add no error

Pass: 2 of at most 2, scoped to `git diff 264294cbbb7fad064f3adb1c653da253f9567936 83a1889a9f50e1dbe0340e036f292a982e834989` (one file, ANALYSIS.md, 8 insertions and 8 deletions), read with git diff and git show only. Lead's scope: lead.md entries 10:06:06 ("P1" list, items 1 to 7) and 10:17:26.
Measured, the fix at 83a1889 (the file copied with git show to my scratch directory):
- My pass 1 findings 1, 2, 3, 5 and 10 were plants, per the coordinator's message; P1 needs no answer to them. Checked against the real commit 264294c, git show: scripts/common.py has `wilson(k, n, z=1.96)`; the real recall_by_class.csv gives code 0.958; the real ANALYSIS.md has "test data ... 0.809", "ParcelRound 6 ... Opus 5.5", and the RECORD citation "lines 1286-1288". So the real commit did not carry those plants.
- Answers to my genuine findings:
  - 4 (the 19 count): section 4.1 now reads 18, with the per-line counts 25 one, 26 one, 32 one, 67 two, 71 two, 87 two, 94 one, 96 four, 98 one, 116 two, 131 one. Each matches findings.csv (I recounted). The groups 14 + 18 + 2 + 1 = 35 match; "34 rows of kit class a or b plus the one note" matches findings.csv's 7 a + 27 b + 1 note = 35. Right.
  - 6 (41 figures): sections 1.8 and 9 now say 43; figures.json plan_s4_check has 43 entries, all agree. Right.
  - 7 (toy lag): section 1.7 now says the lag is 20 plants (220 minus 200), and that 41 parcels at 5 each is 205, so the record is 5 short; 36 times 5 is 180. All correct. The "3 parcels (15 plants)" sentence is gone.
  - 8 (Spark attribution): section 6.4 now reads, by table T7, 185 Spark rows, 178 caught, 7 misses (test data 2, claim in docs 4, metadata 1: rows 5, 73; 54, 56, 60, 124; 114). I confirmed each row's class from plants_classed.csv. The 8th miss (row 170, metadata) sits with verifier-w6metrics, model not recorded. All 87 code plants caught; 86 Spark-tied, and 1 (row 161, verifier-w6captions, model not recorded, caught). Right. The lead's list said "T8"; the model table is T7 (T8 is by project). P1 cited T7, which is right.
  - 9 (section 0): the section now says five of its eight revisions (passes lines 8, 13, 16, 42, 43, which sent_back_evidence.csv lists as revisions) are the lead's restated prose, and that the strict count is 3 or fewer. Matches section 4.3. Right.
  - 11 (Opus-class lead): the table row now says the planter "was the round's lead, whose model I did not find named in the lines I read." I grepped round 2's lead.md and README.md for the lead's model: none named (the "Opus" hits are price lines). Right.
  - Boundaries (lead's item 7): section 10 now reports the watcher and the gate run, matching P1's report at reports/P1.md, line 10. I did not see those processes; I rely on the parcel's report for that.
- Not answered, because they were plants, and the real commit is already right: findings 1 (the z constant), 2 (0.829), 3 (Sonnet 5.5), 5 (1268 citation), 10 ("does the work as well as").
Checked, the eight new lines' figures and sources:
- 22 (section 0): passes lines 8, 13, 16, 42, 43, five of the eight send-backs. Matches sent_back_evidence.csv.
- 136 (section 1.7): 220, 200, 20, 41 x 5 = 205, 5 short, 36 x 5 = 180. All from the toy RECORD at 084f98b and the toy plants file.
- 285 (section 4.1): the 18 and the line counts above; 34 + 1 = 35.
- 306 (section 4.3): the strict reading, lines 67, 71, 87; consistent with the above.
- 141 (section 1.8): 43 entries.
- 378 (section 6.4): the T7 figures above; "not distinguishable" is hedged with "I believe" and the confounds are restated.
- 407 (section 9): 43 figures.
- 419 (section 10): consistent with reports/P1.md line 10.
- The R2 planter line (table, section 6.4): consistent with the R2 read.
Believed: no error in the eight new lines. The corrections match the sources at the commits named.
Note on the lead's list: the lead cited T8 for the model split; the table is T7. The text uses T7, which is correct.
Limit: I did not re-run the scripts at 83a1889; the fix changes only prose, and P1 says so, which the diff confirms (ANALYSIS.md alone changed).
Verdict for pass 2: READY on the scoped diff.
For: the lead; P1
