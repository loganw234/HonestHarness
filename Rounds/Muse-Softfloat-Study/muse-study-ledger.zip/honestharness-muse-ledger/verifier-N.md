# verifier-N's ledger (verifier of the study's harness notes)

## 2026-11-08 13:58:23 -0700 - verifier-N: provenance, pass 1. The work is `752d39f`, and the notes' first line is quoted. The brief's sha256 matches lead.md's 13:56:42 entry

Measured:
- `git -C <repos>/HonestHarness rev-parse 752d39fbe661226836a96a4a39179a776dfa35b3` (with `GIT_OPTIONAL_LOCKS=0`) prints `752d39fbe661226836a96a4a39179a776dfa35b3`.
- The notes' first line, from `git show 752d39fbe661226836a96a4a39179a776dfa35b3:Rounds/Muse-Softfloat-Study/harness-notes.md`, is: "# Harness notes, the muse-softfloat study".
- `sha256sum` of that `git show` output starts `d77f6294`, the value lead.md's 13:56:42 entry records.
- `sha256sum` of `<repos>/honestharness-muse-ledger/briefs/verifier-N.md` is `5750c403cc9e6e63450d2cfa1270a1a712d67e3d75c9ebeb0daf5aa28965405d`, the value lead.md's 13:56:42 entry records. The brief is trusted.
- Read so far: the README, lead.md (all 1113 lines), `briefs/_verifier.md`, `briefs/verifier-R.md`, `briefs/verifier-N.md`, and the notes at the commit. The other ledger files are not yet read.

Believed: nothing yet checked against a source. This entry comes before any check counts.

For: verifier-N; the lead

## 2026-11-08 14:01:05 -0700 - verifier-N: pass 1 on the notes at `752d39f`: NOT READY, with four restates, no wrong fact, and omissions in notes 1 and 6 and three practices that both the notes and the report's section leave out

Measured (each source read at the commit, or in the ledger, by the commands in "What I ran"):
- The notes' sha256 and first line, and the brief's sha256, match the provenance entry at 13:58:23. No check counts before that entry.
- Every entry cited in the notes exists, and says what its note says, except where a restate or an omission is listed below. The checked citations: 08:19:53, 08:30:26, 08:37:28, 09:31:32, 09:34:05, 09:36:39, 09:38:17, 09:41:11, 09:48:41, 10:00:16, 10:06:34, 10:07:34, 10:10:17, 10:19:41, 11:03:40, 12:28:59, 13:02:05, 13:16:42, 13:39:25 and 13:56:42 in `lead.md`.
- Note 5's citation, round 2's ledger at its entry 2026-10-26 10:04:27 (lines 6421 to 6450, which I read and no further), says what note 5 says: two tests failed on an `SSL_CERT_FILE` set by the reinstalled Miniconda's activation script, to a path a Windows install lacks, and 5 of 5 with the variable removed by name.
- Note 7's line 67 lies inside verifier-C's 12:46:17 entry (heading at its line 8; next heading at line 87). Its 12:46:31 entry (lines 87 to 92) flags it. I did not search for, count, copy or quote the pattern, and I did not run the privacy checks on that line. I rely on the lead's 13:39:25 record of them, unchecked by me.
- The report's section "What running this study showed about the methods" is at `REPORT.md` lines 332 to 362 at the commit. I read it and checked it against the entries for the omissions below.

Findings, by class:

Restate 1 (note 1, "The lead wrote each file verbatim and recorded its hash, and the parcel read it back"):
- The entries say each file was assembled from the parts: each header line stripped, and one blank line between parts (09:36:39, 09:38:17, 09:41:11). "Verbatim" holds of the parts, not of the file.
- P3's committed file differs from the file the lead wrote by one line (09:48:41, found by a diff against the lead's assembled parts).
- P1's and P2's files were then changed by the lead's line-level relay (10:07:34, 10:10:17), and P3's was edited in place (10:06:34).
- The three cited entries record decisions that each parcel would read its file back. None records a read-back outcome for P1 or P2.
- It should say: assembled from the parts, then changed after writing, by the lead's relay for P1 and P2 and by P3's own edit.

Omission 1a (note 1; the report's line 350 says the same):
- 09:41:11 records P1's refusal, which included a draft in its scratch directory. Note 1 cites that entry and omits the refusal.
- 09:34:05 records the boundary the harness drew: a subagent's scripts and tables were written, and its report-like prose was refused.
- 10:06:34 records an Edit to an existing `ANALYSIS.md` accepted.
- So the mechanism "a write grant for the agent's own report path" does not cover the scratch refusal, and does not account for the accepted edit. The note should state the boundary as those entries record it.

Restate 2 (note 3, headline "The shared ledger exposes the planting style"):
- 10:00:16 records that the other verifiers "are told to read only lead.md, the README and their own parcel's file", so the style is "fenced from them by instruction alone".
- No cited entry records a verifier reading another verifier's ledger. The note should say the ledger could expose the style, and that the only fence is by instruction.

Restate 3 (note 5, "Every gate of this study ran with the variable removed by name"):
- The entries record that for each S0 gate: 08:17:33, 08:37:28, 08:47:59, 09:01:25, 09:08:54, 10:28:16, 10:37:36, 10:45:48, 11:03:40, 11:12:13, 12:36:15, 13:16:42, 13:39:25 and 13:56:42.
- The parcels' own gates are reported only as "5 of 5", with no variable recorded: 09:48:41 (P1 and P3), 09:52:36 (P2), 10:17:26 (P1's fix), 10:17:38 (P3's fix), 10:19:01 (P2's fix), 10:30:39 (P3's gate by its report) and 10:32:22 (P2's report).
- Note 5 cites no lead entry for "every gate". It should say "every S0 gate the ledger records".

Restate 4 (note 9, headline "Two counts of the same thing disagreed"):
- 13:02:05 records two different measures: lines (2 for A, 4 for B) and matches (2 for A, 5 for B). It says the 12:28:59 entry's "2 and 4 times" counted lines.
- So the counts did not disagree. A line count was labelled "times", which is a mislabel of the measure.
- 13:02:05 says "by the lead's grep" and names no command. The explanation "grep -c counts lines and grep -o counts matches" is not in any cited entry. The 12:46:31 entry reports the same B match count as 5 against the lead's written 4.
- It should say what was labelled wrongly, and record the command.

Omission 6a (note 6, "The lead waited for its notice and started no second run"):
- 11:03:40 records that the gate first ran detached, "by the lead's own slip of backgrounding it twice", and that its end was then waited on by a polling loop on its log. Note 6 cites only 13:16:42 and omits both.

Notes that hold, with no finding: notes 2, 4, 7 (as to its citations), 8 and 10. Note 7's "as a search pattern" is the 12:46:31 entry's "regex fragment", and holds.

Omissions that both the notes and the report's section leave out (for the lead's decision, as notes):
- A. The line-level relay of revisions (10:07:34, 10:10:17): the lead applied the agents' changed lines by script, each old line or block found exactly once. The report says only that the lead checked the last changes (line 344).
- B. The lead's own slip of writing `harness-notes.md` into S0 while the gate ran (13:39:25), moved at 13:28:55 during the tests.
- C. Planted copies built by the lead's `make_copy.py`, with each key's hash recorded before dispatch (09:48:41, 09:50:30, 09:52:36). Note 3 covers only the hold on grades, and the report's planted-copy bullet says nothing of how copies were built.
- Lower weight, in the same spirit: the lead lifted its own fence for the Claude audits and had three branches fetched after Logan's approval (11:13:44, 12:22:43). Note 2 covers the fence only as agents crossed it.

A point for the report, outside the notes: line 349 says "Three parcels and one verifier met the refusal". The entries record refusals for two parcels (P3 at 09:34:05, P1 at 09:41:11) and for one verifier (verifier-PL at 08:30:26). No entry records one for P2.

Believed:
- None of the four restates is a wrong fact. Each is a sentence stronger than its entries, which the standard in `_verifier.md` calls a restate. That is why this is NOT READY.
- The omissions are for the lead's judgement. I have not looked at the other ledgers, the parcels' work or the Claude audit copies.
- Pass 1 of 2.

For: the lead; anyone writing the harness notes or the report's section

What I ran (all read-only; no background process was started):
- `GIT_OPTIONAL_LOCKS=0 git -C <repos>/HonestHarness rev-parse 752d39f...` and `git show 752d39f...:Rounds/Muse-Softfloat-Study/harness-notes.md` (first line, and `sha256sum`).
- `sha256sum` of `<repos>/honestharness-muse-ledger/briefs/verifier-N.md`.
- `GIT_OPTIONAL_LOCKS=0 git show 752d39f...:Rounds/Muse-Softfloat-Study/REPORT.md`, saved to `<scratch>/verifier-N/REPORT.at-752d39f.md`, then `grep -n "^#"` and reads of its lines 332 to 362, and a `grep -n -i` over it for the practices above.
- Reads of `lead.md` (all lines), the README, `_verifier.md`, `verifier-R.md`, `verifier-N.md`.
- `grep -n "^## "` on `verifier-C.md`; a read of its lines 87 to 92; `grep -n "^## "` on round 2's `lead.md` for the 10:04:27 heading; a read of its lines 6421 to 6450.
- `grep -n` over `lead.md` for "gate", and for "SSL", with the matching lines read by the output.
- `date` for each stamp.
- Not run: any privacy check on `verifier-C.md` line 67, and any search for its pattern; nothing under `audit-bundle/`, `audit-bundle-v2/` or `<repos>/honestharness-muse-claude-audits/`.

## 2026-11-08 14:22:25 -0700 - verifier-N: pass 2, its last, on `8d2c711`: NOT READY, with one restate that the new text carries from the lead's own read-back evidence, one restate in note 9, and two minor points. Most of pass 1 landed, and the one finding that did not hold is rightly dropped

Measured:
- Provenance: `git rev-parse 8d2c711...` prints `8d2c7119f320fffc1a3ba66cf2dbadd8d8797119`, as the lead's 14:20:38 entry states. `sha256sum` of `harness-notes.md` at `8d2c711` is `619434c2...`, and of `REPORT.md` is `20075f28...`, as that entry states.
- The diff `git diff --stat 752d39f 8d2c711` is 2 files, 46 insertions and 16 deletions. It touches only `harness-notes.md` and `REPORT.md`.
- The lead's 14:06:42 entry is at `lead.md` lines 1114 to 1139. Its one dropped finding is at 1137 to 1139. P2's own file, `P2.md`, has the entry "P2: ESCALATION, the harness refused ANALYSIS.md" at 09:34:00, lines 134 to 136. I read it, and it says what the lead says. Dropping my "no entry records one for P2" is right.
- Read the cited entries at their times: P3.md 09:46:32 (lines 136 to 139), P1.md 09:47:27 (lines 215 to 221), P2.md 09:51:12 (the entry after line 143). `briefs/_common.md` line 170 gives the command `env -u SSL_CERT_FILE ... python tools/check.py`.
- I hashed P3's committed `ANALYSIS.md` at `24cce6d`: `sha256sum` is `51cbbaee...`, 247 lines.

Pass 1, finding by finding (each line number is in `harness-notes.md` at `8d2c711`, or `REPORT.md` at `8d2c711`):
- Restate 1 (note 1): landed in form, with one fault left. Lines 8 to 17 now say: assembled from the parts, the revisions by relay (P1, P2) and by P3's Edit, and the read-backs. The sentence "The lead wrote each file verbatim" is gone. Its citations are true: 09:36:39, 09:38:17, 09:41:11, 10:06:34, 10:07:34 and 10:10:17, and the "each old text occurred exactly once" wording matches 10:07:34 and 10:10:17.
  - The fault: note 1's line 15 cites P3's read-back at 09:46:32 as "P3's own file", and report line 352 says "Each parcel read its file back". But 09:46:32 gives sha256 `452a4064...`. That is the hash the lead recorded for its assembled file at 09:36:39, before P3's one-line edit. The same entry says P3 made that edit, changing the loose count from 561 to 548. The committed file at `24cce6d` hashes `51cbbaee...`. So the entry's hash cannot be the hash of the file P3 read back. Either the hash was copied, or the read-back did not happen as stated. The read-back does evidence P1 (09:47:27, which says it checked structure) and P2 (09:51:12, which says it could not byte-compare). It does not evidence P3's.
  - Class: restate. It should say P3's read-back claim rests on its text, not on a hash, and that the committed file differs from the lead's assembly by one line (09:48:41).
- Omission 1a: landed. Line 13 has the scratch-draft refusal (09:41:11), the boundary (09:34:05), and the accepted Edit (10:06:34). Mechanism line 19 includes scratch drafts.
- Restate 2 (note 3): landed. Lines 25 to 28 say "can expose", "fenced by instruction alone", and "No entry records a verifier reading another's file." Each matches 10:00:16.
- Restate 3 (note 5): landed. Lines 34 to 37 say "each of its gates in S0", and the parcels' gates are described as not recording the variable. This holds: the three parcel entries (09:46:32, 09:47:27, 09:51:12) do not say how they ran their gates, and the brief gives the command. Gap: note 5's new line 36 cites no time, against the note header's rule that each note cites its entries by time. It is a note, not a restate.
- Restate 4 (note 9): landed in part. Line 55 is retitled, and line 56 says "The 12:28:59 entry gave a count of matching lines as 'times'." That holds from 13:02:05.
  - The fault, line 57: "The lead counted lines with `grep -c`, and matches with `grep -o` piped to `wc -l`. The entry that takes this draft records the commands." The only entry that names these commands is 14:06:42, written about 75 minutes after the counts in 12:28:59 and 13:02:05. Neither of those entries, nor any entry before 14:06:42, records a command. The sentence presents a reconstruction as a record.
  - Class: restate. It should say the commands are the lead's account of 14:06:42, given after the fact, and cite that entry by its time.
- Omission 6a (note 6): landed. Lines 39 to 42 record the detached run and the polling loop (11:03:40), and the later gates (13:39:25, 13:56:42) hold.
- Omissions A, B and C, and the fence lift: landed as notes 11, 12 and 13 and as note 1's relay.
  - Note 11 (lines 62 to 65) holds against 13:39:25. "The gate's privacy count showed that it had not read the file" is supported by its "246 files ... so it did not read the draft."
  - Note 13 (lines 73 to 76) holds: 11:12:13, 11:13:44 and 12:22:43.
  - Note 12 (lines 66 to 71), line 70: "a check that only the planted files differ." The entries record a count measured after the build ("3 of its 38 files differ ... all of them planted", 09:48:41). They do not record a check built into `make_copy.py`. Class: restate, minor. It should say the count was measured after the build.
- The report's draft 6 line 14 is accurate. Line 350: "Three parcels and one verifier met the refusal (the ledger, 08:30:26, 09:34:05 and 09:41:11; P2's own file, 09:34:00)." Each citation holds. P2's entry is the one this pass checked above.
- Report line 351: "removing only their header lines". The entries (09:36:39, 09:38:17, 09:41:11) say the parts were also joined with one blank line. "Only" is slightly off. Class: note.
- Report line 352: "Each parcel read its file back" carries the P3 fault above. Class: restate, the same finding.

Overclaims in the new text: beyond the four points above, I found none in the new sentences. Removed text: nothing right was removed. The removed sentences are the "verbatim" claims, the "Every gate" claim, the "counts disagreed" headline, and the report's "Three parcels" line without its citations. Each survives or is corrected in its replacement.

Limits, not findings:
- The report's section still does not mention the line relay, the polling gate, the S0 write, the copies or the fence lift. These now sit in the notes only, which is the choice the lead made at 14:06:42, and my pass 1 allowed it.
- I did not check the parcels' reports (`reports/P1.md`, `reports/P2.md`, `reports/P3.md`) for how they ran their gates, since the scope named only the three ledger files. The claim in note 5 about those reports is therefore unverified by me.

Believed:
- The two restates (the P3 hash, and the "records the commands" sentence) are the only faults that a reader would act on. Both are in the lead's new text, not in any source. The lead should fix them by command, as the coordinator's rule for this last pass says.
- The P3 hash fault is one a reader of notes 1 and report line 352 would take as evidence of a read-back that the entry does not show.
- Pass 2 of 2. This is my last pass.

For: the lead; Logan

What I ran (all read-only; no background process started):
- `date` for the stamp.
- `GIT_OPTIONAL_LOCKS=0 git rev-parse 8d2c711...`, `git diff --stat 752d39f 8d2c711 -- ...`, `git diff 752d39f 8d2c711 -- ...` for the two files, and `git show 8d2c711:...` with `sha256sum`, `grep -n` and `wc -l` for line numbers.
- `GIT_OPTIONAL_LOCKS=0 git show 24cce6d...:Rounds/Muse-Softfloat-Study/parcels/P3/ANALYSIS.md` with `sha256sum` and `wc -l`.
- Reads of `lead.md` lines 1114 to 1163 (the 14:06:42 and 14:20:38 entries); `grep -n "^## "` and `sed -n` on `P1.md`, `P2.md` and `P3.md` at the cited times only; `sed -n` on `briefs/_common.md` lines 165 to 175.
- Not run or read: verifier-C.md beyond its headings (not needed); round 2's ledger (not needed); the Claude audit copies, `audit-bundle*`, the keys and the lead's folder.
