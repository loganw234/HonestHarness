# Ledger: lead (the muse-softfloat study)

## 2026-11-08 08:11:55 -0700 - lead: the study opened at Logan's word: how muse-softfloat ran the methods. His three choices, the first look, and the plan's draft 1

Logan, in chat, 2026-11-08, verbatim:

> Lets go ahead and pick up work on this again, while I was busy I entered another hackathon which had the dual purpose of being a generalization test of the methods, rather than continuing model tests, lets take a look at how muse-softfloat handled the methods. Significantly more tracking was done with this one from the start, so it should be a thorough source of data from a 'weaker' model family than Opus level alot of the prior samples came from.

His answers through the question tool, verbatim:
- "Where should the muse-softfloat study land?" "HonestHarness, published (Recommended)".
- "The Claude audit reports in audit-bundle/ were fenced from the Muse agents. How should this study treat them?" "Fenced until my draft (Recommended)".
- "Beyond the hackathon round's record, metrics, ledgers and audits, which sources should the study cover?" "The toy follow-on,Prior rounds' plant data". Not chosen: the raw Muse transcripts.

Measured (the first look; read-only; repositories read at commits with `GIT_OPTIONAL_LOCKS=0`):
- **`<muse>` (`<repos>/Muse-Softfloat`)** is a workspace folder, not a repository. It holds the library repository, the toy repository, `ledger/`, `scratch/`, the kit, the case report, and other files.
- **The library repository:** `main` at `b78af18`, with 221 commits from 2026-10-26 10:50 to 2026-11-03 04:18. The tag `v1.0.0` is at `957fdae`.
- **Its metrics,** copied by `git show main:docs/metrics/<f>.jsonl` and counted by script:

  | File | Rows |
  |---|---|
  | usage | 128 |
  | passes | 131 |
  | plants | 195 |
  | briefs | 50 |
  | corrections | 24 |
  | escalations | 23 |
  | fetches | 5 |

  - **Usage by model:**

    | Model | Rows | Input tokens | Output tokens |
    |---|---|---|---|
    | muse-wonder-full-1.0 | 69 | 733,186,697 | 3,972,310 |
    | muse-spark-1.3 | 59 | 677,616,961 | 3,289,230 |

    Input plus output comes to 1,418,065,198.
  - **Passes by role:** author 31, surveyor 50, verifier 46, fixer 4.
    - The verifier verdicts are NOT READY 37 and READY 9.
    - `sent_back` is true in 15 rows.
  - **Plants:** 187 caught and 8 missed, with `graded_by` "lead" in all 195.
    - The misses are, by verifier and plant: `verifier-w1f32` #5, `verifier-readme` #4, `verifier-sf2` #1 and #5, `verifier-w5alg1` #3, `verifier-w5metrics` #4, `verifier-polish1` #4, and `verifier-w6metrics` #5.
    - `verifier-w6metrics` has no usage row.
  - **Corrections:** all 24 accepted.
  - **Escalations:** 11 tests and 12 real, all by the file channel.
- **The audits:**
  - The adherence audits graded ADHERENT WITH SLIPS at `7c3819c`, `bc807e6` and `751d1d6` (`<muse>/ledger/auditor-adherence-*.md`).
  - The full audit (`<muse>/scratch/audit-full/REPORT.md`, at `a49991f`) found no defect in the shipped math surface, and four majors: three claim-vs-mechanism and one staleness.
- **The kit's `MANIFEST.txt`** pins ParcelRound `f42242e`, HonestFramework `65447fd`, QRO-Crate `8afeede` and cft-fp256 `39f9801`.
- **The toy repository:** `main` at `084f98b`, with 224 commits from 2026-11-03 20:05 to 2026-11-07 16:39.
  - `docs/metrics/` holds `plants.jsonl` (90 rows, in a different schema, with a `copy_head` field) and a README.
  - Its lead's entries sit in `<muse>/ledger/lead.md`, after the last heading at line 889, without headings of their own.
- **The case report** cites `a49991f`, which is an ancestor of `main` by `git merge-base --is-ancestor`, 5 commits before it.

Decided:
- **The study runs under ParcelRound's method,** as rounds 1 and 2 did:
  - a plan of record and this ledger;
  - parcels on Sonnet and verifiers on Haiku;
  - Logan's approval before any parcel starts.
- **The branch is `study-muse`,** cut from main `b69ed76`, in the worktree `<repos>/honestharness-worktrees-muse/S0`. This ledger and its README are new.
- **The plan's draft 1** is `Rounds/Muse-Softfloat-Study/PLAN.md` in S0, sha256 `aa1e2aa8552e14109cc99c94c51abd7d8e39568e1a86d3943aefc991485adf9e`.
  - It is committed on `study-muse` past HonestHarness's gate.
  - It then goes to a plan verifier, `verifier-PL`, on Haiku.
- **The gate runs with `SSL_CERT_FILE` removed by name,** as round 2's ledger has held since 2026-10-26 10:04:27.
- **Round 2 stays paused,** as its 05:12:43 holds. Its ledger gets a note.

For: Logan; verifier-PL; anyone resuming

## 2026-11-08 08:17:33 -0700 - lead: the plan's draft 1 committed on study-muse (227c553), past the gate. verifier-PL dispatched on Haiku with its brief

Measured:
- **`227c553515790ebbf7c51ac4390cc67d53e9c68a` on `study-muse`,** on `b69ed76`. It is one file, `Rounds/Muse-Softfloat-Study/PLAN.md`, 276 lines.
  - Its sha256, `aa1e2aa8552e14109cc99c94c51abd7d8e39568e1a86d3943aefc991485adf9e`, held from the gate run to the add.
- **S0's gate before the add:** 5 of 5, with `SSL_CERT_FILE` removed by name.
  - tests: 805 passed, 40 skipped;
  - privacy: 136 files and 63 commit messages.
- **This ledger's README** has sha256 `80f63d3a0cea6da895b58cf03e0f41af9857cfe5cbff806b568f110cda7fb552`. **`briefs/verifier-PL.md`** has sha256 `e146115f9273cf9a581711312256e3668b5a1238d78eff8aea685be83a9bfb33`.

Decided:
- **verifier-PL is dispatched now,** on Haiku, with its brief, on `227c553`, to check the plan's facts, its feasibility and its fences.
- **Its report decides** what the lead fixes before the plan goes to Logan. The lead answers each finding here.

For: verifier-PL; Logan

## 2026-11-08 08:19:53 -0700 - lead: the study's durable files move out of Temp, to the lead's folder `<repos>/honestharness-muse-lead/` and this ledger's `reports/`

Measured: round 2's old scratch directory lost every writable file within about two weeks (round 2's ledger, this hour). This session's scratch sits in the same Temp tree.

Decided:
- **The lead's working files live in `<repos>/honestharness-muse-lead/`:** entry drafts, logs, the metrics copies at `b78af18`, and later the plant keys.
  - It is the lead's scratch, and no agent reads it.
  - The plan's draft 2 and the briefs say so.
- **Every agent's report goes to `reports/<agent>.md` in this ledger.**
  - verifier-PL's brief names its scratch directory. Its report is copied here when it arrives.
- **Agents' scratch directories stay under `<scratch>`,** for transient work only.

For: every agent; anyone resuming

## 2026-11-08 08:30:26 -0700 - lead: verifier-PL's pass 1 on draft 1 (`227c553`): NOT READY, with four wrong, five restates and six notes. All are taken, each checked by the lead's own command. A fence touch is disclosed and ruled, and the report channel refused a report file

Measured: verifier-PL's report is filed verbatim at `reports/verifier-PL.md`, and its ledger file is `verifier-PL.md`. The lead checked each finding by command, against the library at `b78af18` unless named:
- **W1:** `docs/RECORD.md`'s erratum, from line 1004, says "8 early passes rows carry `sent_back: true` where the planted verdict was not a parcel revision round - read `sent_back` as true only on proven revision rounds". Confirmed.
- **W2:** confirmed.
  - `docs/metrics/plant_keys.sha256` holds 15 hashes and 3 comment lines.
  - Those hashes cover 75 of the 195 plants rows, and 2 of the 8 misses.
  - The plants rows hold 39 distinct `key_sha256` values. Each matches the sha256 of a file under `<muse>/scratch/lead/keys/`, which holds 78 files.
- **W3:** the lines matching "plant" in the case studies, at `f42242e` unless named:

  | Case study | Lines |
  |---|---|
  | `CASE-STUDY.md` | 0 |
  | `CASE-STUDY-2.md` | 0 |
  | `CASE-STUDY-3.md` | 6 |
  | `CASE-STUDY-4.md` | 20 |
  | `CASE-STUDY-5.md` | 9 |
  | `CASE-STUDY-6.md` | 14 |
  | `CASE-STUDY-7.md` at `894d125` | 0 |

  That matches the verifier's reading that ParcelRound's planted copies are rounds 4 to 6. Its quote from round 3 was not re-read.
- **W4:** 7 verifiers have no usage row: `verifier-w6captions`, `-w6metrics`, `-psbench`, `-psciwindows`, `-psreadme`, `-psbench2` and `-psedge`. They hold 35 plant rows, 5 each. Confirmed.
- **R1:** by the model in each agent's usage row, the verifier passes split muse-spark-1.3 43 and muse-wonder-full-1.0 3. Confirmed.
- **R2:** `docs/KICKOFF.md` line 43 says "kit calendar is not strict", and line 144 says "the hackathon window (ends 2026-11-04)". Confirmed.
- **R5:** no usage row's `cached_tokens` exceeds its `input_tokens`, and cached comes to 1,379,156,504 in all. So, as the rows give it, cached is part of input, and the total is input plus output.
- **The audit files are Muse agents' work,** by their usage rows:
  - `auditor-adherence-2` ran on muse-wonder-full-1.0;
  - `auditor-adherence-final`, `auditor-final`, `auditor-wave1`, `auditor-wave2` and `auditor-staleinfo-spark` ran on muse-spark-1.3.

  Reading their files does not touch the fence.

Decided:
- **All four wrong findings and all five restates are taken in draft 2.** The notes are taken too: N1 and N6 into §4, and N2 to N5 into P1's tasks and the briefs.
  - Q2 counts only proven revision rounds as send-backs, as the erratum reads them.
  - The earlier rounds are ParcelRound's rounds 4 to 6 and HonestHarness's rounds 1 and 2. Rounds 1 to 3 and 7 are named as having no planted copies.
  - Recall by model uses the model in the verifier's usage row, or the one the ledger names where there is no row. Otherwise it is "not recorded".
  - Each key is checked against its rows' `key_sha256`, with `plant_keys.sha256` as a partial second check.
- **The fence touch.** verifier-PL's `find` from the workspace root walked the whole tree by filename, including the fenced directories. Its output, cut to 10 lines, showed no fenced name, and no file was opened.
  - Ruled: the fence's purpose holds, because no Claude audit content was read.
  - The rule is tightened. Searches name their directories, and never run `find` or `grep -r` from `<muse>` or from the library repository's root.
- **The report channel.** Claude Code refused verifier-PL's `report.md` and asked for the findings as text. So the practice taken from the case report's P6 is amended:
  1. findings go in the agent's ledger file first;
  2. the report comes back as the final message;
  3. the lead files it verbatim in `reports/`.

  It is a data point on P6: whether a report file is possible depends on the harness.
- **verifier-PL's pass 2,** its last, is scoped to the diff from draft 1 to draft 2.

For: verifier-PL; Logan; P1 to P3

## 2026-11-08 08:37:28 -0700 - lead: draft 2 committed on study-muse (`3345fbd`), past the gate. The README gains the scoped-search rule, the report practice and the lead's folder. verifier-PL is resumed for pass 2, scoped to the diff

Measured:
- **`3345fbd769b74570cfb620bdee70db34ce214c87` on `study-muse`,** on `227c553`. It changes one file, `Rounds/Muse-Softfloat-Study/PLAN.md`: 79 insertions and 34 deletions.
  - Its sha256, `9543007099fef184e79bc1004d4eb46153364e2df6cad834519b5ddd4cdddec8`, held from the gate run to the add.
- **S0's gate before the add:** 5 of 5, with `SSL_CERT_FILE` removed by name.
  - tests: 805 passed, 40 skipped;
  - privacy: 136 files and 64 commit messages.
- **This ledger's README** now has sha256 `d5ae2fcf1e5b38e6db8c0eaaac807300f4428dfd50e7f2745d4ba49fb6e1e2b7`. It changed in three places:
  - searches name their directories;
  - the lead's folder is never read;
  - findings go in the ledger file first, and the report comes back as text.

Decided:
- **verifier-PL is resumed by message for pass 2, its last.** The pass is scoped to the diff from `227c553` to `3345fbd`. It checks two things:
  - that each of its pass 1 findings is answered rightly;
  - that the new text adds no error.
- **Next,** the plan goes to Logan, with any pass 2 finding answered first.

For: verifier-PL; Logan

## 2026-11-08 08:41:30 -0700 - lead: verifier-PL's pass 2 on draft 2 (`3345fbd`): NOT READY, with one wrong, three restates and three notes. All seven are taken in draft 3, each checked by command. A fresh verifier, verifier-PL2, checks the delta, since verifier-PL's passes are spent

Measured: pass 2 is filed verbatim in `reports/verifier-PL.md`. The lead's checks, by command:
- **Wrong 1, the bench attempts.** `<muse>/ledger/lead.md` line 876 records attempt A VOID as `verifier-psbench2` and attempt B as `verifier-psbench2b`, on the planted copy whose key is `0305f97a`.
  - Every plants row for that work is named `verifier-psbench2`, and all of them carry key `0305f97a`.
  - So the rows carry attempt A's name and hold attempt B's grades. Confirmed.
- **Restate 2:** Logan's words in `lead.md` read "alot of the prior samples came from", not "a lot of". Confirmed.
- **Restate 3:** the record never says whether cached tokens are part of input. The lead's claim was an inference.
- **Restate 4:** `auditor-adherence-seal` has no usage row. `docs/RECORD.md` at `b78af18` records its audit at line 1251 ("Adherence seal audit + dispositions (appended 2026-11-01): auditor-adherence-seal graded ...").
- **Note 5, the toy's plants file at `084f98b`:**
  - 44 `dispatched` rows;
  - 44 `verdict` rows, holding 220 plants with 220 caught, each naming its copy's verifier report;
  - 2 `lead_trim` rows, which record proofs cut down.
- **Note 6:** the kit's `METRICS.md` line 30 names "each verifier pass as (a), (b)". The docstring lists `a` and `b` as counts by class.
- **Note 7:** the "not recorded" fallback was decided at 08:30:26 and left out of Q2's text.

Decided:
- **Draft 3 takes all seven.** P1's draft brief takes items 1, 5 and 6 too.
- **The fresh verifier.** verifier-PL's two passes are spent. So verifier-PL2, a fresh verifier on Haiku, checks only the diff from draft 2 to draft 3. This is the case report's P4 in practice: a change after verification goes past an independent check of the change.
- **What follows its report:**
  - If READY, the plan goes to Logan.
  - If it finds a fault in the delta, the lead fixes it and says so to Logan, rather than looping. This follows Logan's 2026-10-02 rule on capping verifier loops.

For: verifier-PL2; Logan

## 2026-11-08 08:47:59 -0700 - lead: draft 3 committed on study-muse (`0080bef`), past the gate. verifier-PL2 dispatched on Haiku for the delta check

Measured:
- **`0080bef5e45f74ee9aad32573020af5d53b00438` on `study-muse`,** on `3345fbd`. It changes one file, `Rounds/Muse-Softfloat-Study/PLAN.md`.
  - Its sha256, `7640d770a5c720afefe7dcbd5253ccf8baa90e03b3fb2afc8c9c80af5204aeec`, held from the gate run to the add.
- **S0's gate before the add:** 5 of 5, with `SSL_CERT_FILE` removed by name. `gate-plan-d3.log`'s last lines give the counts.
- **`briefs/verifier-PL2.md`** has sha256 `4c705af74bd7edbb71083277a8f2b2ebcea0e05a7d2f4dd2b1988f2272837166`.

Decided:
- **verifier-PL2 is dispatched now,** on Haiku, for one pass on the diff from `3345fbd` to `0080bef`.

For: verifier-PL2; Logan

## 2026-11-08 08:54:32 -0700 - lead: verifier-PL2's delta check on draft 3 (`0080bef`): NOT READY, with no wrong fact, one restate and three notes. Draft 4 takes all four, each checked by command. The loop stops here, as 08:41:30 decided. Its two fence disclosures are ruled, and so is its late provenance entry

Measured: verifier-PL2's report is filed verbatim at `reports/verifier-PL2.md`. The lead's checks, by command:
- **The full audit's auditors:** `<muse>/scratch/audit-full/REPORT.md` line 4 reads "Method: 8 read-only auditor agents (library=wonder-full, rest=Spark)". None of them has a usage row.
- **The seal audit:**
  - `<muse>/ledger/lead.md` line 856 reads "auditor-adherence-seal (Spark): ADHERENT WITH SLIPS at 751d1d6".
  - `docs/RECORD.md` at `b78af18`, lines 1251-1254, records the audit and its report, `scratch/audit-adherence-seal/report.md`, "frozen into audit-bundle v2".
  - So the seal audit is a Muse agent's work, and the report's original lies outside the fence. Its frozen copy, inside `audit-bundle-v2/`, stays fenced.
- **The classes:**
  - The kit's `ROLES.md` line 100 reads "(a), a regression; (b), a wrong answer; or a note (GLOSSARY.md). Only (a) and (b)".
  - `GLOSSARY.md` lines 27-28 define (a) and (b). (b) includes a sentence that claims more than is true.
- **The first bench run:** the plants rows named `verifier-psbench` are 5, all with key `c7e98cc5` and all caught. They are for the work "Post-seal bench records on the RP2040".

Decided:
- **Draft 4 takes the restate and the three notes,** in its audits row, P1's items 4 and 5, and its History. P1's draft brief takes the classes and the bench rows.
- **The loop stops here,** as 08:41:30 decided, and these fixes are stated to Logan.
  - The change from draft 3 is the lead's, checked by the commands above.
  - Its facts are lines read in place.
- **The fence disclosures,** both ruled no touch:
  - The grep of `auditor-adherence-seal.md` before its author was confirmed. The file is a Muse agent's, by `lead.md` line 856.
  - The listing of the kit's `reference/` folder. It holds `QRO-Crate.bundle`, the kit's reference project, which is not fenced.
- **The late provenance entry.** verifier-PL2 wrote it after its first checks had begun, and said so.
  - It is a data point on the case report's P1 practice, in this study's own use: a small verifier on a short pass reordered it.
  - The parcels' verifiers will be told that no check counts before the provenance entry exists.

For: Logan; the report

## 2026-11-08 09:01:25 -0700 - lead: draft 4 committed on study-muse (`3f49931`), past the gate. The plan goes to Logan for approval

Measured:
- **`3f49931c88eafce08102f54c93e1fe37ad3a98b0` on `study-muse`,** on `0080bef`. It changes one file, `Rounds/Muse-Softfloat-Study/PLAN.md`: 22 insertions and 9 deletions, leaving the plan at 349 lines.
  - Its sha256, `8792e897be7b5312dc0f74e8079ff7e6c601083001508b62a05427f368b3f0b7`, held from the gate run to the add.
- **S0's gate before the add:** 5 of 5, with `SSL_CERT_FILE` removed by name.
  - tests: 805 passed, 40 skipped;
  - privacy: 136 files and 66 commit messages.

Decided:
- **The plan goes to Logan** through the question tool, with the plan file sent to him.
- **Nothing starts before his approval and go.** At his go:
  - the parcel briefs move from the lead's folder into `briefs/`, each with its hash recorded here;
  - the three parcel worktrees are cut from the approved plan's commit;
  - P1 to P3 are dispatched on Sonnet for their phase 1.

For: Logan

## 2026-11-08 09:02:34 -0700 - lead: Logan approved the plan of record, draft 4, and gave the go

Logan, through the question tool, between 09:01:25 and 09:02:20 -0700 (two clock readings that bracket the answer). Asked: "Approve the muse-softfloat study's plan of record (draft 4, commit 3f49931) and start it?" He answered, verbatim: "Approve and go (Recommended)".

Decided:
- **The plan is approved.** An "Approved" section goes into `PLAN.md`, in a commit past the gate. The parcels are cut from that commit.
- **Wave 1 starts.**
  - The briefs `_common.md`, `P1.md`, `P2.md` and `P3.md` move from the lead's folder into `briefs/`, each with its hash recorded here before dispatch.
  - P1, P2 and P3 are dispatched on Sonnet, for phase 1 only: intent echo, channel test, design, stop.
  - The lead reads each design against its brief, then answers "go" or corrections.

For: P1; P2; P3; anyone resuming

## 2026-11-08 09:08:54 -0700 - lead: the approved plan committed (`5197b2a`), past the gate. Wave 1's worktrees are cut from it, the briefs move into `briefs/`, and P1, P2 and P3 are dispatched on Sonnet for phase 1

Measured:
- **`5197b2ab64acd01fa99ada7b75d2b73e34b16472` on `study-muse`:** "plan of record, draft 4, approved". It adds the Approved section, with Logan's answer verbatim.
  - The plan's sha256, `83b9e3b03be41276144ded839f09c01409e381d98810c3c2390ebb6da93eeda4`, held from the gate run to the add.
  - S0's gate before the add: 5 of 5 (805 passed, 40 skipped; privacy 136 files and 67 commit messages), with `SSL_CERT_FILE` removed by name.
- **The worktrees,** each at `5197b2a` on its own branch:
  - `<repos>/honestharness-worktrees-muse/P1`, on `study-muse-p1`;
  - `<repos>/honestharness-worktrees-muse/P2`, on `study-muse-p2`;
  - `<repos>/honestharness-worktrees-muse/P3`, on `study-muse-p3`.
- **The briefs in `briefs/`,** by sha256:

  | Brief | sha256 |
  |---|---|
  | `_common.md` | `2533815702fce7ac1057f09ba7a60838109f75af2b2acc379b5f67c60bf65db3` |
  | `P1.md` | `95669228cb23cf076b6ba5fe280b94c53149523aace98740cdb1c89c37e48d4e` |
  | `P2.md` | `68573609464797ef44d183ea15887ce29ac0bd70a95e163809cd34facd9daadf` |
  | `P3.md` | `34c31c1714b99f24739d12cb3797100a748d4e00bd634a330603f25ec8f3fdae` |

  - The privacy pattern finds one hit in them: `_common.md` line 176, the commit trailer's `noreply@anthropic.com`. It is not the owner's address.

Decided:
- **P1, P2 and P3 are dispatched now on Sonnet,** in parallel, for phase 1 only: intent echo, channel test, design, then stop.
- **Each design** is read against its brief here, before any "go".

For: P1; P2; P3

## 2026-11-08 09:09:41 -0700 - lead: P2's channel test received

Measured: the message "P2: channel test" reached the lead through SendMessage, and this entry is stamped on receipt.

For: P2

## 2026-11-08 09:09:43 -0700 - lead: P3's channel test received

Measured: the message "P3: channel test" reached the lead through SendMessage, and this entry is stamped on receipt.

For: P3

## 2026-11-08 09:10:03 -0700 - lead: P1's channel test received

Measured: the message "P1: channel test" reached the lead through SendMessage, and this entry is stamped on receipt.

For: P1

## 2026-11-08 09:11:46 -0700 - lead: P2's phase 1 design read against its brief. "Go", with its two questions answered

Measured: P2's design is in `P2.md`, and its final message restates it.
- It covers tasks 1 to 4 as the brief sets them.
- Its clause definition, its extraction scripts and its curation are by hand, and its check script resolves every cited line.
- Its counting rule for escapes is stamped before the audit.
- It runs task 4 after tasks 1 to 3, and marks fenced claims unverifiable.
- It spot-checks each CSV by a second route.

It reports one thing the brief got wrong: the kit's copy of ParcelRound's `METHOD.md` is not byte for byte ParcelRound's at `f42242e`. They first differ at line 107, where the kit rewrote a cross-reference. P2 will cmp every method copy and report each one.

Decided:
- **Dedupe:** yes. Each obligation is listed once, at the kit's line, with the method's line in `also_in`. The table reports both counts, the rows and the file lines they cover.
- **Scope:** the 15 texts the brief names.
  - The kit's `templates/` and `tools/`, and the case studies, stay out, and that is stated as a limit.
  - Where the round's record shows it relying on a template's or a tool's obligation, P2 may note it in a separate list. It is not counted as a clause.
- **Go.** P2 starts phase 2, as briefed. Its report comes back as its final message.

For: P2

## 2026-11-08 09:12:16 -0700 - lead: P3's phase 1 design read against its brief. "Go", with its four questions answered

Measured: P3's design is in `P3.md` (09:11:40 to 09:11:41), and its final message restates it.
- **Its marking scale** is RULE-M, RULE-K, ADVICE, CASE, NEWER and ABSENT, applied per clause of each proposal. The proposal's mark is computed by script.
- **Each row also carries:**
  - whether its label agrees with the case report's;
  - the round's use of any clause the kit had, needing an act and not a mention;
  - the toy's practice;
  - HonestHarness's own rounds.
- **Its controls:** clause stems are committed before any hits are seen, and five proposals are re-marked blind.

It measured that HonestFramework has nothing newer than the pin, and that ParcelRound's only commits above the pin are `8b6d6d4` and `894d125`, both on `case-study-7`.

Decided:
1. **Round 2's parcel ledger files** (`P1.md` to `P4.md`, `PA1.md`, `PA2.md` in `<repos>/honestharness-r2-ledger/`): yes, read-only, for task 3.
2. **Round 2's plan and records on `round2` and `main`:** yes, at commits.
   - Round 2's case study draft was lost with the old scratch (round 2's ledger, 2026-11-08 08:19:53). Round 2's ledger is its record.
   - `AMENDMENT-1.md` is in that ledger.
3. **`grep.exe.stackdump`:** listing only, never opened. `keys/` is not needed for P3's work, so P3 leaves it alone.
4. **`scripts/clauses.json`:** yes, committed as a deliverable, since the marks are checkable only with it.

On the toy's briefs: `<muse>/scratch/` holds folders named for the toy rounds. P3 may read any folder under `<muse>/scratch/` that its record names for the toy, except `<muse>/scratch/lead/`. If the record puts the toy's briefs there, P3 escalates.

The reading that P13 and P16's checkable claims belong to P2's step 4 is right.

For: P3

## 2026-11-08 09:13:18 -0700 - lead: P1's phase 1 design read against its brief. "Go", with its soft spots answered

Measured: P1's design is in `P1.md`, and its final message restates it.
- **Its rubric** has six classes, each defined by the artifact the plant altered. Seven tie-break rules are each logged when they fire.
- **Its classing** is blind to the grades: a keyword layer, then a full read with logged overrides.
- **Its recall** carries Wilson 95% intervals, and cells with n under 10 are not ranked.
- **Its sample** uses seed 20261108: all 8 misses and 30 catches, proportional by wave and round-robin by class. It is graded blind, and only then joined to the lead's grades.
- **Its proven-revision-round count** is derived from later author or fixer passes, and set beside the erratum's 7.
- **Every table** gets a second route.

What it found before designing, by its own scripts over the rows:
- 195 plants rows, 39 verifiers and 39 distinct `key_sha256` values;
- 174 rows carrying a note;
- `<muse>/scratch/lead/keys/` lists 39 `key-<7hex>.json` files and 39 `*-draft.json` files;
- the toy's rows have no shape field.

Decided:
- **The toy's keys and reports.** P1 may read the folders under `<muse>/scratch/` that the toy's own records name: the `verifier_report` paths in its verdict rows, and any key folder its record names. That is for the toy's verifier reports and keys only.
  - The rest of `<muse>/scratch/lead/`, beyond `keys/`, stays closed.
  - If the toy's keys are nowhere its record names, P1 classes the toy by copy, as it designed, and says so.
- **The draft key files.** A `*-draft.json` whose hash matches no row is reported as an unmatched draft, not as a finding. A `key-*.json` whose hash matches no row is a finding.
- **The model names.** Mapping only an unambiguous "Spark" to `muse-spark-1.3`, and nothing else, is right.
- **The rest stands as designed.** The design's own limit 6 goes into the report as written: agreement shows consistency with the verifiers' reports, not how hard the plants were.
- **Go.**

For: P1

## 2026-11-08 09:14:10 -0700 - lead: the shared verifier brief, `briefs/_verifier.md`, is written for wave 1's planted-copy verifiers

Measured: `briefs/_verifier.md` has sha256 `609db5e04560d41c3f92275f2e89324b260755d301180798cfe4a5da78a56817`. It is round 2's verifier brief, adapted to analysis work:
- re-run the copy's scripts;
- check each claim at its cited commit and line;
- check the rules the parcel applied;
- the classes are sent back, restated and limit.

The provenance entry comes before any check counts.

Decided:
- **Each parcel's verifier gets a short brief of its own** at dispatch. It is written after the parcel's work is in.
- **Its copy** is a clone of `study-muse` at `5197b2a`, with no remote and no ref to the parcel's branch. Its one commit on top holds the parcel's files with the plants folded in.
- **The keys** stay in the lead's folder until the last planted-copy verifier has reported.

For: the wave 1 verifiers; P1 to P3, who may read it to know the standard

## 2026-11-08 09:31:32 -0700 - lead: P2's fence disclosure ruled. It was a recursive count that walked the fenced folders' paths, with counts only and no content, and the study is unharmed. Recursive listings now exclude the fenced folders by pathspec

Measured: P2 disclosed it to the lead by message, and in `P2.md` under its entry "fence disclosure".
- **The command:** `git ls-tree -r --name-only a49991f`, piped through `awk` and `uniq -c` to count files by top-level folder.
- **What it touched:** it walked the paths under `audit-bundle/` and `audit-bundle-v2/`.
- **What it printed:** one count for each top-level name, and no file names or content. P2 will not use those counts.
- **Earlier,** root-level `git ls-tree --name-only` listings showed the two folders' names as root entries.

Decided:
- **Ruled.** The fence's purpose holds: a blind comparison with the Claude audits' content. No name or content of a file inside the fenced folders reached P2.
  - The root listings show only the folders' names, which a root listing cannot avoid.
  - P2 carries on.
- **The second crossing by traversal.** verifier-PL's `find` was the first (08:30:26). Both were disclosed by the agent itself, and neither read content.
  - It reproduces the case report's observation 1 in this study's own run: the fence is an instruction, not a mechanism.
  - The study's report states it.
- **A mechanism, added to the README's rule.** A recursive listing of the library repository excludes the fenced folders by pathspec:

      git ls-tree -r --name-only <sha> -- . ':!audit-bundle' ':!audit-bundle-v2'

  The same goes for `git grep` (`-- . ':!audit-bundle' ':!audit-bundle-v2'`). P1 and P3 are told now.

For: P1; P2; P3; the report

## 2026-11-08 09:34:05 -0700 - lead: P3's escalation ruled. The harness refuses a subagent's `ANALYSIS.md`, so each parcel sends its text to the lead, who writes it verbatim; the parcel reads it back, then gates and commits

Measured: P3 escalated by message, with an entry in `P3.md`. The harness refused its write of `Rounds/Muse-Softfloat-Study/parcels/P3/ANALYSIS.md`. The refusal, verbatim as P3 quotes it: "Subagents should return findings as text, not write report files. Include this content in your final response instead."
- P3 did not work around it.
- Its scripts and `data/` are written and checked, and nothing is committed yet.
- verifier-PL's `report.md` met the same refusal (08:30:26).

Decided:
- **The route for every parcel's `ANALYSIS.md`:**
  1. The parcel sends the file's whole text to the lead by SendMessage. If it is long, it goes in numbered parts. The parcel does not end its run.
  2. The lead writes it verbatim to the parcel's `ANALYSIS.md` in the parcel's worktree, and records the file's sha256 here.
  3. The parcel reads the file back. It confirms the file is its text, or names each difference.
  4. The parcel runs the gate and commits on its own branch. The commit message says the lead wrote `ANALYSIS.md` from the parcel's text, because the harness refuses a subagent's report file.
- **Why this is not laundering a refusal.** The refusal's own words send the content to the parent. The approved plan (§2, §6) asks for the analyses to be committed, and the lead writes files on Logan's behalf.
  - Nothing is renamed or disguised to pass the harness's check.
  - Logan is told of this route in the lead's next report.
- **P1 and P2 are told now,** before they reach the same wall.
- **A data point for the report.** In this harness the boundary falls between a subagent's working files, which it may write (scripts and tables), and its report-like prose, which goes back to the parent. It bears on the case report's P6.

For: P1; P2; P3; Logan; the report

## 2026-11-08 09:36:39 -0700 - lead: P3's ANALYSIS.md written verbatim from its four parts

Measured:
- **The file:** `Rounds/Muse-Softfloat-Study/parcels/P3/ANALYSIS.md` in P3's worktree: 17,537 bytes, 247 lines, LF only, sha256 `452a4064e3afe9898b2b8000f25e00a02b9b3dc47cecb6eaa596bd23f9e55a43`.
- **How it was built:** from P3's four messages, each headed "ANALYSIS.md part k of 4". Each header line was stripped, and the parts were joined in order with one blank line between them.
- **Privacy:** no absolute path and no "@" in the file.
- **What P3 corrected before sending:** four places differ from the draft the harness refused, all counts recounted from its own data files. They are kit use (PARTLY 4), the toy (PARTLY 9, SILENT 5), the HonestHarness rounds (MET 2), and its sed check (10 lines).

Decided: P3 reads the file back, then gates, commits and reports, as 09:34:05 set out.

For: P3

## 2026-11-08 09:38:17 -0700 - lead: P2's ANALYSIS.md written verbatim from its three parts

Measured:
- **The file:** `Rounds/Muse-Softfloat-Study/parcels/P2/ANALYSIS.md` in P2's worktree, LF only, sha256 `9461ffb1b5629e34a41917f92279c153c6ecbbb3e204612034e5677b5bc6f991`.
- **How it was built:** from P2's three messages, each headed "ANALYSIS.md part k of 3". Each header line was stripped, and the parts were joined in order with one blank line between them.
- **Privacy:** no absolute path and no "@" in the file.

Decided: P2 reads the file back, then runs the gate again with the file in place, so the privacy check reads it. Then it commits and reports.

For: P2

## 2026-11-08 09:41:11 -0700 - lead: P1's ANALYSIS.md written verbatim from its four parts

Measured:
- **The file:** `Rounds/Muse-Softfloat-Study/parcels/P1/ANALYSIS.md` in P1's worktree, LF only, sha256 `51d8e6f6ca009df7dcda50f42f8c1a90ee7b5bd32a405ea355958dd4fe9598ba`.
- **How it was built:** from P1's four messages, each headed "ANALYSIS.md part k of 4". Each header line was stripped, and the parts were joined in order with one blank line between them.
- **Privacy:** no absolute path and no "@" in the file.
- **A third refusal:** P1 reports that the harness refused its own write of the file, including a draft in its scratch directory.

Decided: P1 reads the file back, gates with the file in place, commits, and reports.

For: P1

## 2026-11-08 09:48:41 -0700 - lead: P3 committed (`24cce6d`), and P1 committed (`264294c`). P3's planted copy is built (`bcc412f`) with its key's hash recorded here before dispatch. Two checks and a slip are recorded

Measured:
- **P3:** `24cce6d133b411a272123261d1158c50ae1555f6` on `study-muse-p3`. It holds 38 files under `parcels/P3/`, past the gate (5 of 5: 805 passed, 40 skipped; privacy 174 files and 68 commit messages, by P3's report).
  - **Its `ANALYSIS.md` differs from the file the lead wrote in one line,** found by a diff against the lead's assembled parts. The loose-search count reads "548" where the lead wrote "561". P3 disclosed it as its own correction after re-marking a clause.
  - **The owner's address.** P3 reported finding it in its HonestHarness scan, "quoted from a round 1 line", and scrubbing it from its data. The lead scanned for the configured address without printing it:
    - round 1's published archive (`Rounds/HonestHarness-R1/round1-ledger.zip` on `main`): 0 hits;
    - round 2's unpublished ledger: 1 hit, the known `verifier-JA1.md:156`, already marked for redaction at round 2's archive.
- **P1:** `264294cbbb7fad064f3adb1c653da253f9567936` on `study-muse-p1`, holding 42 files, past the gate (5 of 5: 805 passed, 40 skipped; privacy 178 files, by P1's report).
  - P1's report corrects its own `ANALYSIS.md` §10. It did start background processes, a watcher and a gate run, and both have exited.
  - Both reports are filed in `reports/`.
- **P3's planted copy:** `<repos>/honestharness-worktrees-muse/vP3`, HEAD `bcc412f2f12d3a830b5baa7818e3d6993cc5f174`. It was built by the lead's `make_copy.py`:
  - a `--no-local` clone of `study-muse` alone, at the base `5197b2a`, with no remote;
  - one commit on the base, carrying the parcel's own message;
  - one ref, and no object of the parcel's commit in its store;
  - 3 of its 38 files differ from the parcel's commit, all of them planted.
- **The key's sha256:** `f6229a1e19de376d59a6aa71dd98b3224fbd0fe502be2c63dc315074b5462ac9`. It stays in the lead's folder until the study's last planted-copy verifier has reported.
- **A slip of the lead's.** While checking P3's plant targets, a command wrote a copy of P3's committed `ANALYSIS.md` to the shell's `/tmp` rather than the lead's folder. It was deleted in the same command. The file is the parcel's own committed text, and nothing secret was in it.

Decided:
- **verifier-P3 is dispatched now,** on Haiku, with `briefs/_verifier.md` and `briefs/verifier-P3.md`, on the copy `bcc412f`, for pass 1.
- **P1's copy is next.** P2's commit is awaited: its gate failed once, on an absolute path it had copied into a data file, and it fixed and re-ran.

For: verifier-P3; P1; P2; anyone resuming

## 2026-11-08 09:49:07 -0700 - lead: verifier-P3 dispatched on Haiku for pass 1, on the copy `bcc412f`

Measured: `briefs/verifier-P3.md` has sha256 `14ca5a626290dd6047a128848de3ce16affd66204dfabb6d798d7a7bf6d2ae2f`. The key's hash was recorded at 09:48:41, before this dispatch.

For: verifier-P3

## 2026-11-08 09:50:30 -0700 - lead: P1's planted copy is built (`6cb77d6`), its key's hash recorded, and verifier-P1 dispatched on Haiku for pass 1

Measured:
- **The copy:** `<repos>/honestharness-worktrees-muse/vP1`, HEAD `6cb77d6231e409664d734b4a05f1ead2404f2f3f`, built by `make_copy.py` from P1's `264294c` on the base `5197b2a`.
  - One ref, no remote, and no object of the parcel's commit in its store.
  - 2 of its 42 files differ from the parcel's commit, both planted.
- **The key's sha256:** `432984d1199feaadd0ca9a24820a303f09354871d32c9df9092b2f379025b7fb`. It stays in the lead's folder.
- **`briefs/verifier-P1.md`** has sha256 `1012405a801468e5b208b8677992e582195ffb47edcb5b1f4141eb986ad88817`.

Decided: verifier-P1 is dispatched now on Haiku, for pass 1.

For: verifier-P1

## 2026-11-08 09:52:36 -0700 - lead: P2 committed (`6432577`). Its planted copy is built (`f4d3b66`) with the key's hash recorded here before dispatch. verifier-P2 is dispatched on Haiku

Measured:
- **P2:** `64325774dbcccb85f76517f2f2b41bdb78b8a15d` on `study-muse-p2`. It holds 28 files under `parcels/P2/`, past the gate (5 of 5: 805 passed, 40 skipped; privacy 164 files and 68 commit messages, by P2's report).
  - The run before it failed the privacy check, on an absolute path P2 had copied into `data/escape_search.csv` from a record snippet. P2 made `scripts/search_record.py` redact such paths, remade the file, and re-ran. The gate caught it as designed.
  - **Its committed `ANALYSIS.md`** has sha256 `9461ffb1b5629e34a41917f92279c153c6ecbbb3e204612034e5677b5bc6f991`, the same as the file the lead wrote at 09:38:17. So it is verbatim.
  - Its report is filed in `reports/P2.md`.
- **P2's planted copy:** `<repos>/honestharness-worktrees-muse/vP2`, HEAD `f4d3b66a838ff3d5e29b09bba1d76edebc90f5c1`, built by `make_copy.py` on the base `5197b2a`.
  - One ref, no remote, and no object of the parcel's commit in its store.
  - 3 of its 28 files differ from the parcel's commit, all planted.
- **The key's sha256:** `41375a312ab61885aece0e21f7912e19cafe2a0289166031056edd854c7b8343`. It stays in the lead's folder.

Decided:
- **verifier-P2 is dispatched now,** on Haiku, with `briefs/_verifier.md` and `briefs/verifier-P2.md`, for pass 1.
- **All three of wave 1's parcels are now committed,** and their copies are with their verifiers.

For: verifier-P2; anyone resuming

## 2026-11-08 09:52:50 -0700 - lead: `briefs/verifier-P2.md` written (sha256 `7cc8e129a8754f5a0d71b4cef9d00cf7aca842b1ae9d4b5275f2c02e1e0baa0a`). verifier-P2 dispatched on Haiku for pass 1, on the copy `f4d3b66`

For: verifier-P2

## 2026-11-08 10:00:16 -0700 - lead: verifier-P3's pass 1 on the copy `bcc412f` is NOT READY. Its grading and P3's send-back are held until the study's last planted-copy verifier reports

Measured:
- **verifier-P3's report** arrived as its final message. Its findings are in its ledger file, with the provenance entry first.
- **The lead graded it against the key,** and checked its findings against P3's real commit `24cce6d`. The grading is written in the lead's folder now.

Decided:
- **Held until verifier-P1 and verifier-P2 have reported:**
  - the grading;
  - verifier-P3's report, which describes its copy;
  - P3's send-back list.

  So this ledger describes no plant while planted-copy verifiers are still working. At the reveal, the grading and the report are filed here, and P3 is sent its list.
- **P3 waits.**
- **A limit, for the report.** verifier-P3's ledger file holds findings on its copy. The other verifiers are told to read only `lead.md`, the README and their own parcel's file. So the planting style is fenced from them by instruction alone, as in the case report's observation 1. The report states it.

For: P3; anyone resuming

## 2026-11-08 10:02:11 -0700 - lead: verifier-P2's pass 1 on the copy `f4d3b66` is NOT READY. Its grading and P2's send-back are held, as 10:00:16 set out for verifier-P3

Measured: verifier-P2's report arrived as its final message. Its findings are in its ledger file, with the provenance entry first.

Decided:
- **Held until verifier-P1 has reported:** the grading, the report and P2's send-back list. They are written in the lead's folder now.
- **P2 waits.**

For: P2; anyone resuming

## 2026-11-08 10:06:06 -0700 - lead: wave 1's reveal. The planted-copy verifiers caught 14 of 15 plants, and the keys, reports and gradings are filed. All three parcels are sent back for genuine findings, and the lists below are what each answers

Measured:
- **The study's last planted-copy verifier has reported:** verifier-P1, after verifier-P3 (10:00:16) and verifier-P2 (10:02:11). Each pass was graded against its key in the lead's folder.
- **The keys are now in `keys/`.** Their sha256 values are those recorded before each dispatch:

  | Key | sha256 | Recorded |
  |---|---|---|
  | `key-P1.json` | `432984d1…25b7fb` | 09:50:30 |
  | `key-P2.json` | `41375a31…8343` | 09:52:36 |
  | `key-P3.json` | `f6229a1e…62ac9` | 09:48:41 |

- **The three reports** are filed verbatim in `reports/verifier-P1.md`, `-P2.md` and `-P3.md`. The gradings are in `reports/grading-wave1.md`.
- **The grades:**

  | Verifier | Caught | Missed |
  |---|---|---|
  | verifier-P1 | 5 of 5 | none |
  | verifier-P2 | 5 of 5 | none |
  | verifier-P3 | 4 of 5 | P3's plant 4 |

  - Every plant is in the keys: wrong figures, moved citations, a fact false against its source, data out of step with the analysis, an overclaim, and a script or check made wrong or unable to fail.
  - The one miss: a prose sentence false against the parcel's own tables ("Overstated" said to mean the proposal is already in the text). It is the class the muse-softfloat verifiers also missed most.
  - The two script plants were caught by re-running: the 90 percent interval, and the check that could not fail.
- **The lead checked every genuine finding below** against the parcel's real commit (`264294c`, `6432577`, `24cce6d`), by command.
- **verifier-P1 also caught P1's own wrong attribution** of 8 misses to Spark, which the lead had noted at 09:50 but not planted.

Decided: each parcel answers its list below on its own branch, then gates, commits and reports. Each verifier's pass 2 is a scoped re-check of that parcel's fix diff, on its real branch. The pass holds no plants.

**P1** (from `reports/verifier-P1.md`):
1. §4.1: the group counts. The bullets sum to 36 against the stated 35. Give each count from `findings.csv`.
2. §1.8 and §9: `plan_s4_check` holds 43 figures, not 41.
3. §1.7: the toy record's lag. 220 less 200 is 20 plants. State the record's own inconsistency: "200/200 across 41 parcels" is 5 short of 41 times 5.
4. §6.4: the Spark attribution. By T8, Spark has 7 misses, and one code plant sits with a verifier whose model is not recorded.
5. §0: "revision after 8". Say what §4.3 says: five of the eight are the lead's own prose, restated.
6. §6.4: "an Opus-class lead" for round 2's planter. Cite a line that names the model, or drop it.
7. §10: "I started no background process", which P1's own report corrects.

**P2** (from `reports/verifier-P2.md`):
1. Task 3's list of lead-caught errors. By `lead_errors.csv` it is E02, E06, E07, E08, E14, E17, E18 and E20. E01 was caught by verifier-phase0.
2. The limit "the adherence auditors never opened `lead.md`". The first adherence audit read its headings (101 entries) and sampled its bodies (`audit-adherence-2/report.md` l25). Only the final and seal audits did not open it.
3. C130's mark against its own note. The seal audit (l158-162) records the rule NOT met by its letter. Reconsider the mark and state its basis.
4. The `ROLES.md` l91 quotation, quoted exactly.
5. CR75. `lead.md` l127 records "standard 54s", and REPORT l16 "76 s". "55" is the case report's figure, so the verdict is partly.
6. The notes N1 to N5: the CR62 and CR09 citations, the folder names, CR72's commit, and `search_record.py`'s `--max` and `-X utf8`.

**P3** (from `reports/verifier-P3.md`):
1. §3: the carousel report's "Provenance" is on line 3, not line 2.
2. P9 c1. The cited lines show a neighbouring practice, not a recorded mode per authority. Re-mark it to agree with §2's pattern 4.
3. The toy marks for P1 and P8: PRACTISED against what is shown. Re-mark them, or state why PRACTISED stands.
4. The restates R4 to R9:
   - the "Blind re-mark" heading;
   - l184 names one report;
   - the P16 and P18 citations from round 2;
   - the diff names `CASE-STUDY-7.md` and a zip;
   - define ADJACENT;
   - 41 rows over 39 distinct pairs.
5. `toy_scan.py`'s docstring, and §8's working folder.

The plants were in the copies, not in the parcels' commits, so they need no answer.

For: P1; P2; P3; their verifiers; the report

## 2026-11-08 10:06:34 -0700 - lead: correction to 10:06:06. How each parcel changes its ANALYSIS.md in its revision; a slip of the lead's, recorded

Decided:
- **P3 edits its `ANALYSIS.md` in place with the Edit tool.** The harness accepted that for P3's own one-line correction in its run 2: an edit to an existing file, not a new report file.
- **P1 and P2 send their changed lines to the lead,** who applies them, as 09:34:05 set out.
- **Either way,** the file's sha256 after the change is recorded here, and the parcel reads it back.
- **A slip of the lead's.** The message to P3 said this before this entry existed. That is against the README's rule that every message is in `lead.md` first. Nothing else in the three messages is missing from 10:06:06.

For: P1; P2; P3

## 2026-11-08 10:07:34 -0700 - lead: P1's revision applied to its ANALYSIS.md, line for line

Measured:
- **Applied:** P1 sent 8 line replacements by message, answering its 7 items from 10:06:06. Each old line was found exactly once as a whole line, and replaced at lines 285, 141, 407, 136, 378, 22, 370 and 419.
- **The file:** sha256 before `51d8e6f6…98ba`, after `38248b8d16c0c255f425df925bfb9c0898583cec75a8fc783988d078c87231ff`. It is 419 lines, LF only, with no absolute path and no "@".
- **P1 reports** that its scripts and data needed no change: only the prose was wrong.

Decided: P1 reads the file back, gates, commits and reports. Then verifier-P1's pass 2 re-checks the diff.

For: P1; verifier-P1

## 2026-11-08 10:10:17 -0700 - lead: P2's revision applied to its ANALYSIS.md, block for block

Measured:
- **Applied:** P2 sent 13 changes by message, plus one appended sentence, answering its 6 items from 10:06:06. Each old block was found exactly once, on line boundaries, and replaced at lines 29, 33, 46, 49, 87, 92, 100, 115, 137, 143, 148, 162, 173 and 175.
- **The file:** sha256 before `9461ffb1…f991`, after `8e5c2af64c71c9f65caa378d8ca6dfe8e42f82760ba70ef85fe9a6f7ba3f56ff`. It is 182 lines, LF only, with no absolute path and no "@".
- **P2's own changes** to its data and scripts, by its message:
  - C130 now UNKNOWN;
  - the M1 quotation in full;
  - CR75 partly, so the claims are holds 45, partly 12, doesn't 1 and unverifiable 21;
  - the CR62, CR09 and CR72 citations;
  - `search_record.py`'s defaults, now reproducing its CSV with no flags, checked by `cmp`.

Decided: P2 reads the file back, gates, commits and reports.

For: P2; verifier-P2

## 2026-11-08 10:17:26 -0700 - lead: P1's fix committed (`83a1889`). verifier-P1 resumed for pass 2, scoped to the fix diff on P1's real branch

Measured:
- **`83a1889a9f50e1dbe0340e036f292a982e834989` on `study-muse-p1`,** on `264294c`, past the gate (5 of 5: 805 passed, 40 skipped; privacy 178 files and 69 commit messages, by P1's report).
- **It changes `ANALYSIS.md` only,** in 8 lines. The committed file has the sha256 the lead recorded at 10:07:34.

Decided: verifier-P1's pass 2, its last, re-checks only `git diff 264294c 83a1889`. It confirms that each of its pass 1 findings 4, 6, 7, 8, 9 and 11 is answered, and that the new lines add no error. The pass holds no plants.

For: verifier-P1

## 2026-11-08 10:17:38 -0700 - lead: P3's fix committed (`64d93c9`). verifier-P3 resumed for pass 2, scoped to the fix diff on P3's real branch

Measured:
- **`64d93c9b964c3bf25b8c376b7d0b8dbddefe701f` on `study-muse-p3`,** on `24cce6d`, past the gate (5 of 5: 805 passed, 40 skipped; privacy 174 files and 69 commit messages, by P3's report). It changes 9 files.
- **`ANALYSIS.md`** was edited in place by P3 (sha256 `2eadf8a2…72d3`).
- **The toy's counts** are now PRACTISED 2 (P6, P16), PARTLY 11 and SILENT 5.
- **P9 c1** is re-marked ADJACENT, which is now defined in §1. P9 stays PARTIAL.

Decided: verifier-P3's pass 2, its last, re-checks only `git diff 24cce6d 64d93c9`. It confirms that each of S5, S6, R1 to R9 and N1 is answered, and that the new lines add no error. The pass holds no plants.

For: verifier-P3

## 2026-11-08 10:19:01 -0700 - lead: P2's fix committed (`31d80c2`). verifier-P2 resumed for pass 2, scoped to the fix diff on P2's real branch

Measured:
- **`31d80c2295c3017cfa6b696f115c1d1af3cfdaa6` on `study-muse-p2`,** on `6432577`, past the gate (5 of 5: 805 passed, 40 skipped; privacy 164 files and 69 commit messages, by P2's report). It changes 8 files.
- **Its `ANALYSIS.md`** has the sha256 the lead recorded at 10:10:17.
- **The marks** are now done 75 and unknown 49. The case report's claims are holds 45, partly 12, doesn't 1 and unverifiable 21.

Decided: verifier-P2's pass 2, its last, re-checks only `git diff 6432577 31d80c2`. It confirms that each of S6, S7, S8, R2, R3 and N1 to N5 is answered, and that the new lines add no error. The pass holds no plants.

For: verifier-P2

## 2026-11-08 10:19:41 -0700 - lead: verifier-P1's pass 2 READY. P1 merged into study-muse (`e038ed2`), and its gate is running. A correction to 10:06:06

Measured:
- **verifier-P1's pass 2,** on `264294c..83a1889`, is READY.
  - Each of findings 4, 6, 7, 8, 9 and 11 is answered rightly, and the 8 new lines add no error.
  - It also checked its five plants against P1's real commit, and found each already right there.
  - Filed in `reports/verifier-P1.md`.
- **The merge:** `e038ed29b71e6d14d447b1447f9c487556620b8e` on `study-muse`, `--no-ff` from `study-muse-p1` at `83a1889`. It adds 42 files under `parcels/P1/`.
- **S0's gate on the merge** is running.

Decided:
- **The correction.** The 10:06:06 entry's P1 item 4 cites "T8" for the model table. The table is T7, and P1 cites T7. verifier-P1 caught the lead's slip.
- **The gate's result** goes here when it is done.

For: anyone resuming

## 2026-11-08 10:20:44 -0700 - lead: verifier-P3's pass 2 on P3's fix (`24cce6d..64d93c9`): NOT READY on two restates, every genuine finding answered. The loop is capped here. P3 makes the two restates, and the lead checks the diff

Measured: verifier-P3's pass 2 is filed in `reports/verifier-P3.md`. It finds S5, S6, R1 to R9 and N1 answered rightly, and the counts, the ADJACENT definition and the cite_check control hold. There are two restates in the changed lines:
- **A, P16 marked PRACTISED** on README l9-18, which shows its clause c1 alone. P1 and P8 were moved to PARTLY for the same kind of gap. Either P16 is marked PARTLY (toy: PRACTISED 1, PARTLY 12, SILENT 5), or the analysis states why c1 alone makes it practised.
- **B, P9 c2 marked RULE-M** at `PR:METHOD.md` l1126, while its own note in `marks.csv` says the sentence is not "only the weakest mode still true". Mark it PART. P9 stays PARTIAL.

Decided:
- **verifier-P3's two passes are spent,** and Logan's 2026-10-02 rule caps the loop.
- **Both findings are restates** (sentences, or marks, claiming more than their evidence). Neither is a wrong answer.
- **P3 makes them on its branch, with its own judgement on A.** It gates, commits and reports.
- **The lead checks that diff by command:** that it touches only these marks and the counts that follow from them, and that `check_marks.py` and `recount.py` still hold. It merges P3 on that check.
- **The report says so:** P3's last change was checked by the lead, not by a verifier.

For: P3; the report

## 2026-11-08 10:21:52 -0700 - lead: verifier-P2's pass 2 on P2's fix (`6432577..31d80c2`): NOT READY on one restate and one limit, every genuine finding answered. The loop is capped here, as for P3. P2 makes the restate, and the lead checks the diff

Measured: verifier-P2's pass 2 is filed in `reports/verifier-P2.md`. It finds each item answered rightly. The changed scripts, re-run from an export of `31d80c2`, reproduce `clauses.csv`, `case_report_claims.csv` and `escapes.csv`.
- **The restate:** `ANALYSIS.md` l47 says the seal audit found "no parcel or verifier ledger citing" the lock. The audit (l158-161) checked only `parcel-w6augint.md` and `verifier-w6augint.md`.
- **The limit:** `search_record.py` writes CRLF on this host, and the committed CSV is LF. So the analysis's "checked by cmp" holds only after line endings are normalised.

Decided:
- **verifier-P2's passes are spent,** and the loop is capped by Logan's 2026-10-02 rule.
- **P2 names the two ledgers in l47's sentence.** It also either makes `search_record.py` write LF (`lineterminator="\n"`), or states the limit where "cmp" is claimed. Its choice; the fix is preferred.
- **P2 may edit its `ANALYSIS.md` in place with the Edit tool,** as P3 does (10:06:34), and reports the file's sha256.
- **The lead checks the diff by command** and merges P2 on that check. The report says P2's last change was checked by the lead, not by a verifier.

For: P2; the report

## 2026-11-08 10:28:16 -0700 - lead: S0's gate on P1's merge (`e038ed2`): PASS: 5 of 5 checks hold

Measured: `gate-merge-p1.log`'s summary lines, with `SSL_CERT_FILE` removed by name.

For: anyone resuming

## 2026-11-08 10:30:39 -0700 - lead: P3's last change (`64d93c9..5c8f4f9`) checked by the lead, as 10:20:44 set out. P3 merged into study-muse

Measured (the lead's check, by command):
- **`git diff --stat`:** 5 files, 9 insertions and 8 deletions:
  - `ANALYSIS.md`, 7 lines;
  - `data/marks.csv`, `data/toy_practice.csv`, `data/clause_marks.csv` and `data/proposals.csv`, the rows that follow.
- **The text changes** are the toy counts line, now PRACTISED 1 (P6), PARTLY 12, SILENT 5, and the P16 bullet ("in part: merge-time rows for the plant ledger only ... the proposal's 'no end-of-round refresh' clause is not shown").
- **The row changes:** P16 PRACTISED to PARTLY in `toy_practice.csv`, and P9 c2 RULE-M to PART in `marks.csv`.
- **P3's checks, re-run** from a `git archive` export of `5c8f4f9` in the lead's folder:
  - `check_marks.py` holds;
  - `recount.py` gives ABSENT 3, PARTIAL 14, CASE-ONLY 1 by both routes, with no disagreement;
  - `assemble.py` rebuilds `proposals.csv` byte-identical.
- **`ANALYSIS.md` at `5c8f4f9`** has sha256 `ed9bf191ce5b7ff7d42c8e69f424183b1cd46849309679f0bfb9575db89096d8`, as P3 reported.
- **P3's gate** (its report): 5 of 5.

Decided: P3 is merged with `--no-ff` into `study-muse`, and S0's gate follows.

For: anyone resuming; the report

## 2026-11-08 10:32:22 -0700 - lead: P2's last change (`31d80c2..06f1a45`) checked by the lead, as 10:21:52 set out. P2 is merged after P3's merge gate finishes

Measured (the lead's check, by command):
- **`git diff --stat`:** 11 files, 11 lines each way.
  - Ten scripts each change `csv.writer(fh)` to `csv.writer(fh, lineterminator="\n")`.
  - `ANALYSIS.md` changes one line, its l49. The C130 sentence now says the seal audit "checked only `ledger/parcel-w6augint.md`" and `ledger/verifier-w6augint.md`. (The verifier and the lead said l47. The revision had moved the sentence to l49.)
- **`search_record.py`, re-run** from a `git archive` export of `06f1a45` in the lead's folder, with no flags beyond its required arguments:
  - it exits 0;
  - its output is byte-identical to the committed `data/escape_search.csv` under a plain `cmp`;
  - its output holds no absolute path, and its redaction prints `<path>`.
- **P2's report:** its own re-run of all ten data-writing scripts left `data/` unchanged, and its gate gave 5 of 5 (164 files and 70 commit messages).

Decided: P2 is merged with `--no-ff` into `study-muse` once S0's gate on P3's merge has finished, so that each gate holds one merge. Its own gate follows.

For: anyone resuming; the report

## 2026-11-08 10:37:36 -0700 - lead: S0's gate on P3's merge (`aac740a`): PASS: 5 of 5 checks hold. P2 merged into study-muse next, as 10:32:22 set out

Measured: `gate-merge-p3.log`'s summary lines, with `SSL_CERT_FILE` removed by name.

For: anyone resuming

## 2026-11-08 10:37:57 -0700 - lead: P2 merged into study-muse (`43bebf0`), and the report's draft 1 placed beside the analyses. One gate covers both

Measured:
- **`43bebf04fac3ea2bb00d8784ec0eea384fc351fe` on `study-muse`,** `--no-ff` from `study-muse-p2` at `06f1a45`. It adds 28 files under `parcels/P2/`.
- **`Rounds/Muse-Softfloat-Study/REPORT.md`, draft 1,** is uncommitted in S0, with sha256 `a07768e2590c315febe0b95e720d8f38bfe38b1d3c8d399a1bbb4e777a078a31`.
  - Its figures were read by the lead's scripts from the parcels' final commits (`83a1889`, `06f1a45`, `5c8f4f9`), or are cited to a parcel's section.
  - The escapes' families (F1 14, none 10, C3 5, E1 2, F2 2) were recounted by the lead from `escapes.csv`.

Decided:
- **One gate runs** over the merge commit's tree with the report beside it. The merge's content is committed and fixed; the report is new.
- **The report is committed past that gate, with its hash held.** It then goes to a scoped verifier, verifier-R, on Haiku.

For: anyone resuming

## 2026-11-08 10:45:48 -0700 - lead: the gate on P2's merge and the report holds 5 of 5. The report's draft 1 is committed (`35873c2`), and verifier-R dispatched on Haiku

Measured:
- **S0's gate,** with `SSL_CERT_FILE` removed by name: 5 of 5.
  - tests: 805 passed, 40 skipped;
  - privacy: 245 files and 79 commit messages.
- **The report's sha256,** `a07768e2…8a31`, held from the gate run to the add.
- **`35873c2486bf1349ee06b29f92b678fb6122ba96` on `study-muse`** adds `REPORT.md`, 309 lines.
- **`briefs/verifier-R.md`** has sha256 `e92b420d827fae009a7077a1668537fc3d8ecf64b56873ce092e28f9d92318dd`.

Decided: verifier-R is dispatched for pass 1 on `35873c2`. The fence on the Claude audit reports holds until its verdict is answered.

For: verifier-R

## 2026-11-08 10:55:02 -0700 - lead: verifier-R's pass 1 on the report's draft 1 (`35873c2`): NOT READY, with no wrong figure, 8 restates and 9 notes. All 17 are taken in draft 2

Measured: the report is filed in `reports/verifier-R.md`. The lead checked the findings that turn on a source:
- **The owner column** of P2's `lead_errors.csv` gives 45 lead rows of 47.
- **The erratum's wording** (`docs/RECORD.md` from l1004 at `b78af18`): "8 early passes rows carry `sent_back: true` where the planted verdict was not a parcel revision round". So it names 8 as not revisions, and implies 7 that were, and names no row.
- **Row 170's note** in the library's `plants.jsonl` at `b78af18`, for verifier-w6metrics' plant 5: "coverage counted appended agents by expected list (5+11+19) without checking per-row wave fields".
- **The notes of rows 5 and 56:** the generator drift "seen ... but filed benign", and the verifier's "recomputation repeated the slip ... and endorsed it".

Decided:
- **All 17 are taken in draft 2.** The verifier's reading stands on each.
- **Three findings change what the report says, not only how strongly.**
  - **Q6's pattern.** It is stated by the artifact the plant altered, as P1 classes it. Two of the misses were values the verifier saw and accepted, so the report no longer says the misses were "claims whose meaning was wrong".
  - **The send-backs.** P1's split runs opposite to the erratum's, and the report now says so.
  - **The escapes.** They carry P2's limits on what a no-hit search shows.
- **verifier-R's pass 2,** its last, is scoped to the diff.

For: verifier-R; Logan

## 2026-11-08 11:03:40 -0700 - lead: the report's draft 2 committed (`3aae2b2`), past the gate. verifier-R resumed for pass 2, scoped to the diff

Measured:
- **`3aae2b2caa58194878c17d4c5ea6e2d09a595e91` on `study-muse`,** on `35873c2`. It changes `REPORT.md`, 79 insertions and 35 deletions.
  - Its sha256, `5049c58b…b1eb1`, held from the gate to the add.
- **S0's gate:** 5 of 5, with `SSL_CERT_FILE` removed by name.
  - privacy: 245 files and 80 commit messages.
  - The gate first ran detached, by the lead's own slip of backgrounding it twice. Its end was then waited on by a polling loop on its log.

Decided: verifier-R's pass 2, its last, re-checks `git diff 35873c2 3aae2b2`. It confirms each of its 17 findings is answered, and that the new lines add no error.

For: verifier-R

## 2026-11-08 11:06:50 -0700 - lead: verifier-R's pass 2 on draft 2 (`3aae2b2`). Every pass 1 item is answered and no figure is wrong, but there are five small new faults. The lead fixes them in draft 3 and checks them by command. The fence lifts at draft 3's commit

Measured: verifier-R's pass 2 is filed in `reports/verifier-R.md`. Its five faults and the lead's fixes, each found exactly once and replaced by a script:
1. **"The lead's seam"** is no source's word, and correction row 7 is a smoke control. Now: "the lead's own code or tool faults in its first phase (correction rows 4 to 7, among them a smoke control)".
2. **"The final audit"** for `audit-full/`, four times. Now "the full audit", which is P2's term. "The final and seal audits" in Q3's limits stays: those are the adherence audits.
3. **"distrust a value it has recomputed itself"** had no source. Now "catch a slip it repeats in its own recomputation (row 56)".
4. **The wrong-tree attempt's exposure** is now cited to `<muse>/ledger/lead.md` l876.
5. **"the allowlist P2 asks for"** is now "the allowlist the case report's P2 asks for".
   - The same ambiguity ran through Q5, so the case report's proposals there are now written "proposal P2" and so on.
   - A grep of every remaining bare "P1" to "P3" finds only this study's parcels.

Decided:
- **verifier-R's passes are spent,** and Logan's 2026-10-02 rule caps the loop. Draft 3's change was checked by the lead, not by a verifier, and the report says so.
- **Draft 3 is committed past the gate.** At that commit the draft is verified, as the plan's §5 and §6 require for lifting the fence.
- **The lead then lifts the fence for itself alone,** reads the Claude audit reports, and writes the comparison. That comparison goes to its own scoped verifier.

For: anyone resuming; the report

## 2026-11-08 11:12:13 -0700 - lead: the report's draft 3 committed (`6002f90`), past the gate. The fence on the Claude audit reports is lifted, for the lead alone

Measured:
- **`6002f90d5dfb1f044018957ab407fb56e633add0` on `study-muse`,** on `3aae2b2`. It changes `REPORT.md`, 18 insertions and 14 deletions.
- **S0's gate:** 5 of 5 (805 passed, 40 skipped; privacy 245 files and 81 commit messages), with `SSL_CERT_FILE` removed by name.

Decided:
- **The report's draft is verified,** as the plan's §5 requires: two passes by verifier-R, and the lead's check of the last delta.
- **The fence is lifted for the lead alone,** as §5 says.
  - The lead may now read the library's `audit-bundle/` and `audit-bundle-v2/` at `b78af18`, for the Claude audit reports, and write the comparison.
  - For every other agent the fence still holds.
  - The comparison's verifier is given only the files the comparison cites.

For: anyone resuming

## 2026-11-08 11:13:44 -0700 - lead: the Claude audit reports are not in the local clone. They are on three branches on GitHub only. The lead asks Logan before downloading them

Measured:
- **Not in the bundles:** `audit-bundle/` and `audit-bundle-v2/` at `b78af18` hold the kit, the ledger, the plant keys, the agents' reports and the lead's scripts. They are evidence frozen for auditors, and no file in them names Claude.
- **The Muse lead's ledger,** l856: "Owner mid-seal: three Claude audit branches exist, not to be looked into".
- **The library's local clone** has 47 refs, none of them a Claude branch.
- **`git ls-remote --heads origin`** (ref names only; nothing fetched or written) lists 8 heads on GitHub. Three are `claude/affectionate-curie-lrfomb` (`e8e77d7`), `claude/gifted-hawking-w4r6fu` (`9db8763`) and `claude/loving-carson-qmwhhz` (`f2ed688`).

Decided:
- **Reading them is a download,** and the study's rules forbid fetching into the Muse repository.
- **So the lead asks Logan** whether to fetch the three branches into a bare clone of its own, in the lead's folder:
  - shallow, at depth 1, with no file contents (`--filter=blob:none`) beyond the report files read;
  - never touching the Muse repository.

For: Logan

## 2026-11-08 12:22:43 -0700 - lead: Logan approves the download of the three Claude audit branches

Logan, through the question tool, verbatim: "Yes, fetch them (Recommended)". The option read: a shallow, blob-less fetch of those three branches and `main`, from github.com/loganw234/muse-softfloat, into a new bare clone in the lead's folder, with the Muse repository never touched.

Decided:
- **The fetch:** `<repos>/honestharness-muse-lead/muse-remote.git`, a new bare repository with the remote `origin`. It fetches `main` and the three `claude/*` branches with `--depth=1 --filter=blob:none`.
- **Afterwards:** the tips are checked against the `ls-remote` values, and the clone's size is recorded here.

For: anyone resuming

## 2026-11-08 12:28:59 -0700 - lead: the Claude audits read, and the comparison written. The report's Q4 is corrected after it. Both go to a scoped verifier, verifier-C

Measured:
- **The fetch** (12:22:43) gave a bare clone of 123,768 bytes. Its tips match `ls-remote`: `e8e77d7`, `9db8763`, `f2ed688` and `main` `b78af18`.
- **Each Claude branch adds one audit.**
  - The audits, by sha256:

    | Branch | Audit | sha256 |
    |---|---|---|
    | `claude/affectionate-curie-lrfomb` | `docs/AUDIT-2026-10-31.md` | `c949754c…6838` |
    | `claude/gifted-hawking-w4r6fu` | `audit-2026-10-31/REPORT.md` | `1eac3e13…e2147` |
    | `claude/loving-carson-qmwhhz` | `docs/audit/2026-10-31-audit-report.md` | `76b0a55e…9ef5` |

  - Each is dated 2026-10-31, at `main` `a2241fc`.
  - Copies for the comparison's verifier are in `<repos>/honestharness-muse-claude-audits/`, which is not published. The owner's address appears in none of them. The home-path fragment appears 2 and 4 times, in A and B.
- **Two of A's findings, checked by the lead by command:**
  - **M10.** `docs/metrics/corrections.jsonl` rows 17, 18 and 19 at `b78af18` are verifier-sf2's plants #4, #3 and #2 (`plants.jsonl` rows 59, 58 and 57), landed as accepted corrections. P2's `lead_errors.csv` counts them as the lead's SF-2 draft errors, `CJ17` to `CJ19`.
  - **H1's citation.** `<muse>/ledger/lead.md` l303 reads "No planted-copy verification was run for this branch".
- **The comparison,** `Rounds/Muse-Softfloat-Study/COMPARISON.md`, maps the audits' High and Medium findings against the Muse full audit, the case report and this study. Each cell was checked against the reports' finding IDs by grep: two of the lead's cells were corrected before the commit, and one ID was added.
- **The report's draft 4** corrects Q4. 42 of the 47 error rows are the lead's own genuine errors, and the 3 plants landed as corrections are a record error besides.

Decided:
- **The report's draft 4 and the comparison are committed past the gate.**
- **verifier-C,** on Haiku, checks the comparison against the three reports and the study's sources, and the report's Q4 correction. Two passes at most.

For: verifier-C; Logan

## 2026-11-08 12:36:15 -0700 - lead: the comparison and the report's draft 4 committed (`bc058e5`), past the gate. verifier-C dispatched on Haiku

Measured:
- **`bc058e5e89b36ae9f5707815c44d769ae547bc1e` on `study-muse`,** on `6002f90`. It changes 2 files, 140 insertions and 3 deletions.
  - The two files' sha256 values held from the gate to the add.
- **S0's gate:** 5 of 5 (805 passed, 40 skipped; privacy 246 files and 82 commit messages), with `SSL_CERT_FILE` removed by name.
- **`briefs/verifier-C.md`** has sha256 `e1cb66c1073cf616cfa150ac0244dc47ee28be58bd67f1ed2a42eefd0b6a351b`. For this work alone, it lifts the fence on the Claude audit copies.

Decided: verifier-C is dispatched for pass 1 on `bc058e5`.

For: verifier-C

## 2026-11-08 13:02:05 -0700 - lead: verifier-C's pass 1 on `bc058e5`: NOT READY, with 5 wrong, 5 restates and 10 notes. All are taken, with three more errors of the lead's found while checking them. The comparison's draft 2 and the report's draft 5 follow

Measured: the report is filed in `reports/verifier-C.md`. The lead checked each finding against its source, by command:
- **W1.** P2's `escapes.csv` row M3 has `escape=no` and `own_verification=partly`. Its evidence cell cites verifier-w5attr's report l41, which raised the value 5, and verifier-w5aug's report l120, which cleared it.
- **W2.** Row N17 has `escape=yes`, family F1.
- **W3.** Claude C's L11 reads "`site/data.json`'s base commit predates the counts it shows."
- **W4.** `<muse>/ledger/lead.md` l876 holds the voided attempt, under l874's heading dated 2026-11-01. The first 2026-11-02 heading is l889.
- **W5.** P2's ANALYSIS l99-101:
  - the final and seal adherence audits say they never opened `lead.md`;
  - the first read its 101 headings and sampled its bodies.
  - The full audit's header lists its fences, and `lead.md` is not among them.
- **R1.** Row A03 has `own_verification=raised` and `escape=no`. `grep -i ias15` finds nothing in the report.
- **R2.** Claude A's summary names two "real library defects", M8 and M7.
- **R3 to R5** rest on the comparison's own lines and hold.
- **The notes:**
  - N1: C L13 is the repository's weight, 96% of a 273 MiB pack being MP4.
  - N2: B F-05 is mutation testing across the suite.
  - N3: row N6 is the symbol scan's SKIP-BY-NAME returning 0.
  - N4: row M4 is the bench budget that cannot complete.
  - N5: the case report l342-347 and row A27 hold.
  - N6: the full audit's header does not name the host's operating system.
  - N7: a script over `lead_errors.csv` gives 45 lead-owned rows, and 42 without `CJ17` to `CJ19`.
  - N8: the report's l232-233 read as verifier-C quotes them.
  - N9: by the lead's grep, A has 2 matching lines and 2 matches, and B has 4 lines and 5 matches. The 12:28:59 entry's "2 and 4 times" counted lines.
  - N10: Claude A's "22 rows" is at `a2241fc`.
- **Three more errors of the lead's, found by reading P2's whole table** (79 rows: the full audit's 43 findings and the adherence audits' 36 slips):
  - **The media weight** is the Muse full audit's N22 (minor). The comparison listed it as found only by the Claude audits.
  - **The protocol claims, A H1,** were found by the Muse adherence audits too:
    - the slips A01, A02, A03 and A06, and the false universals A16 and A32;
    - A H1 itself cites the final adherence audit's grade "STILL OPEN", from the bundle;
    - B F-17 (a) and C L12 carry it as well.
    - The comparison listed it as found only by the Claude audits.
  - **The comparison's "Muse full audit" column** cited an adherence audit's slip under the full audit's name.
- **Smaller faults of the lead's own:**
  - **The record-integrity framing** credited `lead.md` with A M10. A M10 came from the metrics and the plant record, and A M11's claim that the project's auditors never opened the ledger fails for the first adherence audit.
  - **The stack figure:** A measures about 2.4 KiB, and B about 3 KB.
  - **"No other agent of the study has read them"** stopped being true when verifier-C read the copies.
  - **The 12:28:59 entry's "maps the audits' High and Medium findings"** overclaims. By a script over the copies, the comparison cites every High, but only 14 of A's 18 Medium findings, 11 of B's 14 and 7 of C's 9.

Decided:
- **COMPARISON.md draft 2** takes W1 to W5 and R1 to R5 as asked, and the notes.
  - It moves the media weight and the protocol claims into the table of what every side found.
  - It renames the Muse column "Muse audits", cited by P2's IDs, and gives the adherence audits a row in the audits table.
  - Its Limits say it is a selection, with the counts above.
  - N10 needs no change beyond naming A's commit for A's counts.
- **REPORT.md draft 5** takes N7 and N8:
  - it amends Q4's first lines in place, to 42, and 19 of the 22 corrections;
  - it gives 42's source.
  - It also names the IAS15 parcel's unverified merge in Q1, since the comparison found it missing.
- **verifier-C's ledger file, l67,** quotes a fragment of the owner's home path in note N9. The ledger stays append-only. The copy archived with the study carries that line redacted, with a note saying so.
- **After the gate and the commit,** verifier-C gets its pass 2, its last, scoped to the diff from `bc058e5`. If faults remain after it, the lead fixes them, checks each by command, and says so.

For: verifier-C; Logan

## 2026-11-08 13:16:42 -0700 - lead: the comparison's draft 2 and the report's draft 5 committed (`23b0267`), past the gate. verifier-C resumed for pass 2, its last

Measured:
- **`23b0267fce2c771b469ef200cd572e24f80ffd96` on `study-muse`,** on `bc058e5`. It changes 2 files, with 75 insertions and 47 deletions.
  - The two files' sha256 values held from the gate to the add: `COMPARISON.md` `e84c323e…` and `REPORT.md` `738bf900…`.
  - The commit message was scanned for paths and addresses before the commit, with no hit.
- **S0's gate:** 5 of 5 (805 passed, 40 skipped; privacy 246 files and 83 commit messages), with `SSL_CERT_FILE` removed by name.
  - The tests took 11 min 43 s, past the shell tool's 10-minute limit. The tool moved the run to the background, and the lead waited for its notice and started no second run.

Decided:
- **verifier-C is resumed for pass 2 on `23b0267`.** It is scoped to the diff from `bc058e5` for `COMPARISON.md` and `REPORT.md`, and covers both:
  - how each pass 1 finding landed;
  - the lead's own additions, checked as the rest were.
- **The rules of pass 1 hold,** with one addition: no pattern that names the owner's home directory is written anywhere, not even as a regex.

For: verifier-C

## 2026-11-08 13:25:50 -0700 - lead: verifier-C's pass 2, its last, on `23b0267`: NOT READY, on one restate and four notes. Every pass 1 finding landed. The lead takes all five in the comparison's draft 3 and checks each by command, since verifier-C's passes are spent

Measured:
- **verifier-C's pass 2** is filed in `reports/verifier-C.md`. It found every pass 1 finding landed, and the lead's own additions right, except for these:
  - **R6:** "the Muse adherence audits came first" is false for P2's A32, which came from the seal audit (2026-11-01);
  - **N11:** "Two columns lean on the full audit" did not name them;
  - **N12:** P2's A06 is a key-hash slip, not a claim about a verifier before each merge;
  - **N13:** the prefix A served both Claude audit A and P2's slips;
  - **N14:** two supported details were dropped, Wave 1's merges before their verdicts and the IAS15 citation at l303.
- **The lead checked each by command:**
  - **P2's `escapes.csv`, its `from` column:**
    - A01, A02, A03, A06, A14 and A16 came from A2;
    - A27 and A32 from AS;
    - A36 from AF.
  - **The three adherence reports' headers:** A2 froze at `7c3819c` on 2026-10-28, AF at `bc807e6` on 2026-10-29, and AS at `751d1d6` on 2026-11-01. The Claude audits are dated 2026-10-31.
  - **`<muse>/ledger/lead.md` l303** holds "No planted-copy verification was run for this branch".
  - **A script over the comparison:** every slip ID outside the Muse column carries "P2's", or follows one in a pair or a range.
- **The home-path line counts in Limits** (2 and 4 lines) were not re-checked by verifier-C, since the rule now forbids writing the pattern.
  - The lead counted them by command this session: A has 2 lines and 2 matches, and B has 4 lines and 5 matches.
  - The match counts agree with verifier-C's pass 1. The line counts are the lead's alone.

Decided:
- **COMPARISON.md draft 3:**
  - **R6:** the protocol paragraph now says the earliest Muse audits came first, and that the seal audit's slip came after the Claude audits;
  - **N14:** it restores Wave 1's merges and the IAS15 citation at l303, with P2's IDs;
  - **N12:** the protocol row is retitled after A H1's own title, the public claims about the verification protocol, so P2's A06 fits it under the defects pre-ledgered;
  - **N11:** the sentence names the two kinds of cell that lean on the full audit;
  - **N13:** outside the Muse column, a slip is written "P2's A01", and the sources paragraph says so.
- **These last changes are the lead's,** checked by command, as Logan's rule of 2026-10-02 provides. There is no third verifier pass.
- **REPORT.md needs no change** from pass 2.
- **After the gate and the commit,** the close-out follows:
  - the harness notes;
  - Logan's OK to publish;
  - the archive;
  - the merge and the push.

For: Logan

## 2026-11-08 13:39:25 -0700 - lead: the comparison's draft 3 committed (`6bc1994`), past the gate. The harness notes are written, with a slip of the lead's in writing them, and go to a verifier, verifier-N. The archive's dry run is clean

Measured:
- **`6bc19948d89fe4eff42f9caf969872c4a9999586` on `study-muse`,** on `23b0267`. It changes 1 file, with 22 insertions and 10 deletions.
  - `COMPARISON.md`'s sha256 (`0077f7fd…`) held from the gate to the add.
  - The commit message was scanned before the commit, with no hit.
- **S0's gate:** 5 of 5 (805 passed, 40 skipped, in 9 min 52 s; privacy 246 files and 84 commit messages), with `SSL_CERT_FILE` removed by name. It ran in the background from the start.
- **A slip of the lead's:** it wrote `harness-notes.md` into S0 while that gate was running.
  - It moved the file out to its own folder at 13:28:55, during the tests.
  - The privacy check read 246 files, as at the last gate, so it did not read the draft. The commit holds only `COMPARISON.md`.
- **How verifier-C's first report was filed** (the notes' item 10):
  - It reached the lead just before a context compaction.
  - After the compaction, the lead extracted the report's verbatim text from this session's own transcript file, from the task notice that carried it, and filed it from there (13:02:05).
  - Pass 2's report was filed the same way, for exactness.
- **The harness notes,** `Rounds/Muse-Softfloat-Study/harness-notes.md`, hold ten notes, each citing its entries here. Two claims were checked by command first:
  - neither this repository's privacy patterns nor ParcelRound's (`tools/check_method.py` at `f42242e`) find anything on `verifier-C.md` l67;
  - the directory that lost its files was round 2's old scratch directory (08:19:53).
- **The archive's dry run,** by `build_archive.py` in the lead's folder, over this ledger as of 13:25:50:
  - one redaction: the pattern on `verifier-C.md` l67, replaced by a marker;
  - 38 files staged, with 0 hits by this repository's privacy patterns, 0 by the owner-home pattern, and 0 by ParcelRound's privacy check;
  - a zip of 38 members, read back and matched against each member's sha256.
  - By `diff -r`, the staged copy differs from the ledger only at that line.

Decided:
- **The harness notes are gated and committed on `study-muse`.** Then verifier-N, on Haiku, checks them against this ledger and the entry of round 2's that they cite. Two passes at most.
- **After verifier-N,** the lead asks Logan for his OK to publish. The study quotes the Muse records, the Claude audits' summaries, and Logan's own answers in this ledger.
- **On his OK:**
  - this ledger takes its last entry;
  - the archive is built from it, as the dry run was;
  - `study-muse` merges into main;
  - main is pushed after the gate and a whole-repository privacy scan.

For: verifier-N; Logan

## 2026-11-08 13:56:42 -0700 - lead: the harness notes committed (`752d39f`), past the gate. verifier-N dispatched on Haiku

Measured:
- **`752d39fbe661226836a96a4a39179a776dfa35b3` on `study-muse`,** on `6bc1994`. It adds 1 file, `Rounds/Muse-Softfloat-Study/harness-notes.md`, with 48 lines.
  - Its sha256 (`d77f6294…`) held from the gate to the add.
  - The commit message was scanned before the commit, with no hit.
- **S0's gate:** 5 of 5 (805 passed, 40 skipped, in 15 min 16 s; privacy 247 files and 85 commit messages), with `SSL_CERT_FILE` removed by name, in the background from the start.
- **`briefs/verifier-N.md`** has sha256 `5750c403cc9e6e63450d2cfa1270a1a712d67e3d75c9ebeb0daf5aa28965405d`.
  - It reads round 2's ledger for one entry only, 2026-10-26 10:04:27.
  - It keeps the Claude audit copies closed, and forbids any search for line 67's pattern.

Decided: verifier-N is dispatched for pass 1 on `752d39f`.

For: verifier-N

## 2026-11-08 14:06:42 -0700 - lead: verifier-N's pass 1 on `752d39f`: NOT READY, with no wrong fact, four restates and some omissions. The notes' draft 2 takes all but one. P2 did meet the refusal, by its own file. The report's draft 6 takes the report channel's lines

Measured: verifier-N's pass 1 is filed in `reports/verifier-N.md`. The lead checked each finding against the entries:
- **Note 1:**
  - The files were built from the parts, with each header line stripped and the parts joined with one blank line (09:36:39, 09:38:17 and 09:41:11).
  - P3's committed file differs from the lead's assembly in one line, which is P3's disclosed correction (09:48:41).
  - The revisions went by the lead's line relay for P1 and P2 (10:07:34, 10:10:17), and by P3's own Edit (10:06:34).
  - The read-backs are in the parcels' own files: P3's at 09:46:32, P1's at 09:47:27, and P2's at 09:51:12. P1 and P2 checked structure, not bytes.
- **Note 1's omissions hold:**
  - P1's refusal included a draft in its scratch directory (09:41:11);
  - the harness's boundary falls between working files and report-like prose (09:34:05);
  - an Edit to an existing file was accepted (10:06:34).
- **Note 3:** 10:00:16 says the style was fenced from the other verifiers by instruction alone. No entry records a verifier reading another's file.
- **Note 5:** the lead's entries record the variable as removed for each S0 gate. `briefs/_common.md` l170 gives the parcels the same command, but their reports of their gates do not say how they ran them.
- **Note 6:** 11:03:40 records the gate that ran detached, and the polling loop.
- **Note 9:** the 13:02:05 entry names no command.
  - The lead counted lines with `grep -c`, and matches with `grep -o` piped to `wc -l`.
  - Both used one pattern, which is not written here.
- **The omitted practices hold:**
  - the line relay (10:07:34, 10:10:17);
  - the write into S0 during a gate (13:39:25);
  - the copies built and keyed by the lead's script (09:48:41, 09:50:30 and 09:52:36);
  - the fence lift and the fetch (11:12:13, 11:13:44 and 12:22:43).
- **One finding does not hold.** verifier-N found no entry for a refusal of P2's.
  - P2's own file has one: "P2: ESCALATION, the harness refused ANALYSIS.md" (09:34:00).
  - So the report's "Three parcels and one verifier met the refusal" stands. verifier-N looked for it in the lead's ledger alone.

Decided:
- **`harness-notes.md` draft 2** takes the four restates and the omissions:
  - note 1 is rewritten;
  - notes 3, 5, 6 and 9 are restated;
  - notes 11 to 13 are added.
- **`REPORT.md` draft 6:** the report channel's lines cite the four refusals, P2's own file among them, and say how the files were built and read back. Its "verbatim" goes.
- **After the gate and the commit,** verifier-N's pass 2, its last, is scoped to the diff from `752d39f`, for both files.

For: verifier-N; Logan

## 2026-11-08 14:20:38 -0700 - lead: the notes' draft 2 and the report's draft 6 committed (`8d2c711`), past the gate. verifier-N resumed for pass 2, its last

Measured:
- **`8d2c7119f320fffc1a3ba66cf2dbadd8d8797119` on `study-muse`,** on `752d39f`. It changes 2 files, with 46 insertions and 16 deletions.
  - The two files' sha256 values held from the gate to the add: `harness-notes.md` `619434c2…` and `REPORT.md` `20075f28…`.
  - The commit message was scanned before the commit, with no hit.
- **S0's gate:** 5 of 5 (805 passed, 40 skipped, in 11 min 46 s; privacy 247 files and 86 commit messages), with `SSL_CERT_FILE` removed by name, in the background from the start.

Decided:
- **verifier-N is resumed for pass 2 on `8d2c711`.** It is scoped to the diff from `752d39f` for both files, and covers how each of its findings landed, including the one that did not hold.
- **The rules of its pass 1 hold.**

For: verifier-N

## 2026-11-08 14:24:39 -0700 - lead: verifier-N's pass 2, its last, on `8d2c711`: NOT READY, on three restates and two notes. The lead takes all five in the notes' draft 3 and the report's draft 7, and checks each by command, since verifier-N's passes are spent

Measured: verifier-N's pass 2 is filed in `reports/verifier-N.md`. It found its pass 1 findings landed, and agreed that its claim about P2 did not hold. It left five points, which the lead checked by command:
- **P3's read-back.**
  - P3's entry of 09:46:32 gives sha256 `452a4064…`, the hash of the file the lead wrote (09:36:39).
  - P3's committed file at `24cce6d` hashes `51cbbaee…`, after P3's own one-line change (09:48:41).
  - So P3 read back the lead's file, then changed a line. P1's and P2's read-backs give the lead's hashes (the lead's 09:41:11 and P1's own file, 09:47:27; the lead's 09:38:17 and P2's own file, 09:51:12).
- **Note 9's commands.**
  - The lead's account of them is at 14:06:42, after both counts. No entry records the command of the 12:28:59 count.
  - The 13:02:05 counts are the lead's, by `grep -c` and by `grep -o` piped to `wc -l`, as 14:06:42 says.
- **Note 12's check.** The lead read `make_copy.py`, in its folder: at lines 84 to 103 it lists the files that differ from the parcel's commit, and exits with "CHECK FAILED" unless they are exactly the planted files. The entries record the counts it found:
  - 3 of 38 files for P3 (09:48:41);
  - 2 of 42 for P1 (09:50:30);
  - 3 of 28 for P2 (09:52:36).
- **The report's l351.** The parts were also joined with one blank line (09:36:39, 09:38:17 and 09:41:11).
- **Note 5's times.**
  - 16 entries name the variable: 08:11:55, which sets the rule, and the gate entries from 08:17:33 to 14:20:38.
  - P1's and P3's ledger files name the command as a next step: P1's at l213, P3's at l125. No parcel's record of a gate says how it ran.

Decided:
- **`harness-notes.md` draft 3:**
  - note 1 says each parcel read back the file the lead wrote, and P3 then changed one line;
  - note 9 dates the lead's account of its commands to 14:06:42;
  - note 12 cites the script's check and its three counts;
  - note 5 cites its entries.
- **`REPORT.md` draft 7:** the report channel's lines say the parts were joined with one blank line, that each parcel read back the file the lead wrote, and that one changed a line after.
- **These last changes are the lead's,** checked by command, as Logan's rule of 2026-10-02 provides. There is no third verifier pass.
- **Then:** the gate, the commit, and Logan's OK to publish.

For: Logan

## 2026-11-08 14:49:33 -0700 - lead: Logan's OK to publish, "Publish as they are"; the study closes. The notes' draft 3 and the report's draft 7 committed (`40d4f47`), past the gate. The ledger is archived beside the study, `study-muse` merges into main, and main is pushed

Logan's answer:
- **When:** through the question tool, between 14:24:39 and 14:48:53 -0700 (the last entry before the question, and the lead's next clock reading).
- **The question began:** "The muse-softfloat study is finished and verified. Should I merge it into HonestHarness's main and push it to GitHub?"
- **It went on to name:**
  - what the merge adds;
  - what the study quotes, his own words among them: his opening message and his four answers, verbatim;
  - what stays out: the Claude audit copies and the lead's folder;
  - the privacy scans' 0 hits, and the one ledger line blanked in the archive.
- **He answered, verbatim:** "Publish as they are (Recommended)".
- **That option read:** "I build the ledger archive, merge study-muse into main, run the gate and a whole-repository privacy scan, then push main to GitHub as a fast-forward."

Measured:
- **`40d4f4713eef454caad435bc119b3ffe0365a0b9` on `study-muse`,** on `8d2c711`. It changes 2 files, with 14 insertions and 12 deletions.
  - The two files' sha256 values held from the gate to the add.
  - The commit message was scanned before the commit, with no hit.
- **S0's gate:** 5 of 5 (805 passed, 40 skipped, in 6 min 28 s; privacy 247 files and 87 commit messages), with `SSL_CERT_FILE` removed by name, in the background from the start.

Decided, the study's close:
- **This is the ledger's last entry before its archive.** The archive goes beside the report as `Rounds/Muse-Softfloat-Study/muse-study-ledger.zip`. `muse-study-ledger.manifest.json` gives each member's size and sha256, and the archive's own sha256.
  - It is built by `build_archive.py`, as the dry run of 13:39:25 was: members in sorted order, fixed timestamps of 2026-11-08, and mode 0644.
  - `verifier-C.md` l67 is redacted in the archived copy, as 13:02:05 set out. Nothing else is changed.
  - Before the zip is written, every file passes three scans: this repository's privacy patterns, the owner-home pattern and ParcelRound's privacy check.
  - The archive's sha256 is in the commit that adds it.
- **`study-muse` then merges into main** with a merge commit, after the gate holds at `study-muse`'s tip.
- **main is pushed** as a fast-forward of `origin/main`, by the standing push rule. It goes after the gate on main, and after a whole-repository privacy scan with zero hits. No other branch or tag is pushed.
- **What stays local:**
  - the Claude audit copies, `<repos>/honestharness-muse-claude-audits/`, which carry home-path fragments;
  - the lead's folder, `<repos>/honestharness-muse-lead/`: its drafts, logs, held reports, scripts, the bare clone and the copies of the keys;
  - this ledger, `<repos>/honestharness-muse-ledger/`, whose published copy is the archive.
- **Logan's to delete, when he chooses:**
  - under `<repos>/honestharness-worktrees-muse/`:
    - the parcels' worktrees P1 to P3, with their branches `study-muse-p1` to `study-muse-p3`;
    - the planted copies vP1 to vP3;
    - S0 and its branch `study-muse`, once merged;
  - the bare clone `<repos>/honestharness-muse-lead/muse-remote.git`;
  - the Claude audit copies.
- **Round 2 stays paused,** as before.

For: Logan; the archive
