
## 2026-11-08 08:52:16 -0700 - verifier-PL2: provenance. Draft 3 at 0080bef

Measured:
- `GIT_OPTIONAL_LOCKS=0 git -C <repos>/HonestHarness rev-parse 0080bef5e45f74ee9aad32573020af5d53b00438` prints `0080bef5e45f74ee9aad32573020af5d53b00438`.
- A line new in draft 3, from `git -C <repos>/HonestHarness diff 3345fbd769b74570cfb620bdee70db34ce214c87 0080bef5e45f74ee9aad32573020af5d53b00438 -- Rounds/Muse-Softfloat-Study/PLAN.md` (saved as `<scratch>/verifier-PL2/delta.diff`, 96 lines): "- **Draft 3** takes all seven, each checked first by command. verifier-PL's"
- The plan at 0080bef is 336 lines (`wc -l` of its `git show` output, saved as `<scratch>/verifier-PL2/plan_d3.md`).
- The HonestHarness working checkout is on `main`: `git rev-parse HEAD` prints b69ed7613bdb655fb4b42acd1517b0b30631af7a. Every read of the plan is a `git show` or `git diff` at a commit.
- Order of reads. Before any check I read the brief, then `<repos>/honestharness-muse-ledger/` at its top level (README.md, briefs/, lead.md, reports/, verifier-PL.md), then `lead.md` and `reports/verifier-PL.md`. My first checks came after those reads. This entry is my first write to this file, so it comes after those checks begin. I did not read `briefs/verifier-PL.md`, which is outside my scope.
Believed: the copy I read is the plan of record at 0080bef.
For: verifier-PL2; the lead

## 2026-11-08 08:52:46 -0700 - verifier-PL2: delta check, draft 2 to draft 3: NOT READY on one restate (the audits row, line 138) and a partly taken pass 2 item; notes 2 to 4; no wrong fact

Measured (each by the command named; all reads of sources at commits or as files, with directories named):

Pass 2 items, as draft 3 answers them:
- **Item 1, the bench attempts: answered rightly.** `git show b78af1801d3e2bd123fed82d933414af661a9e9a:docs/metrics/plants.jsonl` in `<muse>/muse-softfloat`, read by a script: 5 rows named `verifier-psbench2`; all carry key_sha256 prefix `0305f97a`; all caught; notes F-TABLE, F-README, F-RATIO, F-SEED, F-LEGEND. `<muse>/ledger/lead.md` line 876 says "ATTEMPT A VOID: verifier-psbench2", and attempt B is "verifier-psbench2b", caught 5/5 on the same five findings. Also, 5 rows named `verifier-psbench` carry key prefix `c7e98cc5`; they appear to belong to the first bench run, not to either attempt (see note 4).
- **Item 2, Logan's words: answered rightly.** `<repos>/honestharness-muse-ledger/lead.md` line 7 reads "than Opus level alot of the prior samples came from." The changed line 52 is a paraphrase introduced by "As Logan's message says", with no quotation marks. It is faithful.
- **Item 3, cached tokens: answered rightly.** `usage.jsonl` at b78af18 (128 rows, read by a script): cached_tokens sum 1,379,156,504; rows where cached exceeds input: 0; input sum 1,410,803,658; output sum 7,261,540; input plus output 1,418,065,198. Negative check, `git -C <muse>/muse-softfloat grep -n -i cached b78af18 -- docs tools ':!docs/metrics'`: RECORD.md line 131 (a column), HARNESS.md line 40 ("input/output/cached tokens"), and `tools/extract_session_metrics.py` lines 18 to 23 (cached_tokens taken verbatim; no statement of inclusion). The kit's `METRICS.md` line 11 lists "tokens (output, input, cached)". None defines whether cached is inside input. The changed lines are right.
- **Item 4, the auditors: partly answered.** `usage.jsonl` at b78af18 has six `auditor-*` agents with rows: `auditor-adherence-2` on muse-wonder-full-1.0; `auditor-adherence-final`, `auditor-final`, `auditor-staleinfo-spark`, `auditor-wave1`, `auditor-wave2` on muse-spark-1.3. `auditor-adherence-seal` has no row. RECORD.md line 1251 is the seal header and lines 1252 to 1253 say "auditor-adherence-seal graded the SF-2-close -> seal span ADHERENT WITH SLIPS". See finding 1.
- **Item 5 (note 5 of pass 2), the toy's "(verifier-PL)":** removed. Done.
- **Item 6 (note 6), the a and b classes:** taken. See finding 2.
- **Item 7 (note 7), the "not recorded" fallback:** taken at line 65. It is the lead's decision and is not a source fact.

Changed lines, checked against their sources:
- Line 60, the toy row: `git -C <muse>/muse-softfloat-toy show 084f98b29e292d0674dfa4eb9fe119c3990c726d:docs/metrics/plants.jsonl`, read by script: 90 rows; 44 `dispatched` (44 distinct copy_head); 44 `verdict` (caught 5 each, 220 in all, all caught, and `verifier_report` set in all 44); 2 `lead_trim`. Verdict rows have no per-plant shape. Right.
- Line 138: the seal's row has no usage row (above). `<muse>/ledger/auditor-adherence-seal.md` line 3 reads "Seal methods audit: ADHERENT WITH SLIPS at 751d1d6". Right as far as it goes.
- Lines 83 to 85, the kit's classes: `METRICS.md` line 30 reads "each verifier pass as (a), (b)". The `round_metrics.py` docstring says "a and b, the counts of its findings in each class". Both are true. But neither names the classes. The definitions are in `<muse>/softfloat-bootstrap-kit/ROLES.md` line 100 ("(a), a regression; (b), a wrong answer; or a note (GLOSSARY.md)") and `GLOSSARY.md` lines 27 and 28. See note 2.
- Lines 86 to 93, the attempts: right, as item 1 shows.
- Lines 71 to 75 (cached): right.
- Line 65 ("not recorded"): consistent with the lead's decision. Seven verifiers have neither a usage row nor a passes row, holding 35 plant rows: `verifier-psbench`, `-psbench2`, `-psciwindows`, `-psedge`, `-psreadme`, `-w6captions`, `-w6metrics`. The sentence at line 66 is right.

Findings:
1. **RESTATE, line 138 (the audits row).** "Six of the audit agents have usage rows, all on Muse models" is true of the six `auditor-*` names. But the row's folder list includes `audit-full/`, whose eight auditors (`<muse>/ledger/lead.md` line 879: "8 read-only auditors (library wonder, 7 Spark)") have no usage row under any name. `usage.jsonl` at b78af18 has no row for an `audit-full` auditor under a name I could match, and lead.md line 879 does not name the eight. So "the audit agents" reads as complete when it is not. The seal's provenance is also not stated. Pass 2 item 4 asked for two things: say six by usage row, and say where the seal audit's file came from before its contents are used. The first is done loosely. The second is not done. Fix: "Six `auditor-*` agents have usage rows, all on Muse models (`usage.jsonl` at b78af18). The eight full-audit auditors (lead.md line 879) and `auditor-adherence-seal` have none. The seal's grade is in `<muse>/ledger/auditor-adherence-seal.md` line 3 and RECORD.md line 1251; say who ran it before its contents are used."
2. **NOTE, lines 83 to 85.** The claim "the kit names the classes a and b" is true, but the two cites name only the labels and the counts. P1 item 4 should cite `ROLES.md` line 100 and `GLOSSARY.md` lines 27 and 28 for what (a) and (b) are, and say that a note is a third class and is not counted.
3. **NOTE, the seal and the fence.** RECORD.md lines 1252 to 1253 say the seal report is "frozen into audit-bundle v2", which is fenced. The plan's audit row names `<muse>/scratch/audit-adherence-seal/` as a source. Before any agent reads that folder, the lead should confirm who ran the seal audit and that the folder is outside the fence. I did not open the folder, `audit-bundle/` or `audit-bundle-v2/`.
4. **NOTE, P1 item 5.** Plant rows named `verifier-psbench` (5 rows, key prefix c7e98cc5, all caught, lead-merge) come from the first bench run. `lead.md` line 876 says that run's records were superseded. The tie-by-key rule covers them, but the plan names only the voided attempt and attempt B. Say that the first run's rows are a third set, keyed apart.

Believed: the changed lines are right except line 138, which needs the fix in finding 1. No changed line is a wrong fact. The verdict is NOT READY on that one restate. Findings 2 to 4 are notes for the lead. The lead's rule says a delta fault is fixed and reported, not looped. Nothing in the delta reopens the fence, but finding 3 needs the lead's answer.

Fence disclosure: I ran a grep, for the words "verdict" and "ADHERENT", over `<muse>/ledger/auditor-adherence-seal.md` before I knew its author. It is a Muse ledger file per the lead's notes, but I had not confirmed that. I opened no other file of the fenced kind. The listing of the kit's `reference/` folder showed a bundle, `QRO-Crate.bundle`. I did not open it.

Commands run (all with GIT_OPTIONAL_LOCKS=0; scripts run with `python -I` from `<scratch>/verifier-PL2/`):
- `git rev-parse` of b78af18, 084f98b and 0080bef.
- `git diff 3345fbd... 0080bef... -- Rounds/Muse-Softfloat-Study/PLAN.md`, to `<scratch>/verifier-PL2/delta.diff`.
- `git show 0080bef:Rounds/Muse-Softfloat-Study/PLAN.md`, to `<scratch>/verifier-PL2/plan_d3.md`.
- `git show` of b78af18's `docs/metrics/plants.jsonl`, `usage.jsonl`, `passes.jsonl` and `docs/RECORD.md`, and 084f98b's `docs/metrics/plants.jsonl`, saved to `<scratch>/verifier-PL2/`. Scripts `chk_lib.py`, `chk_usage.py`, `chk_toy.py`, `chk_toy2.py`, `chk_agents.py`, `chk_nousage.py`.
- `sed -n` on `<muse>/ledger/lead.md` (lines 868 to 884), `RECORD.md` lines 1249 to 1262, and `softfloat-bootstrap-kit/METRICS.md` lines 26 to 34.
- `python -I` over `softfloat-bootstrap-kit/tools/round_metrics.py` (its docstring and a regex for class words).
- `grep` over `softfloat-bootstrap-kit/METRICS.md`, `ROLES.md`, `GLOSSARY.md`, `WORKFLOW.md`, `BOARD.md`, `HARNESS.md`, and `ls` of the kit's top level, `method/`, `reference/`.
- `git grep -n -i cached b78af18 -- docs tools ':!docs/metrics'`, and a regex for inclusion wording in the same pathspec.
- `grep` of `<muse>/ledger/auditor-adherence-seal.md` (see the fence disclosure).
- `git cat-file -t 751d1d6` in `<muse>/muse-softfloat`: prints "commit".
- `grep -o` for the quoted words in `<repos>/honestharness-muse-ledger/lead.md` (lines 7 and 175 match "alot of the prior samples"), and a full read of that file with the Read tool.

Background processes: I started none, so none needs stopping.

For: the lead (fix line 138 before the plan goes to Logan; decide finding 3 before any agent reads the seal folder); verifier-PL2's report
