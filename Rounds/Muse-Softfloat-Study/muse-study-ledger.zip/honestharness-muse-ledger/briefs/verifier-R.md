# verifier-R: the study's report, draft 1 (the lead's own text)

You are a **verifier**, not an author. Your job is to try to *disconfirm* the
lead's report, and to report.
- **You must not fix anything.**
- **"Found nothing" is an acceptable, unpenalised answer.**

Read this ledger's README and `lead.md` first. Then read `_verifier.md` for the
standard; its planted-copy section does not apply to you.
- **Your ledger file:** `verifier-R.md`.
- **Your scratch directory:** `<scratch>/verifier-R/`.

## The work

`Rounds/Muse-Softfloat-Study/REPORT.md` on HonestHarness's branch
`study-muse`, at the commit your dispatch names. Read it at that commit with
`git show`. It is the lead's answer to the plan's six questions. It draws on:
- the three parcels' analyses, beside it under `parcels/`, each verified twice
  (`reports/`);
- the study's ledger and its gradings (`reports/grading-wave1.md`).

This text is the lead's own. The study's record says the lead's own text has
been its least-verified text, so read it as if it were wrong.

## What to check

1. **Every figure in the report.** Check each against its source:
   - a parcel's `ANALYSIS.md` or `data/` at the report's commit;
   - or the ledger, the gradings or the keys.

   Recount, by a short script of your own, every table in the report and every
   count it leans on.
2. **Every citation** of the form "P1 §2.3". Does that section say what the
   report says?
3. **Overclaims,** above all:
   - in Q6, which is meant to be field evidence and not a ranking;
   - in "What running this study showed about the methods".

   A sentence stronger than its source is a finding.
4. **Omissions that change a reading.** A limit a parcel states that the
   report drops, where dropping it makes a claim read stronger.

## Classing what you find

- **Wrong:** a figure or fact false against its source.
- **Restate:** a sentence stronger than its source.
- **Note:** anything else.

## Rules

- **The README's rules hold.**
  - Read-only.
  - Repositories at commits, with `GIT_OPTIONAL_LOCKS=0`.
  - Searches name their directories, and pathspec exclusion applies for the library repository.
  - The fence still holds: `audit-bundle/`, `audit-bundle-v2/` and the Claude audit reports.
  - No environment values.
  - No absolute paths in what you write.
- **Your first ledger entry is your provenance:** the report commit's SHA as `git rev-parse` prints it, and the report's first line, quoted.
- **Two passes at most.** This is pass 1.
- **Report.** Write your findings in your ledger file first. Then give your report as your final message: READY or NOT READY, each finding with its class, the report's line, the source's evidence and what it should say, and what you ran.
