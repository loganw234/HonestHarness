# verifier-C: the comparison, and the report's draft 4 correction (the lead's own text)

You are a **verifier**, not an author. Your job is to try to *disconfirm* the
lead's comparison, and to report.
- **You must not fix anything.**
- **"Found nothing" is an acceptable, unpenalised answer.**

Read this ledger's README and `lead.md` first, then `_verifier.md` for the
standard. Its planted-copy section does not apply.
- **Your ledger file:** `verifier-C.md`.
- **Your scratch directory:** `<scratch>/verifier-C/`.

## The work

At the commit your dispatch names, on HonestHarness's branch `study-muse`:
- `Rounds/Muse-Softfloat-Study/COMPARISON.md`;
- the draft 4 change to `Rounds/Muse-Softfloat-Study/REPORT.md`, which corrects
  Q4's count of the lead's errors.

Read both with `git show`, and the report's change with `git diff` against
`6002f90`.

The comparison maps the findings of three Claude audits of muse-softfloat
against three other sources:
- the Muse round's own full audit;
- the Muse lead's case report;
- this study.

## The fence, changed for you

The README's fence on the Claude audit reports is lifted for you, for this
work only. Read them as copies in `<repos>/honestharness-muse-claude-audits/`.
Their sha256 values are in `lead.md`'s entry of 2026-11-08 12:28:59. Check
them before you trust a copy.
- Never quote a home path from them in anything you write.
- `audit-bundle/` and `audit-bundle-v2/` stay fenced. The comparison does not
  rest on them.

## What to check

1. **Every cell of the comparison's tables, and every finding ID it cites.**
   - Does that report's finding say what the cell says?
   - Is a cell left blank because the report has no such finding, rather than
     because one was missed? Grep the report.
2. **The Muse side:**
   - the full audit's findings, in P2's `data/escapes.csv` at the commit, and in
     `<muse>/scratch/audit-full/REPORT.md`, which you may read;
   - the case report's observations, in `<muse>/CASE-REPORT-muse-softfloat.md`.
3. **The correction.**
   - Are rows 17 to 19 of the library's `docs/metrics/corrections.jsonl`, at
     `b78af1801d3e2bd123fed82d933414af661a9e9a`, verifier-sf2's plants? Read with
     `git show` at that commit, with `GIT_OPTIONAL_LOCKS=0`.
   - Does the report's draft 4 state the consequence rightly?
4. **Overclaims,** above all in "What it says about the methods and the roles".

## Classing, rules and report

These are as in `verifier-R.md`:
- **classing:** wrong, restate or note;
- **rules:**
  - provenance first, as the commit's SHA and one line of the comparison, quoted;
  - read-only;
  - repositories at commits;
  - no absolute paths in anything you write;
  - two passes at most, of which this is pass 1;
- **report:** your findings in your ledger file first, then READY or NOT READY as your final message, with each finding's class, its line and its evidence.
