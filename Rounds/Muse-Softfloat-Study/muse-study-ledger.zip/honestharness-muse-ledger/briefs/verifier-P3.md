# verifier-P3: P3's analysis, as a planted copy

Read `_verifier.md` first. You are **verifier-P3**.
- **Your ledger file:** `verifier-P3.md`.
- **Your scratch directory:** `<scratch>/verifier-P3/`.

**Time box:** about 2 hours for pass 1.

## The work

P3's analysis covers three things:
- the muse-softfloat case report's 18 proposals (P1 to P18), against the methods' text at the kit's pins;
- the toy round's practice of those proposals;
- whether HonestHarness's rounds 1 and 2 met the same failures.

Its brief is `briefs/P3.md`. Its tasks are in the plan's §6, under P3.

## Your copy

`<repos>/honestharness-worktrees-muse/vP3`. It is a repository whose last commit holds P3's work, with planted faults folded in. It is built on the approved plan, `5197b2ab64acd01fa99ada7b75d2b73e34b16472`.

- **The copy is yours to run in.** P3's scripts write their tables into `data/`, and running them there is how you reproduce them.
- **Afterwards,** `git -C <copy> diff --stat` and `git -C <copy> diff` show what a re-run changed against the committed copy. That diff is evidence.
- **Never commit** in the copy, and never touch any other repository's working tree.

## What to check

1. **Re-run P3's scripts,** in the order its `ANALYSIS.md` §8 gives. Run them from the copy's root, with `--repos <repos> --scratch <scratch>/verifier-P3/run`. Compare their output with the committed `data/` and with `ANALYSIS.md`.
2. **Check the counts.** Every count in `ANALYSIS.md` against the tables in `data/`:
   - `proposal_marks.csv` and `clause_marks.csv`;
   - `kit_use.csv`;
   - `toy_practice.csv`;
   - `honestharness_rounds.csv`.

   Recount by your own route, with a short script of your own in your scratch directory.
3. **Check the cited lines.** Open at its commit every citation the analysis leans on: the main table's quotes, and each "Key quote". Also open a sample of the rest. The sources are named in `ANALYSIS.md`'s opening paragraph.
4. **Run the control** that `ANALYSIS.md` §6 describes:
   - copy the cited tables into your scratch directory;
   - alter one quote and one line number;
   - run `cite_check.py` against them, by pointing its data directory at your copy of them if it allows, or by a small harness of your own;
   - see whether it reports the failures it claims to.
5. **Read for overclaims:** a sentence stronger than its tables or its sources.

## The sources P3 read

- ParcelRound at `f42242e`, and its branch `case-study-7` at `894d125`.
- HonestFramework at `65447fd`.
- The kit, under `<muse>/softfloat-bootstrap-kit/`.
- The library at `b78af18`: only `docs/KICKOFF.md` and `docs/RECORD.md`.
- The toy at `084f98b`.
- `<muse>/ledger/lead.md`.
- `<muse>/scratch/toy1/` and `toy2/`.
- HonestHarness `main` at `b69ed76` and `round2` at `8e392dd`.
- Round 1's archived ledger zip.
- Round 2's ledger directory, excluding `keys/`.
