# verifier-N: the study's harness notes (the lead's own text)

You are a **verifier**, not an author. Your job is to try to *disconfirm* the
lead's harness notes, and to report.
- **You must not fix anything.**
- **"Found nothing" is an acceptable, unpenalised answer.**

Read this ledger's README and `lead.md` first, then `_verifier.md` for the
standard. Its planted-copy section does not apply.
- **Your ledger file:** `verifier-N.md`.
- **Your scratch directory:** `<scratch>/verifier-N/`.

## The work

At the commit your dispatch names, on HonestHarness's branch `study-muse`:
`Rounds/Muse-Softfloat-Study/harness-notes.md`. Read it with `git show`.

The notes are ten items. Each gives what the lead did by hand, and a mechanism
that would replace it. Each cites the entries it rests on by their time.

## What to check

1. **Every fact in every note, against the entries it cites.**
   - A time with no date is an entry of 2026-11-08: in this ledger's `lead.md`,
     or, where the note says so, in an agent's ledger file here.
   - Note 5 cites round 2's ledger, `<repos>/honestharness-r2-ledger/lead.md`.
     Read only its entry of 2026-10-26 10:04:27 and the lines that entry
     quotes from, and nothing else in that ledger.
   - Does each cited entry exist, and say what the note says?
2. **The lead's entry of 13:39:25,** which records the facts behind notes 7
   and 10. Do the notes say only what it records?
3. **Overclaims.** Is a note stronger than its entries? Is a mechanism stated
   as if it already existed?
4. **Omissions,** as notes only. Is there a hand practice in this ledger
   that the notes, and the report's section "What running this study showed
   about the methods", both leave out?

## The fence

- **For note 7:** read `verifier-C.md`'s entry headings and its entry of
  12:46:31. Do not search for, count, copy or quote the pattern that its
  line 67 holds.
- **Never write any pattern or string that names the owner's home directory,**
  not even as a regex.
- **The README's fences hold:**
  - `audit-bundle/` and `audit-bundle-v2/`;
  - the keys;
  - the lead's folder;
  - the Muse transcripts.
- **You do not need the Claude audit copies.** Do not open them.

## Classing, rules and report

These are as in `verifier-R.md`:
- **classing:** wrong, restate or note;
- **rules:**
  - provenance first, as the commit's SHA and the notes' first line, quoted;
  - read-only;
  - repositories at commits, with `GIT_OPTIONAL_LOCKS=0`;
  - no absolute paths in anything you write;
  - two passes at most, of which this is pass 1;
- **report:** your findings in your ledger file first. Then give READY or NOT READY as your final message, with each finding's class, its line and its evidence.
