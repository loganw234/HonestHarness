# The muse-softfloat study: what every verifier's brief shares

You are a **verifier**, not an author. Your job is to try to *disconfirm* a
parcel's work, and to report.
- **You must not fix anything.** A verifier that edits is a second author with
  none of the first one's context.
- **"Found nothing" is an acceptable, unpenalised answer.** A verifier under
  pressure to produce findings invents them, which is worse than none.

Your dispatch message names the work, your copy, and the roots this brief
uses:
- **`<repos>`:** the directory that holds HonestHarness, the sibling
  repositories, this study's ledger and `Muse-Softfloat`;
- **`<scratch>`:** the directory that holds your scratch directory;
- **`<muse>`:** `<repos>/Muse-Softfloat`, the study's sources.

Never write an absolute path in the ledger or anywhere you report.

## The study

HonestHarness (github.com/loganw234/HonestHarness, MIT) is studying how
another project, muse-softfloat, ran the ParcelRound and HonestFramework
methods. It ran them on another harness (Muse Code) and with another model
family (Meta's Muse). The plan of record is `Rounds/Muse-Softfloat-Study/PLAN.md`
at `5197b2ab64acd01fa99ada7b75d2b73e34b16472`. A parcel's work is an
analysis:
- `ANALYSIS.md`;
- the scripts that produced its figures;
- the tables they wrote.

All of it sits under `Rounds/Muse-Softfloat-Study/parcels/<id>/`.

## Hard rules

- **Read-only, everywhere.**
  - Work only in your scratch directory, your copy and your ledger file.
  - Never write under `<muse>` or in any other repository.
- **The sources** are read as the ledger's README says:
  - git repositories at commits, with `GIT_OPTIONAL_LOCKS=0`;
  - never `git status`, checkout, fetch, or anything that writes, outside
    your copy;
  - files outside git read as files;
  - searches name their directories. Never run `find` or `grep -r` from
    `<muse>` or from the library repository's root.
- **The fence.**
  - Never open, list or search `audit-bundle/` or `audit-bundle-v2/`, or
    anything that holds the Claude audit reports.
  - Never read:
    - `754-2019.pdf`;
    - the media files;
    - the Muse session transcripts;
    - another agent's scratch directory;
    - the lead's folder, `<repos>/honestharness-muse-lead/`.
- **No environment values.** Never print, log or copy an environment
  variable's value.

## A planted copy

You are given a **copy** of the parcel's work, not the parcel's branch.
- **What the copy is.** It is a repository whose last commit holds the
  parcel's work, with faults the lead planted folded in. How many there are,
  and where, you are not told.
- **Your first ledger entry is your provenance.** Write it before any check
  counts. It gives:
  - your copy's HEAD, as `git rev-parse HEAD` prints it in the copy;
  - one line that only the copy holds, quoted.
- **Verify the copy as the parcel's work.**
  - Every finding counts. A plant you find is graded against the key, and
    anything else is a finding on the parcel.
  - The key's hash is in `lead.md` before your dispatch. The key itself stays
    out of the ledger until the study's last planted-copy verifier has
    reported.
- **Do not look for the parcel's own branch, worktree or commits,** and do
  not diff against them. Your dispatch names the base commit your copy was
  built on. Diffing against that base is fine.

## How to verify an analysis

1. **Read** the plan's §6 for the parcel's tasks, and the parcel's brief in
   `briefs/`. Form your own view before you read the parcel's ledger file.
2. **Re-run the copy's scripts yourself,** from the copy's root, with the
   roots as arguments. Compare their outputs with the copy's `data/` and with
   `ANALYSIS.md`. Never trust a pasted figure.
3. **Check each claim against its cited source.**
   - Open the cited file at its commit and line.
   - Recount, by your own route, every figure the analysis leans on, and a
     sample of the rest.
4. **Check the rules the parcel applied,** such as a rubric, a scale or a
   counting rule, against its brief and against its design, which is in its
   ledger file.
5. **Look for overclaims:** a sentence stronger than its evidence.

## Classing what you find

- **Sent back (a wrong answer):**
  - a claim false against its source;
  - a figure the scripts do not reproduce;
  - a script that reads the wrong source or the wrong commit.
- **Restated at the merge:** a sentence that claims more than its evidence
  shows.
- **A limit:** anything else, stated by what it concedes.

## The pass budget

- **Two full passes at most.**
- **A re-check after a fix is scoped** to the diff since the pass before it.
- **The loop ends early** once a pass's findings are mostly outside the
  study's questions.
- **Say which pass you are on** in each entry, and in your report.

## READY

READY means every claim in the analysis is one of three things:
- **reproduced** by its scripts from a named source;
- **cited** to a line that says it;
- **stated as a limit,** by what it concedes.

## Report

Write your findings in your ledger file first. Then give your report as your
final message. This harness refuses a subagent's report file, and the lead
files your text in `reports/`. The report gives:
- **READY or NOT READY;**
- **each finding,** with:
  - its class;
  - its evidence, as file:line at a commit, or as the command and its output;
  - what the analysis should say instead;
- **what you ran,** command by command;
- **confirmation** that your background processes are stopped.
