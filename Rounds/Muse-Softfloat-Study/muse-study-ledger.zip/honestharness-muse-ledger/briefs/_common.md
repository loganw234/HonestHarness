# The muse-softfloat study: what every parcel's brief shares

Read this first, then your own brief (`P1.md` to `P3.md` beside it). Where your
brief and this file disagree, say so in the ledger at once. Don't pick one.

## The study

You are a parcel in a HonestHarness study, run on ParcelRound's method.

**HonestHarness** (github.com/loganw234/HonestHarness, MIT) measures which
models can hold which roles in rounds run on two methods:
- **ParcelRound,** for allocating work: a lead, parcels and verifiers;
- **HonestFramework,** for verification: gates, planted faults and stated
  limits.

**muse-softfloat** is another project, which ran both methods from a frozen
bootstrap kit. It differed from the earlier rounds in four ways:
- **the harness:** Muse Code;
- **the models,** from Meta's Muse family:
  - `muse-wonder-full-1.0` was the lead and ran most parcels;
  - `muse-spark-1.3` was the verifier;
- **the work:** an IEEE 754-2019 softfloat library for the RP2040, with
  hardware in the loop;
- **a hard hackathon deadline.**

A follow-on "toy" round ran afterwards in a second repository.

**The plan of record** is `Rounds/Muse-Softfloat-Study/PLAN.md` in your
worktree.
- Read all of it.
- Your parcel is under §6.
- Its rules and fences are in §5.

## Places, and no absolute paths

Your dispatch message defines the roots:
- **`<repos>`:** the directory that holds HonestHarness, the sibling
  repositories, this study's ledger and `Muse-Softfloat`;
- **`<scratch>`:** the directory that holds your scratch directory;
- **`<muse>`:** `<repos>/Muse-Softfloat`, the study's sources.

**Never write an absolute path** in the ledger, a commit message, a committed
file or your report. The repository is public, a path names the owner's
machine, and the gate's privacy check fails on one.

**Scripts take the roots as arguments,** for example
`python Rounds/Muse-Softfloat-Study/parcels/P1/scripts/plants.py --repos <repos>`.
They never hold a path.

## The sources and how to read them

| Source | Read it at |
|---|---|
| The library repository, `<muse>/muse-softfloat` | `main` = `b78af1801d3e2bd123fed82d933414af661a9e9a`; tag `v1.0.0` = `957fdaef45539b5ad0b5e024cee5b7f82016d517`; the case report cites `a49991f2603f2ebd55f6287be1d691de78cf5c57` |
| The toy repository, `<muse>/muse-softfloat-toy` | `main` = `084f98b29e292d0674dfa4eb9fe119c3990c726d` |
| ParcelRound, `<repos>/ParcelRound` | `f42242ecc1707a3d36c52e4b2a3b580ee2783e5b` (the kit's pin; the local checkout's HEAD is 37 commits behind it, so read at the SHA, never at HEAD). Also the branch `case-study-7` at `894d125`: `CASE-STUDY-7.md`, round 7 on cft-fp256, dated 2026-10-05. It is not in the kit |
| HonestFramework, `<repos>/HonestFramework` | `65447fd4d8253034fd6d206479c5a5371c623c60` (the kit's pin) |
| HonestHarness round 1 | `Rounds/HonestHarness-R1/` on `main`, with its archived ledger `round1-ledger.zip` |
| HonestHarness round 2 | the branch `round2`; its ledger `<repos>/honestharness-r2-ledger/` (`lead.md`, `keys/`, the verifiers' files) |
| Files outside git | `<muse>/ledger/`, `<muse>/scratch/` (the audits, the agents' reports), `<muse>/softfloat-bootstrap-kit/` (the kit), `<muse>/CASE-REPORT-muse-softfloat.md` |

**How to read each kind:**
- **Git repositories, at commits only.** Use `git show <sha>:<path>`,
  `git log`, `git ls-tree`, `git cat-file` or `git archive`, each with
  `GIT_OPTIONAL_LOCKS=0`.
  - Never `git status`, checkout, fetch, worktree, or anything that writes,
    in any repository but your own worktree.
  - Another session may be working in `<muse>`.
- **Files outside git:** read them as files. Never write, move or create
  anything under `<muse>`.
- **Zip archives:** copy them to your scratch directory, from `git show`, and
  read them there with Python's `zipfile`.
- **Never copy an author's email** from `git log` into anything. Use
  `--format` without `%ae` or `%ce`. The owner's address must not appear in
  any file you write.

## The fence, and what is never read

- **Until the lead lifts the fence in `lead.md`,** never open, list or
  search:
  - `audit-bundle/` or `audit-bundle-v2/` in the library repository, at any
    commit;
  - any branch, file or bundle that holds the Claude audit reports.
- **Searches name their directories.** Never run `find` or `grep -r` from
  `<muse>` or from the library repository's root, because both trees hold
  the fenced folders.
- **Never read at all:**
  - `<muse>/754-2019.pdf`;
  - the media files (`.mp3`, `.mp4`, `.wav`, images);
  - anything under the owner's `.local/share/muse/`, which holds the Muse
    session transcripts and is out of scope;
  - `<repos>/cft-worktrees/` and any `Data/runs/`;
  - another agent's scratch directory, and the lead's folder
    `<repos>/honestharness-muse-lead/`.

## Your deliverable

Files only under `Rounds/Muse-Softfloat-Study/parcels/<your id>/` in your
worktree:
- **`ANALYSIS.md`:** your answers. Each claim names its source:
  - a row: the file at its commit, and the line or key;
  - a ledger entry: the file, the line, and the entry's heading stamp;
  - a figure: the script, the command, and the line of output.
- **`scripts/`:** every script that produced a figure.
  - Python standard library only, run with `python -I`.
  - Each one reads its sources at the named commits or as named files, and
    writes its tables to `data/`.
- **`data/`:** the derived tables, as CSV or JSON. Each is remade by a script.
- **Quotes** from the sources are short and attributed. Paraphrase anything
  longer.

**Values come from a script or a command, never from memory or from
reading.** That covers every count, rate, SHA, date and line number. Where you
counted by reading, say so, and give what you read.

## The ledger

`<repos>/honestharness-muse-ledger/`. Read its README now: it holds the
study's rules. In short:
- one file per author, named in your brief, append only;
- stamps from `date`, never typed;
- read the whole directory:
  - before you start;
  - before you design anything that touches a shared file;
  - before your report;
- mark what you measured and what you believe;
- nothing secret or personal in any file, because the ledger will be
  published.

**Escalation.** Write it in your file first. Then message the lead
(`SendMessage` to `main`) and wait. If `SendMessage` isn't loaded, load it
with the ToolSearch tool, query `select:SendMessage`.

**A resume note at each step.** At the end of each numbered step, write a
short entry headed "resume note":
- where you are;
- what is done and committed, and what is not;
- what comes next.

Agents are dropped by API failures and the weekly usage limit, and paused by
the owner. Work resumed from a brief and a resume note survives. Work held
only in context does not.

## Your two phases (design first)

**Phase 1: read, echo, test the channel, design, then stop.**
1. **Your intent echo,** as your first ledger entry. In your own words:
   - what your brief asks;
   - which files you own, and what you must not touch;
   - which sources each task reads, and at which commit;
   - what would count as failing.
2. **A test escalation.** Send the lead one message, `"<you>: channel test"`,
   and record in your file that you sent it.
3. **Your design,** in your ledger file:
   - each task's method;
   - your scripts and their outputs;
   - any rubric your brief asks for, in full;
   - the spot checks you will run on your own figures;
   - anything your brief got wrong.
4. **Stop.** Your final message for phase 1 is the design. The lead compares it
   with the brief, then resumes you with "go", or with corrections.

**Phase 2, on the lead's "go": do, check, commit, report.**
1. **Do the tasks,** in your files only.
2. **Check your own figures.** For each table, recount at least one figure
   by a different route (a second script, `grep -c`, or `git` itself), and
   report both.
3. **Run the gate** in your worktree:

       env -u SSL_CERT_FILE DOCKER_HOST=tcp://127.0.0.1:9 PYTHONDONTWRITEBYTECODE=1 PYTHONIOENCODING=utf-8 python tools/check.py

   It must hold 5 of 5. Its privacy check fails on an absolute path or the
   owner's address in any file.
4. **Commit on your own branch.**
   - The message says what you did. It ends with a `Co-Authored-By:` trailer
     with `<noreply@anthropic.com>`, naming the model you actually run as,
     taken from your own system prompt, not from this brief.
   - Check `git show --stat HEAD` against your message before you believe it.
5. **Stop every background process of your own,** then report.

## READY

READY means every claim in your analysis is one of three things:
- **reproduced** by a script in your parcel, from a named source;
- **cited** to a line you read;
- **stated as a belief or a limit,** by what it concedes.

Your verifier works to that standard, on a copy of your work with faults
planted in it. "Found nothing" and "the sources cannot answer this" are
acceptable answers. Say so rather than forcing a figure.

**The send-back rule:**
- **Sent back:** a claim that is false against its source, or a figure your
  scripts do not reproduce.
- **Restated at the merge:** a claim stronger than its evidence.
- **A limit:** anything else.

So state your limits yourself, before your verifier has to.

## Do not

- Push, merge or rebase, or commit to `main` or `study-muse`. Commit only on
  your own branch: the lead merges.
- Write anywhere but your parcel directory, your scratch directory and your
  ledger file.
- Install anything.
- Send a heredoc with backslashes through Bash, because they get mangled
  here. Write scripts with your file-writing tool.
- Read any source the fence or the list above forbids.
- Work around a refused write. If the harness refuses to write a file your
  brief asks for, escalate at once: say which file, and quote the refusal.
  The lead decides.
- Run long jobs inline. A step that may take more than 10 minutes runs as a
  script, writes its progress to a file, and stays under 2 GB of memory.

## Report (phase 2)

Write your findings in your ledger file first. Then send the report as your
final message, and the lead files it verbatim in the ledger's `reports/`.
This harness refuses a subagent's report file. The report gives:
- your commit, and each file with its job;
- your answers, in brief, each with its source;
- your spot checks: the actual lines, both routes;
- your limits;
- **anything you found that this brief or the plan got wrong;**
- any boundary you crossed, and why. A crossing you disclose and reason is
  fine; a silent one is not;
- confirmation that your background processes are stopped.
