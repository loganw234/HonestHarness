# verifier-P2: P2's analysis, as a planted copy

Read `_verifier.md` first. You are **verifier-P2**.
- **Your ledger file:** `verifier-P2.md`.
- **Your scratch directory:** `<scratch>/verifier-P2/`.

**Time box:** about 2.5 hours for pass 1.

## The work

P2's analysis covers the muse-softfloat library round:
- a table of the methods' clauses, marked done, adapted, skipped, not applicable or unknown;
- the harness's fallbacks;
- the escapes: what the round's final audits found that its own verification had not raised;
- the lead's own errors;
- the case report's checkable claims, checked against the record.

Its brief is `briefs/P2.md`. Its tasks are in the plan's §6, under P2.

## Your copy

`<repos>/honestharness-worktrees-muse/vP2`. It is a repository whose last commit holds P2's work, with planted faults folded in. It is built on the approved plan, `5197b2ab64acd01fa99ada7b75d2b73e34b16472`.

- **The copy is yours to run in.**
- **P2's judgements live in curated input files** under `scripts/` (`*_curated.txt` and the other `.txt` files). Its scripts join those inputs with what they measure, and write the tables in `data/`. Each script's docstring gives its usage.
- **After a re-run,** `git -C <copy> diff --stat` and `git -C <copy> diff` show what changed against the committed copy. That diff is evidence.
- **Never commit** in the copy.

## What to check

1. **Re-run P2's scripts** from the copy's root, with the roots as arguments. Compare what changes in `data/` against the committed copy.
2. **Check every count in `ANALYSIS.md` against the tables in `data/`.** Recount by your own route, with a short script of your own in your scratch directory:
   - the clause marks;
   - the escape table, including that its rows and columns add up;
   - the escape families;
   - the lead's error rows;
   - the case report's results.
3. **Check that each curated verdict follows from its own evidence:** the `reason` and the measured values beside it. Do it for every row the analysis quotes, and for a sample of the rest.
4. **Check the cited lines** the analysis leans on, each at its commit or file:
   - the M1 evidence in `<muse>/scratch/verifier-readme/report.md`;
   - `tools/run.sh` at `a49991f`;
   - the `docs/RECORD.md`, `docs/KICKOFF.md` and `docs/HARNESS.md` lines at `b78af18`;
   - the adherence-audit lines;
   - `<muse>/ledger/lead.md` lines;
   - ParcelRound `CASE-STUDY-6.md` lines 254-276 at `f42242e`.
5. **Read for overclaims:** a sentence stronger than its tables or its sources, especially where it compares with ParcelRound's round 6.

## Access

- **The full audit:** you may read `<muse>/scratch/audit-full/`. It is the Muse round's own audit, by Muse agents, and is not fenced.
- **The adherence audits:** you may read `<muse>/scratch/audit-adherence-2/`, `-final/` and `-seal/`, and `<muse>/ledger/auditor-*.md`.
- **The round's own records:** the verifier and parcel reports under `<muse>/scratch/verifier-*/` and `<muse>/scratch/parcel-*/`.
- **Nothing under `<muse>/scratch/lead/`,** and nothing fenced.
