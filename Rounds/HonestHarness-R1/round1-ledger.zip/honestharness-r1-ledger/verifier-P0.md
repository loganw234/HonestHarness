# verifier-P0 - the ledger of the P0 verifier

Append only. Each heading's time is taken from `date`.

## %Y-%m-%d %H:%M:%S %z - verifier-P0 starts: clone at f680bfd, the gate re-run 5 of 5 and controls 7 of 7

Measured:
- Clone of `<repos>/honestharness-worktrees/P0` at `<scratch>/r1-vP0/clone`, detached at f680bfd18ca4ab5edb7bd35567dcec76c034fd06, parent 2357035, committed 2026-10-06 10:39:18 -0700.
- `python tools/check.py`: "PASS: 5 of 5 checks hold" (tests ok; schema ok, 0 record lines read; guard ok, 22 fixtures checked; privacy ok, 37 files and 6 commit messages read; livegate ok, 21 Python files read).
- `python tools/check.py --control`: "controls: 7 of 7 caught".
- `python -m pytest -p no:cacheprovider`: "59 passed in 5.91s".
- The gate's tests line prints pytest's progress dots, not its count, as its summary (pyproject's addopts `-q` plus the gate's own `-q`). Cosmetic.
- `<scratch>/ds/chat_completion_full.txt` is stamped 10:49:38 -0700, after this dispatch; the other doc copies are stamped 09:07 to 09:23. I read it as a fuller copy of D10, beside `chat_completion.txt`.

Believed: nothing yet.
For: the lead

## 2026-10-06 10:55:55 -0700 - correction to the entry above: its heading lost its time

Measured:
- The entry headed "%Y-%m-%d %H:%M:%S %z - verifier-P0 starts ..." was written with a doubled % in the `date` format, so its heading printed the format, not the time.
- The file's modification time, read with `date -r` before this entry was appended, is 2026-10-06 10:55:46 -0700. That is when the entry above was written.

Believed: nothing.
For: anyone reading the stamps

## 2026-10-06 11:13:46 -0700 - shared-code findings that bear on wave 1, ahead of my report: a run that raises loses its billed spend, a run is priced at its start period, max_tokens passes DeepSeek's limit

Measured (scripts in `<scratch>/r1-vP0/work/`, run against `qs/fake.py` on 127.0.0.1 only, P0 at f680bfd; file:line at that commit):
1. **An exception other than `ProviderError` or `CapReached` inside a run escapes `run_batch`** (suite.py:207-212 catches only those two). The run's record, its spend line, and the batch's reconciliation and summary are never written.
   - E1a (`e1_error_paths.py`): a dropped connection on a run's second call. The fake billed $0.0720024. The spend file holds $0.0000024, the probe's line only. No run record, no `batches.jsonl`.
   - The same holds at the probe (E1b) and at the closing balance read (E14b, `e14_misc.py`: `httpx.ConnectError`, no summary).
   - DeepSeek documents closing a connection whose request has not started inference after 10 minutes (ds/rate_limit.txt:57).
   - For P2: any exception the loop or its sandbox raises inside `run_item` has the same effect.
   - The spend file holds one line per run, not one per paid call (E14a: 7 paid calls, 3 lines), against guard.py:11's "one per paid call". The spend line is written after the run's record (suite.py:266-268). So a record its schema refuses also loses the spend line. A cost below $0.000001 renders as "6E-7" (prices.py:81-85, suite.py:263). The schema's pattern refuses that (qs/schema/run_record.schema.json:57), and the batch stops with no spend line for that run (E11, `e6_context.py`).
2. **The rate period is read once per run, and the worst case once per batch, at its start** (suite.py:163, 169-173, 196, 213). `Context.chat` reads no clock. Run with `e4_peak_crossing.py`:
   - E4a, `allow_peak` off: a run starts at 00:59:30 UTC on a Monday, and its two calls land after 01:00. The fake billed $0.5100021 against a reservation of $0.2550192. The run's record says `off_peak` at $0.25499985, and the spend file holds the meter's figure. `MeterMismatch` is raised after the batch.
   - E4b, `--allow-peak`: the batch starts off-peak, and run 2 lies wholly in peak. Reserved $0.5100192; computed and billed $0.76500195. Reconciliation is `ok`, and nothing is raised.
3. **`Context.chat` sends `max_tokens` equal to the run's remaining output cap when the suite gives none** (suite.py:104-105), and never clamps it.
   - With `max_output_tokens=500_000`, the plan's QS4 cap (§7), it sent 500000 (E6).
   - DeepSeek's docs say: "The value must be between 1 and 384K (393216)" (ds/chat_completion_full.txt:319-322). The model list's `max_output_tokens` is "the maximum accepted value of max_tokens" (ds/list_models.txt:37, 393216 at :62).
   - With the default caps (8,000), a thinking-mode call is sent `max_tokens` 8000, where DeepSeek's thinking-mode default is 64K (ds/chat_completion_full.txt:322). The run record does not carry `max_tokens`.
   - For P1: a thinking-mode case that hits this cap ends `length`. That is the harness's cap, not a model failure.
4. **`Context.chat` accepts a per-call `thinking=False`** (suite.py:101-103), **but the run record keeps the batch's `thinking` and `effort`** (suite.py:258-259). E9: the batch ran thinking on at effort max; the call sent thinking disabled with no effort; the record says thinking true, effort max.
5. **The run record keeps only the last response's `model` and `system_fingerprint`** (suite.py:115-116). E10: three responses reported fp_1, fp_2 and fp_3, as deepseek-flash, deepseek-v4-pro and deepseek-flash. The record says fp_3 and deepseek-flash. Each response's values are only in the local, gitignored transcript.
6. **A stream that ends without its usage chunk is metered as zero, and no cap fires** (deepseek.py:119-162 checks for neither `[DONE]` nor usage). E7b: 25 calls, usage 0, cost 0.000, status pass. DeepSeek always puts usage on the last chunk (ds/chat_completion_full.txt:384-392), so this needs a stream cut short. Over HTTP/1.1 chunked transfer, a cut raises instead, which is item 1.

Believed:
- Items 1 to 4 change what P1 and P2 can rely on in `Context` and the runner. My final entry gives each finding's class.

For: the lead, P1, P2

## 2026-10-06 11:18:52 -0700 - verdict: NOT READY. Five sent back (lost spend on a raise, the rate period fixed per run, max_tokens unclamped, a key in an exception message, a thinking override misrecorded), eight restated, seven known limits

Verdict: **NOT READY.** Five findings are sent back, eight are restated, and seven are known limits. Every other property is held by the gate or by a check I ran. Evidence is given as file:line at f680bfd. The E and p labels are runs of my scripts in `<scratch>/r1-vP0/work/`, against `qs/fake.py` on 127.0.0.1 only.

Measured:

**Sent back: wrong answers**
- **S1. If a run, the probe or the closing balance read raises anything but `ProviderError` or `CapReached`, billed spend is left out of the spend file, and the batch neither reconciles nor records why.**
  - Code:
    - suite.py:207-212 catches only those two;
    - the probe (suite.py:184-191) and the closing read (suite.py:225) are in no `try`;
    - the record is written before the spend line (suite.py:266-268).
  - The spend file holds one line per run, not "one per paid call" (guard.py:11). E14a: 7 paid calls gave 3 lines.
  - Runs:
    - E1a, a dropped connection on a run's second call: billed $0.0720024; the spend file holds $0.0000024; no run record, no summary.
    - E1b, the same at the probe: no summary.
    - E14b, at the closing read: `httpx.ConnectError`, no summary.
    - E11: a run costing $0.0000006 renders as "6E-7". The schema refuses it (run_record.schema.json:57), and the run's spend line is never written.
  - DeepSeek closes a connection whose request has not started inference after 10 minutes (ds/rate_limit.txt:57). The commit message says "every batch is reconciled".
- **S2. The rate period is read once per run, and the worst case once per batch at its start.**
  - Code: suite.py:163, 169-173, 196 and 213. `Context.chat` (suite.py:92-122) reads no clock.
  - E4a, `allow_peak` off: a run starts at 00:59:30 UTC on Monday 2026-10-05, and its two calls land after 01:00.
    - Reserved $0.2550192; billed $0.5100021.
    - The record says `off_peak` at $0.25499985.
    - `MeterMismatch` is raised only after the batch.
  - E4b, `--allow-peak`: reserved $0.5100192; computed and billed $0.76500195; reconciliation `ok`.
  - guard.py:5-6 claims the guard refuses "a run whose worst case would cross what is left".
- **S3. `max_tokens` defaults to the run's remaining output cap, and is never clamped** (suite.py:104-105).
  - E6: with `max_output_tokens=500_000`, the plan's QS4 cap (§7), it sent 500000.
  - The docs:
    - "The value must be between 1 and 384K (393216)" (ds/chat_completion_full.txt:319-322);
    - the model list's `max_output_tokens` is "the maximum accepted value of max_tokens" (ds/list_models.txt:37, 393216 at :62).
  - Default caps send 8000 in thinking mode, against DeepSeek's 64K default (ds/chat_completion_full.txt:322).
  - The record has no `max_tokens`, so a `length` finish caused by the harness's cap cannot be told from the model's own.
- **S4. A key value with trailing whitespace reaches an unredacted exception message.**
  - Code:
    - keys.py:18-24 returns the value as read, and client.py:56-58 puts it in the header;
    - only `ProviderError` bodies are redacted (client.py:76-78, 82-85);
    - the first balance read (suite.py:175-176) catches nothing, and `tools/live.py` prints the traceback.
  - E12 and E12b used my own variable, holding a dummy value with a trailing space or a trailing newline. Each raised `httpx.LocalProtocolError: Illegal header value b'Bearer <value> '`. A leading space was sent without error.
- **S5. A per-call thinking override is sent, but the record keeps the batch's setting.**
  - Code: suite.py:101-103 accepts the override; suite.py:258-259 records the batch's values.
  - E9: the batch was thinking on at effort max. The call sent thinking disabled with no effort, and the record says thinking true, effort max.

**Restated at the merge: claims beyond what is true**
- R1. suite.py:14 says "A mismatch stops the caller's next batch". Nothing does. E14c: after a `MeterMismatch`, the next batch on the same guard and records ran and spent. `tools/live.py` runs one batch per process and reads no earlier summary.
- R2. guard.py:11 says "one per paid call". The spend file holds one line per run, plus the probe's (E14a).
- R3. The live gate is checked against the client's base URL, not against each request.
  - client.py:3-8 says a provider "is reached only when the caller is in live mode and holds a reservation". lead.md 10:45:33 believes "outside live mode, the client refuses any other host".
  - E5a and E5b: a local client given an absolute URL posts to it, including a stand-in provider host, with no live mode and no reservation.
  - What holds is narrower: outside live mode no key is read or sent.
  - A read-only reservation allows any GET (client.py:66-67), not only the balance and model-list reads.
- R4. The privacy check's claim (check.py:33-35) misses forms inside its own threat model, neither caught nor stated. Catch them or state them.
  - Home paths in WSL `/mnt/c/Users/<name>`, Docker Desktop `/run/desktop/mnt/host/c/Users/<name>`, Cygwin `/cygdrive/c/Users/<name>` and drive-less backslash form all pass 5 of 5 (p01-p04). The lookbehind at check.py:76-78 refuses a `/c/users` segment that follows a letter. P2's sandbox runs on Docker Desktop.
  - `tools/check.py` is never scanned (check.py:233-234). A home path or a key-shaped token pasted into it passes (p05, p06).
- R5. deepseek.py:16-17 says "What the docs leave open is marked where the code meets it". The balance's precision (stated as fact at guard.py:22) and its update time (live.py:65, `--settle` 5) are not marked.
  - The first live step cannot settle either. E16: an empty batch costs about $0.00001, the balance read 12.00 before and after, billed 0.00, `ok`.
- R6. `test_provider_error_is_recorded` (tests/test_runner.py:159-165) asserts only that an exception is raised at the probe. Nothing is recorded on that path, and no test covers a run's provider error. E1d: a 400 inside a run is recorded.
- R7. README.md:8 says "There is no code yet.", beside P0's new code section.
- R8. `model_reported` and `system_fingerprint` are the last response's (suite.py:115-116). Plan §6 lists those "each response reports".
  - E10: fp_1, fp_2 and fp_3 from deepseek-flash, deepseek-v4-pro and deepseek-flash were recorded as fp_3 and deepseek-flash.
  - Each response's values are in the local transcript only.

**Known limits, each stated by the behaviour it concedes**
- K1. A response without usage is metered as zero, and no cap fires.
  - E7b: 25 streamed calls, usage 0, status pass.
  - E14f: a 200 with no choices is read as an empty turn.
  - Only a reconciliation over $0.02, after the batch, sees it.
- K2. A 402 does not stop a batch; each later run records an error (E1c).
- K3. Two blind spots in the reconciliation:
  - A top-up smaller than the bill goes unseen (guard.py:121-123), and can hide a meter fault.
  - A routing match returns normally, and the spend file keeps the meter's figure. E14d: $0.0840024 spent against $0.3432099 billed.
- K4. Each of these drifts passes 5 of 5:
  - absolute tolerance at 0.30 (p07);
  - a worst case without `max_call_prompt_tokens` (p08);
  - a token estimate at four characters a token (p10);
  - no `max_tokens` bound (p11);
  - no per-call estimate check (p12);
  - no in-batch peak stop (p14);
  - provider error bodies unredacted (p16).

  The gate's tests limit covers them, but plan §7 rests on this bound.
- K5. A record id with a colon is allowed by the schema. On this desktop it puts the transcript in an NTFS alternate data stream: E17 listed only `b1.cut16k`.
- K6. The spend file belongs to the checkout (live.py:71). Spend recorded in one checkout is unseen by a batch run from another.
- K7. On a Chinese public holiday every hour is off-peak (ds/pricing.txt:35). A peak-window batch run with `--allow-peak` is metered at twice its bill, and raises `MeterMismatch`.
- Outside the threat model, stated and not pressed:
  - a live client sends its key to any absolute URL given as a path (E5c);
  - in the one test file allowed `live=True`, reading the key's name from registry.json would read the real key without naming it.

**Held by the gate or by checks I ran**
- The gate: 5 of 5, and controls 7 of 7. 59 tests passed. Plants p00, p09, p13 and p15 were caught.
- The live gate at construction: refusals per P0's tests. In live mode against a local host, no key is read (E16, with a tripwire on `read_key`).
- Prices against ds/pricing.txt:26-35. The fixtures' hand sums recomputed: 2.016, 1.008, 27.39, 0.005324.
- The adapter against the docs, all as documented:
  - thinking and effort (ds/chat_completion_full.txt:271-318);
  - reasoning passback (ds/thinking.txt:34-36, 54);
  - the `tool_choice` 400 (:463-466);
  - usage (:684-709) and finish reasons (:530-557);
  - stream keep-alives and last-chunk usage (:384-392, ds/rate_limit.txt:52-56);
  - blank lines before a JSON body (E14e);
  - the balance and model-list shapes (ds/balance.txt:28-35, ds/list_models.txt:35, 62).
- The schema holds every field plan §6 names. The price table is named by its id, and its URL and date are in the table file.
- The runner: the peak refusal at start and between runs, the probe, the guard's mid-batch stop, and the caps.
- Privacy: P0's 28 files, its commit message and the ledger are clean under the gate's patterns and wider ones (E15).

**What I ran**
- Setup: the clone and detached checkout per the brief.
- `python tools/check.py`, `python -m pytest -p no:cacheprovider`, and `python tools/check.py --control`.
- In `<scratch>/r1-vP0/work/`:
  - `e1_error_paths.py`, `e4_peak_crossing.py`, `e5_client_gate.py`, `e12b_ws.py`, `e6_context.py`, `e14_misc.py`, `e15_privacy.py`, `e16_probe_batch.py` and `e17_colon.py`;
  - `e13_plants.py`: 17 plants, each in its own copy under `<scratch>/r1-vP0/plants/`.
- No paid call was made. `tools/live.py` was neither run nor imported, and no provider host was contacted. The only key variables read were my own, holding dummy values.

**Corrections and disclosures**
- My 11:13 message to main believed wave 1 was designing now. lead.md 11:14:26 records that it had not been dispatched. The findings stand.
- My scripts' working directories were made by Python's tempfile, in the system temp directory, outside `<scratch>/r1-vP0/`. They held fake-run records only. All are removed, the last at 11:17:11.
- No process of mine is running. Every server ran inside a foreground script that has exited.

Believed:
- S4 depends on the key's value having trailing whitespace, which is unknown: the value was never read (lead.md 10:26:00).
- Calls are billed by the period they are made in. When a call spanning 01:00 is billed is not documented.
- An out-of-range `max_tokens` returns 400 or 422 (ds/quick_start_error_codes.txt:11, 14). Not measured.

For: the lead

## 2026-10-06 12:04:36 -0700 - pass 2 on 8108bb6: NOT READY on two narrow leftovers of the S1 and S2 fixes (S1 prime: calls continue in a run after stop_reason; S2 prime: a call longer than the peak margin bills at peak); every other item holds

Verdict: **NOT READY**, on two narrow leftovers of the fixes for S1 and S2. Every other item in the re-check's scope holds, by a test or by a check I ran.

The work is the clone fetched to 8108bb681ebd22404063da75a539b5d890fb4988, parent f680bfd. Evidence is file:line at 8108bb6. The E and p labels are runs of my scripts in `<scratch>/r1-vP0/work/`, all against `qs/fake.py` on 127.0.0.1.

Measured:

**Sent back: S1′ and S2′**
- **S1′. `Context.chat` keeps sending after `stop_reason` is set.**
  - Code: `chat()` never reads `self.stop_reason` before it sends (suite.py:167-206). The stop takes effect only after the run returns (suite.py:459-462).
  - E18a (`e18_retry.py`): the suite retries a failed call up to five times. Each reply is billed and then dropped.
    - Five more calls went out in the same run after the first drop.
    - Billed $0.2520024; metered $0.0000024.
    - The adjustment of $0.2499976 and the `MeterMismatch` come only after the batch.
    - Unmetered calls add nothing to `used`, so no cap fires. Only the suite's retry limit, or the provider's balance, ends it.
  - E18b: after a 503, five more calls went out.
  - What the docs say:
    - suite.py:26-28 says such an error "stops the batch".
    - suite.py:143-145 says "a suite that catches the error cannot hide it".
    - The revised `_common.md` and `P2.md` tell parcels the runner stops the batch even when a suite catches.
  - The fix: refuse a call once `stop_reason` is set.
- **S2′. A call sent just before the margin, and longer than it, is metered at peak against a reservation priced at the start's period.**
  - Code:
    - without `--allow-peak` the reservation is priced at the start's period (suite.py:411-420);
    - the gate reads the send time (suite.py:363-371);
    - the meter reads the reply time (suite.py:373-377).
  - E4c (`e4_p2.py`): call 2 went out at 00:49:00 UTC, 11 minutes before peak, and replied at 01:04:00.
    - Reserved $0.2550192; computed and billed $0.36000165, which is 1.41x.
    - Reconciliation `ok`; nothing held.
  - suite.py:15-17 says the worst case is priced at "the dearest rate period the batch may be billed in: the start's".
  - The excess is one call's peak premium per batch, at most that call's off-peak cost. The next gate stops the batch.
  - E4d: if the provider bills at the send time instead, the meter over-counts, and `MeterMismatch` holds the next batch.
  - The fix: price the reservation at the dearest period, or state this as a limit with its bound and correct the docstring.

**Held: the sent-back items**
- **S1:**
  - S1a, a drop on a run's second call: $0.072 stays in the spend file; the summary is written and the batch stops.
  - S1b, a reply billed then dropped: an adjustment of $0.0679976, then `MeterMismatch`, and the next batch is held.
  - S1c, a drop at the probe: the identity line records the error; the summary is written.
  - S1d, the suite's own exception: the run records `error`, the batch goes on, and the spend is kept.
  - S1e, a failed closing read: reconciliation `unread`, and the next batch is held.
  - E11: costs are written in fixed point.
- **S2:**
  - E4a: no call is sent at 00:50:30, and all spend is off-peak.
  - E4b, `--allow-peak`: $1.5300384 reserved at peak against $1.1250012 computed, with a run marked `mixed`.
- **S3:** caps of 500000, or a suite's own 450000, are sent as 393216. A suite's 1000 is sent as 1000. The record carries the caps.
- **S4** (`e5_p2.py`):
  - Surrounding whitespace is stripped.
  - Whitespace, a tab, a no-break space or a DEL inside the key raises `KeyUnavailable`, naming only the variable.
  - A non-ASCII character raises `UnicodeEncodeError`, naming that one character.
- **S5:** a call that passes `thinking` or `effort` is refused before any request is sent. The record holds the batch's setting.

**Held: the restates**
- **R1:** after a mismatch the next batch is `Held` until that batch is named. A recheck after an adjustment adds nothing (E14).
- **R2:** 7 calls gave 7 spend lines.
- **R3:** these are all refused:
  - absolute, scheme-relative, bare and upper-case-scheme paths;
  - every read-only GET except /models and /user/balance.

  A path of `/\host` stays on the base host. E5c is closed.
- **R4:** p00 to p06, p41, p42 and p44 are caught. p40 (a JSON-escaped drive-less path) and p43 (a Claude project slug) pass, inside the stated "encoded" limit.
- **R5:** restated in the code. E16: the probe batch does not move the balance.
- **R6, R7:** hold.
- **R8:** the lists hold (E6). But p34, which keeps only the last fingerprint, passes all 113 tests, so no test holds R8.

**Held: the limits**
- **K1:** a cut stream raises `IncompleteReply` and stops the batch.
- **K2:** 401, 402, 403, 429, 500 and 503 stop the batch after one run; 400 and 422 do not.
- **K3:** the routing adjustment is $0.2559976, so the spend file holds $0.34, the bill. A same-size top-up hides a meter miss, as stated.
- **K4:** p07, p08, p10, p11, p12 and p16 are caught.
  - p14, the per-run peak check removed, passes. That check is now redundant behind the per-call gate, whose removal (p33) is caught.
  - Of the fix's own drifts (p09, p13, p15, p17-p33, p35-p37), all are caught.
- **K5:** a colon, a slash or a space in an id is refused before anything is written.
  - A nit: Python's `$` matches before a final newline, so "abc\n" passes both the id pattern and the schema's pattern.

**Held: the gate, and privacy**
- The gate: 5 of 5 (113 tests, 26 fixtures, 39 files and 7 messages, 22 Python files). `--control`: 9 of 9.
- Privacy: the fix's 19 files, its commit message and the ledger are clean.

**What I ran**
- `git fetch` and a detached checkout at 8108bb6.
- `python tools/check.py`, `python -m pytest` and `python tools/check.py --control`.
- `e1_p2.py`, `e4_p2.py`, `e5_p2.py`, `e6_p2.py`, `e14_p2.py`, `e18_retry.py` and `e15_privacy.py`.
- `e13_p2.py`: 43 plants, each in a copy under `<scratch>/r1-vP0/plants/`. Privacy plants ran the copy's own check; the others ran pytest -x.
- No paid call. The only key variables read were my own, holding dummy values.

**Disclosures**
- My scripts' temp directories were in `<scratch>/r1-vP0/tmp/`, and none are left.
- pytest's `tmp_path` and the gate's control copies use the system temp. That is the gate's own behaviour, in both passes.
- No process of mine is running.

Believed:
- When DeepSeek prices a call that spans 01:00 is not documented. S2′ holds under the meter's own reply-time pricing.
- P2's loop is the likeliest suite to retry after a failed call.

For: the lead, P2

## 2026-10-06 12:21:32 -0700 - pass 3 on 4c2456e: READY. S1 prime, S2 prime, R8 and the newline nit hold, each held by a test; no regression; one older limit to state (a run's status after a stop is the suite's own)

Verdict: **READY.** Each of the four fixes holds, and the diff brings no regression. One known limit is to be stated. It is older than this diff, and the new tests make it easier to meet.

The work is the clone fetched to 4c2456e1620d39e1a2970b3fd0759d26c356e193, parent 8108bb6. Evidence is file:line at 4c2456e. The E and p labels are runs of my scripts in `<scratch>/r1-vP0/work/`, all against `qs/fake.py` on 127.0.0.1. Their temp directories, pytest's included, were inside `<scratch>/r1-vP0/`.

Measured:

**The gate**
- `python tools/check.py`: 5 of 5. That is 118 tests passed, 26 fixtures, 39 files and 8 commit messages, and 22 Python files.
- `--control`: 9 of 9 caught.

**The four fixes**
- **S1′ holds.** `Context.chat` refuses any call once `stop_reason` is set (suite.py:181).
  - `e18_retry.py`, after a reply billed then dropped: no call was sent after the first.
    - Billed $0.0420024; metered $0.0000024.
    - An adjustment of $0.0399976, then `MeterMismatch`.
    - Each retry raised `BatchStopping`.
  - After a 503, too, no call was sent after the first.
- **S2′ holds.** Without `--allow-peak`, the reservation adds one call's peak premium (suite.py:435-442).
  - `e4_p2.py`, E4c: the call sent at 00:49 and answered at 01:04 cost $0.36000165 against $0.3600192 reserved.
    - The premium is $0.105.
    - It holds with $0.0000175 to spare, so the bound is tight.
  - E4a: the gate still stops at 00:50:30.
  - E4b, `--allow-peak`: unchanged at $1.5300384, with no premium added.
  - E4d: a bill at the send time still holds the next batch.
  - The docstring states both, at suite.py step 4 and in its limits.
- **R8 is held by a test.** p34, which keeps only the last fingerprint, fails `test_the_record_lists_every_model_and_fingerprint_reported`.
- **The newline nit is fixed.** Ids go through `ID_PATTERN.fullmatch` (suite.py:73, 418). The schema adds a lookahead after `$` (run_record.schema.json:17, 18, 23).

**Each fix removed in a copy fails a test (`e13_p3.py`)**
- p50, with chat sending after a stop: `test_a_retrying_suite_cannot_send_past_a_stop[drop]`.
- p51, with the premium dropped: `test_the_reservation_is_the_hand_computed_worst_case`.
- p52, with the premium priced too low: `test_with_peak_allowed_the_reservation_is_priced_at_peak`.
- p53, with ids matched by prefix: `test_an_id_with_a_colon_is_refused`.
- p54, with the schema's lookahead removed: `test_bad_values_fail`.

**Privacy**
- The fix's 4 files, its commit message and the ledger are clean under the gate's patterns and wider ones.

**Known limit, to state: a run's status is the suite's own word**
- After a stop, the runner neither overrides the status nor puts `stop_reason` in the run record. The record takes the suite's status (suite.py:566).
- E19 (`e19_status.py`) has the shape of the lead's own `Retries` test suite (tests/test_runner.py:524-535).
  - The run's only reply was dropped, and the suite caught `BatchStopping` and returned "fail".
  - The run record says status `fail`, detail "gave up", and has no field for the stop. Only the batch summary's `stopped_for` names the dropped reply.
  - A table built from run records would count a provider drop as a model failure.
- This is older than the diff: a suite could always relabel an error it caught. The parcel rule in `_common.md` covers it.
- A one-line hardening would close it by mechanism: when `ctx.stop_reason` is set, record the run as `error` with the reason, or add the reason to the record.

**What I ran**
- `git fetch` and a detached checkout at 4c2456e.
- `python tools/check.py` and `--control`.
- `e18_retry.py`, `e4_p2.py`, `e13_p3.py` (p34 and p50-p54), `e19_status.py` and `e15_privacy.py`.
- No paid call.

**Disclosures**
- No temp directory is left, and no process of mine is running.

Believed: nothing beyond pass 2's note that when DeepSeek prices a call spanning 01:00 is undocumented. The docstring now states it.

For: the lead
