# verifier-A1: the plan's amendment 1, QS4's code slice (pass 1 of 1)

Append only. Verifier on Sonnet 5.5 (claude-sonnet-5-5). Scratch: `<scratch>/r1-vA1/`.

## 2026-10-07 12:47:21 -0700 - Pass 1 begins; test escalation "verifier-A1: channel test" sent to main

Measured: I have read the README, briefs/_verifier.md and briefs/verifier-A1.md. The stamp is from `date`.
Escalation (test): the text I am sending to `main` by SendMessage is exactly `verifier-A1: channel test`. I will wait for the answer, and look for it in my tool results and in lead.md.
Believed: the channel works and the lead will answer. Until it does, I go on reading lead.md, which my brief puts before the author's own file.
For: lead

## 2026-10-07 13:15:18 -0700 - My view of amendment 1, formed before I open any verifier's file

Pass 1 of 1. I wrote this before opening verifier-P1.md, verifier-P2.md, verifier-P3.md or verifier-P4.md, or any parcel file. I read the README, lead.md (to its 12:48:48 entry), my two briefs, the draft, and the four keys.

Measured:
- The test escalation: the lead recorded its receipt in lead.md at 12:47:29. The lead sent me no other message.
- The draft: `sha256sum` before I read it equals the brief's `f8a3a83c...ae8`. 136 lines.
- My clone of the code: `git clone --no-hardlinks` of HonestHarness into `<scratch>/r1-vA1/hh`, `round1` at `0af47f7` by `git rev-parse`.
- Facts, against git, the keys and lead.md:
  - Each key's real_tip, base and copy_commit match the draft's table. Each base is an ancestor of its tip, and each tip an ancestor of round1.
  - The diffs base..tip are P1 5 files and 2,333 insertions, P2 12 and 2,673, P3 12 and 3,162, P4 13 and 4,593, as lead.md says.
  - The dispatch stamps 13:42:27, 13:53:53, 17:29:08 and 20:21:45 are the headings of the lead's entries that record each copy and its sealed key hash. The verifier's channel test followed each by under a minute.
  - Each plant's description in the table matches its key. Four plants are logic in Python and four are suite data or a prompt.
  - lead.md 12:41:38, 22:00:27, 17:29:08, 09:32:39, 03:00:44 and 10:26:10 exist and say what the draft says of them.
  - 22:00:27 says "8 of 8 in all, each found in the verifier's first pass".
- The copies, by `qs.suites.qs4.rebuild_copy`, the function `tools/qs4_rebuild.py` uses:
  - P2's `8214694` and P3's `83ee196` reproduce their copy_commit.
  - P1's `17f9d9f` and P4's `3b1b3cd` are REFUSED: the rule rebuilds `7124c3d` and `193dfc3`.
  - Both reproduce under a squash rule, found by trying 12 and 36 combinations: parent := the base; tree := the tip's tree with the key's plants; message := the first commit after the base; author and committer lines := the tip's. One match each.
  - So the key and the tip are enough only with that rule, which no code states. As the draft is written ("must reproduce copy_commit, or the item stops"), two of the eight items would stop.
  - The real tips have 2 (P1) and 3 (P4, one a merge) commits above their base. The copies have 1.
  - The copies' messages are the first commit's, so they are stale against the tip's tree. P1's says "95 tests" and "216 tests" where the tip's says 96 and 217.
- The reservation, from the repository's PriceTable and QS4's caps:
  - Off-peak, N = 23 is $23.8687104 and N = 15 is $17.9338368. The draft's two figures are right.
  - With `--allow-peak`, N = 23 is $29.9328000 and N = 15 is $23.9979264.
- The cost: the 25 QS4 batch lines in the lead's checkout `records/batches.jsonl` have a mean of $0.138 and a median of $0.112. The 12 planted have a mean of $0.077, and the 13 real $0.194.
- The sandbox (this repository, on this desktop; no container run by me):
  - `pyproject.toml` needs httpx>=0.28, jsonschema>=4.23 and pytest>=9 on Python>=3.12. An `ast` scan of 59 Python files finds no other third-party import. The gate also needs `git`.
  - I ran the whole suite with no `docker` on PATH and a guard that refuses and logs any non-loopback connect or lookup. The guard was shown to refuse, in child processes too. Result: 712 passed, 34 skipped, 0 failed, in 159.7 s, and no refused attempt was logged.
  - The 34 skips: 17 need Docker (15 in `test_sandbox_docker.py`, 2 in `test_qs4_docker.py`), 11 need QS6's local files, 4 need QS4's local inputs, 1 a symlink, 1 the table's selection file.
  - The parcel's own test modules pass on each rebuilt planted tree (exit 0 for all four, P3's with round 6's ledger archive in place and no key).
  - I wrote one test file per parcel, in scratch. Each test passes on the real tip and fails on the rebuilt planted tree, with no Docker and no network: P1-A and P1-B, P2-A and P2-B, P4-A and P4-B.
  - For P3, R09 (A) shows from the items file alone: the question names verifier-P1 and the evidence cites verifier-P0.md.
  - L06 (B) shows only with round 6's ledger. I read it from ParcelRound at f42242e, read only, and its SHA-256 equals the one QS6 pins. Its cited lines are stamped 17:20:54, 17:34:34, 17:35:41 and 18:38:25, and the planted bound is 18:00.

Believed (each to be checked against the verifiers' files, or left as a finding):
- The squash makes the real-tip condition not read alike for P1 and P4: `git log` shows 2 or 3 commits, not 1. QS4's template fills `parent ${parent}` from the base for planted and real alike, which is false for those two real tips.
- L06 is a fault against the key only. Without the key it can be found only by reading each cited line against the question's bound.
- P4's copy holds `qs4_prompt.md` and `qs4.py`, the files that frame and score the replay itself. The draft does not name this self-reference.
- The draft cites "harness note 43" and "harness note 44". The only harness-notes file in the repository is round 6's, where those numbers are other rules.
- `briefs/_verifier.md` was last changed at 16:39 by its mtime, after the P1 and P2 dispatches. So "the briefs as dispatched" cannot be given for those two verifiers.
- The reservation figures are off-peak figures and the draft does not say so.
- The draft's five limits do not carry over QS4's own 21.

For: the lead; Logan

## 2026-10-07 13:38:18 -0700 - Verdict, pass 1: the design holds; four wrong facts to correct, four gaps to close, nine limits to state; nothing here changes a decision of Logan's

Pass 1 of 1. The draft is the file the brief names. Its SHA-256 was `f8a3a83c7309c622989976d89e281569fd05160896aca59f27c8c8bd5a91fae8` before I read it and again when I finished (`sha256sum` both times). My view entry (above) was written before I opened any verifier's file; what I found afterwards in `verifier-P1.md` to `verifier-P4.md` agrees with it. Lines cited are at `0af47f7` unless a file is named.

**Verdict on the draft.** The design holds. Nothing I found refutes the amendment's purpose or changes a decision of Logan's, so each item below can go in under his approval (lead.md 12:48:48), each recorded. The text is not correct as it stands: four sentences claim more than is true (W1 to W4), four gaps would stop or skew an item once P5 builds on QS4's tools (G1 to G4), and nine limits are unstated (L1 to L9). Classes are the brief's: a wrong fact to correct, a gap to close before approval (now: before the build), a limit to state. G2 and G4 ask the lead for a choice. I did not run the code slice itself, a container, or anything the amendment would build.

### Wrong facts to correct

**W1. A1.3: "A copy is rebuilt from its real tip and its key, and must reproduce `copy_commit`, or the item stops."**
- Measured: `qs.suites.qs4.rebuild_copy`, the function `tools/qs4_rebuild.py` calls (`qs4.py:460`), reproduces P2's `8214694` and P3's `83ee196`. It REFUSES P1's `17f9d9f` (it rebuilds `7124c3d`) and P4's `3b1b3cd` (it rebuilds `193dfc3`). As the code stands, 2 of the 8 items stop.
- Cause: P1's tip has two commits above its base and P4's three, a merge among them. The lead squashed them (lead.md:707). The rule keeps the tip's commit object and changes only its tree line, so the parent stays the tip's parent.
- A rule that reproduces both exactly (one match in 12 and in 36 combinations tried): parent := the base; tree := the tip's tree with the key's plants; message := the oldest commit above the base (P1 `e711a39`, P4 `9a85a15`); author and committer lines := the tip's (`8d6ba72`, `5ecd02b`). P2 and P3 reproduce under it too.
- Because each SHA matches, each copy's tree is the tip's tree plus exactly the key's plants and nothing else: the four keys are complete.
- Fix: write this rule into the amendment, and have P5 add it to `rebuild_copy`.

**W2. A1.3: "The briefs as dispatched".**
- Measured: `briefs/_verifier.md` and `briefs/_common.md` have mtimes of 16:39 on 2026-10-06, after P1's (13:42:27) and P2's (13:53:53) dispatches, and the ledger keeps no history of them. `_verifier.md:57-64` (item 8) names 15:35:17 and 16:39:34, after those two dispatches, so the current text is not what those two verifiers read.
- I ran QS4's `build_cut` on the ledger as it stands. P1's and P2's cuts are missing both files. P3's and P4's cuts hold them. Every other brief a verifier read is older than its cut (`briefs/verifier-P3.md` by one minute).
- So the replay of P1 and P2 would have no `briefs/_verifier.md`, though the dispatch text says the brief is there.
- Fix: say so as a limit, or restore the earlier text from where the lead holds it and record it as an adaptation.

**W3. A1.5 "(harness note 44)" and A1.8 "(harness note 43)".**
- Measured: the only harness-notes file in the repository, `Rounds/ParcelRound-R6/harness-notes.md`, has other rules under those numbers: 43 is "The lead's rulings after dispatch are items on each verifier's list", and 44 is "A ruling is checked against the status of the rows it touches".
- Round 1's own notes (lead.md uses 12, 29 and 43 for them) are in no file I can read.
- Fix: cite the ledger entry (lead.md 11:37:12 for A1.8's gap in the records) or name the file.

**W4. A1.6: the balance and the figures.**
- "After QS4 the balance is about $24" is stale. lead.md 13:26:42 puts Logan's top-up at about $10 and the balance at 34.23. The latest lane batch line I read says 34.17 (20:28 UTC).
- The default "a $20 top-up" is overtaken: Logan answered "Ill top it up again" and gave no amount.
- "N = 23 ... QS4's largest runs met 21 and 23" is true by the records (21 in `qs4-p4-real-20261007T163001Z`; 23 in lane C's `qs4-p5-real-20261007T183548Z`, which stopped there). lead.md 13:26:42 and 13:33:50 add that P5's real tip was lost three times at 23 and runs again at 35. The slice's N should be set from the drop rate at that time.
- $23.87 and $17.93 are right (I computed $23.8687104 and $17.9338368 from the repository's own `PriceTable` and QS4's caps) and they are off-peak figures. With `--allow-peak` they are $29.9328000 and $23.9979264. Say off-peak, and that the runs must start and end in the off-peak hours (here 03:00 to 18:00 and 21:00 to 23:00 on weekdays, PLAN.md section 4).

### Gaps to close

**G1. "As QS4's" scoring cannot locate P2-B, and holds P1-A badly.**
- `plant_span(blob, new)` (`qs4.py:470`) anchors on the plant's new text. P2-B's new text is empty (it deletes a block), so its span is lines 1-1. The block's true place in the planted file is the join after line 269 (real tip lines 270-275). The tolerance is 2 lines.
- Measured for the other seven plants: the span equals the line diff of the real tip against the planted file (P1 `qs1.py` 377, `qs1_cases.json` 582 and 600; P2-A the join after 294; P3 `qs6_items.json` 28 and 76; P4 `qs4_prompt.md` 26, `qs4.py` 1006).
- QS4's data gives each plant one key `index` (see `qs4_items.json`, `parcels.P1.plants`). P1-A is two edits (582 and 600), so one of them would not be registered.
- Fix: pre-register the spans from the line diff, widen the tolerance for deletions, and let a plant hold more than one edit.

**G2. The real-tip condition does not read alike for P1 and P4.**
- Shape: the planted copies of P1 and P4 are one commit above the base; their real tips have 2 and 3 (P4's has a merge). A model sees this with `git log`.
- The template: `render_messages` fills `parent ${parent}` from the base for both kinds (`qs4.py:791`, `qs4_prompt.md:26`). For those two real tips that sentence is false.
- The cut: lead.md:707 says the copy is one commit with the plants folded in, and (in P3's and P4's cuts, lead.md:1270 and :1679) that plants exist and "only reading can find them". For a real-tip run these statements contradict its repository.
- Fix: build each real-tip repository as the same squash minus the plants, so the two repositories have the same shape; or state it as a limit. The choice is the lead's.

**G3. Inputs the draft does not name** (items 3 below).
- The parcel's brief `briefs/P<n>.md` and `briefs/_common.md`: all four verifiers read them before their views. The draft's list names only `_verifier.md` and `verifier-P<n>.md`, and its "without ... (P1.md to P4.md)" can be read to drop `briefs/P<n>.md`.
- DeepSeek's documentation copies in the lead's scratch: verifier-P1 read D8, D9 and D10 (`briefs/verifier-P1.md` item 1 names `ds/chat_completion_full.txt` by line); verifier-P3 read `ds/quick_start_token_usage.txt`. They have no commit; they need digests. lead.md 10:50:11 says the first conversion of D10 is lossy.

**G4. QS4's cut checks refuse this round's ledger.**
- Measured: I ran `build_cut`, `substitute_sha` and `cut_problems` (the checks `cut_for` makes) over the ledger at the four stamps. All four planted items are REFUSED: "lead.md: a text the cut must not hold". The cause, separated by `cut_cause_a1.py`: the lead's entries name the real tip's short SHA (`8d6ba72` twice, `ceef2e2` once, `beb6176` twice, `5ecd02b` six times in the cuts). Round 6's entries named only the copy. No plant's old or new text occurs in any cut, so that part of the check passes.
- P4's real item is also refused: `substitute_sha` needs the copy's short SHA exactly once, and `3b1b3cd` occurs three times (the heading, the full SHA, `key-3b1b3cd.json`).
- P1 to P3 real items pass.
- Fix: a stated rule for both SHAs (which becomes which in each condition), as an adaptation. This is the lead's choice.

### Limits to state

- **L1. QS4's own limits carry over and are not listed.** The five in A1.10 are not QS4's 21. Those that apply: 1 no network; 3 a file that postdates the cut is absent (W2 is that case; QS4 names `briefs/P5.md`); 4 the replay's `date`; 5 the read-only copy; 6 the tools; 7 and 8 the screen and location by file and lines; 11 the two cuts differ by one SHA (false here: G4); 12 one run per item (here four); 13 the per-call cap; 14 the fixed escalation reply; 16 reasoning goes back with each request; 17 mount paths show host names; 21 the author address (answered, lead.md 12:48:48).
- **L2. The false-alarm set is told plants exist.** `briefs/_verifier.md:65-71` says the copy holds planted faults, and the dispatch entries say the same. Round 6's brief said "may" (verifier-P4 F2). QS4's prompt says "may" (`qs4_prompt.md:26`). Every real-tip run, which holds none, reads a brief and a cut that say there are some. P4-A (the prompt's "holds two") is clearest against round 6's brief, which is in round 6's ledger (an outside source); this round's `_verifier.md` also gives no count.
- **L3. P3-B (L06) needs round 6's ledger and an inference.** Without the key, R09 (A) shows from the items file alone: the question names verifier-P1 and all ten cited lines are verifier-P0.md's. L06 (B) shows only with the QS6 source mounted (`round6-ledger.zip`, 203,064 bytes, SHA-256 `286e7bd7...`, which I read from ParcelRound at `f42242e` and checked against the pin). The cited lines are stamped 17:20:54, 17:34:34, 17:35:41 and 18:38:25, and the planted bound is 18:00. The baseline compared a derived answer with the key, and also noted that the four cited lines fit a 19:00 bound (verifier-P3.md:41). A replay has only the second.
- **L4. Self-reference.** P4's copy and tip hold `qs4_prompt.md` (the template that frames a replay) and `qs4.py` (the screen and the judge). The model reads the rules that score it. If the slice's own dispatch reuses "It may hold faults the lead planted, as your brief says", P4-A shows by comparing the file with the model's own prompt. P1 to P3 are smaller cases of the same thing (the suites and the loop that run the replay). Also: the new items' names (`p1`..`p4`, and "P5" for the builder) collide with QS4's round 6 items.
- **L5. Compute and time.** The originals used the host: verifier-P1 ran about 23 minutes of mutation sweeps, up to 12 workers at once (verifier-P1.md, 14:24:56); verifier-P2 ran real containers, 14 Docker mutations and `docker manifest inspect` (a network read); verifier-P3 ran up to 7 pytest processes at once; verifier-P4 rebuilt QS4's inputs in about 15 minutes. The sandbox has 2 CPUs, 2 GiB, 256 pids, a 512 MB `noexec` `/tmp`, a read-only repository, and 300 s per tool call (`sandbox.py:183-188`, `qs4_items.json` budgets). The suite takes 159.7 s on this host. I started no container, so the sandbox's speed on a bind mount is unmeasured.
- **L6. Unplanted differences between a squashed copy and its tip.** P1's copy carries the first commit's message ("95 tests", "216 tests"; the tree has 96 and 217; verifier-P1 recorded it). P4's carries `9a85a15`'s ("$6.8059488"; verifier-P4's F3). A replay finding on either is true, and is not a plant.
- **L7. A1.8's fields exist only on records written after the commit** (lead.md 12:57:43: version 2; earlier records stay valid). DeepSeek's QS1, QS6 and QS4 documentation runs carry none; they are tied to code by times and the lane clones' commit (`86235a7`). The live entry's flags (`--max-unmetered`, `--retry-delays`, `--concurrent`, `--allow-peak`) shape which runs complete; the batch summary keeps `allow_peak` and the unmetered margin only.
- **L8. The plants burn when the ledger and `keys/` are published.** A1.10.4 covers models that predate the round. A model trained after the publication has the keys.
- **L9. The dispatch messages are rebuilt from lead.md's summaries**, not verbatim, and the verifiers read more of the directory after their views (later lead.md entries, other agents' files) than the cut holds. The cut does reproduce what they read to the line: lead.md at P3's stamp is 1,280 lines, as verifier-P3 says; at P4's, 1,686 against verifier-P4's 1,685.

### What each verifier read outside the repository, and A1.3's way to give it (item 3)

| verifier | read outside the repository | A1.3 |
|---|---|---|
| P1 | README; lead.md; `_verifier.md`, `verifier-P1.md`, `briefs/P1.md`, `_common.md`; DeepSeek's docs in the lead's scratch (D8 to D10); after its view P1.md, headings of P2.md, verifier-P0.md, cs7-reader.md, lead.md's tail to 14:20 | ledger cut yes (W2); `briefs/P1.md`, `_common.md` not named; the docs not named (G3) |
| P2 | the same with `briefs/P2.md`; Docker and the pinned image; `docker manifest inspect`; ParcelRound at `f42242e` through the P0 worktree, for the one command; in pass 2 `lowprio.py` and a clone of P2's branch | ledger yes; ParcelRound as an outside source yes; Docker and the registry read are L1 of the draft |
| P3 | README; lead.md to the cut (1,280 lines); `_verifier.md`, `verifier-P3.md`, `briefs/P3.md`; the answer key in its scratch; round 6's archive through `qs6_extract.py --parcelround`; `ds/quick_start_token_usage.txt` | key withheld, stated; archive as an outside source (needed by L06, L3); the doc not named |
| P4 | README; lead.md to the cut (1,685 lines); `_verifier.md`, `verifier-P4.md`, `briefs/P4.md`; ParcelRound at `f42242e` (archive, history, round 6's lead.md and verifier files, the case study's cost table); cft-fp256, HonestFramework and loganw.dev (twelve files); HonestHarness at `809ed2f` (round 6's plan); Docker; after its view P4.md, lead.md 20:22:44 to 20:55:17, verifier-P0r.md's verdict | outside sources yes, if the builder lists them from this file; `briefs/P4.md` not named |

### The sandbox (item 4)

- The project needs Python 3.12 or later, `httpx>=0.28`, `jsonschema>=4.23`, `pytest>=9` (`pyproject.toml`) and `git`. An `ast` scan of 59 Python files finds no other third-party import. `openai`, installed on this desktop, is not imported.
- The closure on Linux and Python 3.12 is 18 packages, which would be pulled from PyPI by pip when the image is built: anyio 4.9.0, attrs 25.3.0, certifi 2025.4.26, h11 0.16.0, httpcore 1.0.9, httpx 0.28.1, idna 3.7, iniconfig 2.3.0, jsonschema 4.23.0, jsonschema-specifications 2024.10.1, packaging 24.1, pluggy 1.6.0, pygments 2.21.0, pytest 9.1.1, referencing 0.36.2, rpds-py 0.24.0 (a compiled wheel), sniffio 1.3.1 and typing-extensions 4.13.0. Installed here they take 17.8 MiB (Windows layout; pygments is 8.4 of it). Wheel sizes I did not measure; I downloaded nothing.
- Docker tests: 17 skip with "docker: the docker command is not installed" (15 in `tests/test_sandbox_docker.py`, 2 in `tests/test_qs4_docker.py`). The one command, `sandbox/controls.py`, needs Docker and a ParcelRound clone. With no docker it REFUSES at `0af47f7` (exit 2) and crashes at P2's tip with a `FileNotFoundError` (exit 1), which is verifier-P2's V4.
- Network: none beyond 127.0.0.1. With no `docker` on PATH and a guard that refuses and logs any non-loopback connect or lookup (shown to refuse, in child processes too), the whole suite gave 712 passed, 34 skipped, 0 failed in 159.7 s, and no refused attempt was logged.
- The 34 skips: 17 Docker, 11 QS6 local files (7 need the key, 4 the archive), 4 QS4 local inputs, 1 symlink (this account cannot make one), 1 the table's selection file.
- Each parcel's own test modules pass on its rebuilt planted tree (exit 0 for all four; P3's with round 6's archive in place and no key), so no test of theirs shows a plant.
- The eight plants, in that same environment, by tests I wrote in scratch (each passes on the real tip and fails on the planted tree): P1-A, P1-B, P2-A, P2-B, P4-A and P4-B by tests; P3-A from the items file alone; P3-B only with round 6's ledger in place (the test is skipped without it). So all eight can be shown without Docker; one needs the QS6 source.

### Held (checked and right)

- The table's tips, bases and copies against the four keys, git and lead.md: ancestry, diffs, stamps, plant descriptions, four plants in Python and four in data or a prompt.
- The baseline: 8 of 8, each in the verifier's first pass (V1 and V2 in verifier-P2's view, F1 and F2 in the other three). "V3 and V4" are verifier-P2's view labels for its F3 and F4.
- The ruling stamps; what verifier-P3 was given (lead.md 17:29:08, verifier-P3.md:15).
- QS4's mean cost: 25 batch lines, mean $0.138 (planted $0.077, real $0.194), so "$0.13" and "$4 to $6" for 32 runs hold.
- A1.9: all 42 commits of `round1` carry one author and committer address, the owner's; five of them are already on `origin/main`. The closure of each real tip is 13, 13, 19 and 32 commits.
- A1.10.4: DeepSeek's V4.1-Flash was released 2026-09-10 and V4-Pro-0813 on 2026-08-13 (PLAN.md section 4), before the plants.
- The dispatch stamps are the stamps of the entries that record each copy and its sealed hash. The verifier's channel test followed the first three by 26 to 40 seconds (lead.md 13:43:07, 13:54:23, 17:29:34) and the fourth by about a minute (lead.md 23:06:38, N2).

### What I ran

1. `sha256sum` of the draft, before and after. `git clone --no-hardlinks` of HonestHarness into `<scratch>/r1-vA1/hh`; `round1` is `0af47f7`.
2. `facts_git.py` (keys against git), `rebuild_a1.py` and `squash_search.py` (W1), `reservation_a1.py` (W4), `spans_a1.py` and `spans2_a1.py` (G1), `cut_sha_a1.py`, `cut_cause_a1.py` and `cut_lines_a1.py` (W2, G4, L9), `ledger_headings.py` (QS4's stamp rule over the ledger: every entry heading parses and no file runs backwards; verifier-P0.md has one heading that is a literal format string, which is harmless).
3. `imports_scan.py` and an `importlib.metadata` closure (the sandbox's needs). `run_offline.py` (the whole suite, no docker, guard on) and `run_planted_tests.py`. `extract_trees.py`, `run_demo.py` and the four `demo/test_a1_P*.py` (the plants). One run of `sandbox/controls.py` at three trees with no docker.
4. Reading: lead.md to its 13:33:50 entry (the whole directory re-read before this entry), the README, both briefs, the draft, the four keys, PLAN.md sections 4 and 6, REQ's QS4, QS4's module docstring and cut code, the sandbox module, and after my view the four verifiers' files.
5. Read only: the lead's `records/batches.jsonl` (the checkout and the three lane clones), for the cost mean, the largest allowances and the balance. ParcelRound at `f42242e`: `git cat-file` and `git show` of the archive, with `GIT_OPTIONAL_LOCKS=0`, written to my scratch.
6. `docker ps` twice. No container, no image, no download, no paid call, no provider host.

### Disclosures

- I printed `PATH` once with `echo` to find where `docker` sits, and my scripts read it to remove Docker's directory and copy the environment to child processes (`dict(os.environ)`). I read or printed no other variable's value, and passed no provider variable's name to any code.
- I listed the scratch directory's top-level names, which include other agents' directory names. I opened none of their contents, except the one draft.
- My first `facts_git.py` asked for the copy commits in this repository, where they are not (they live only in the verifiers' scratch clones, which I did not read). My first look at the plants' spans compared the real tip's line numbers with the planted file's; `spans2_a1.py` corrects it, and the only result that changed is P2-A, which is right.
- My first run of `sandbox/controls.py` lacked its required arguments (exit 2, a usage error); I re-ran it with them.
- Not checked by me: that the copies survive in the verifiers' scratch clones (A1.3's last sentence). I read no other agent's scratch. verifier-P1.md:103, verifier-P4.md:169 and the lead's 12:46:43 entry say they do.
- Cleanup: I remove the copy of round 6's archive and my extracted trees' `local/` directories when I stop. My clone, scripts and logs stay in my scratch.

Believed:
- G2 and G4 can be settled by one rule: build each real-tip repository and each cut the way the planted ones are built, with the plants left out and both SHAs mapped to the item's, and record that as the adaptation.
- None of this makes the replay unsound. It makes the amendment's "as in QS4" claim narrower than it reads.

For: the lead (to correct the text before it lands as AMENDMENT-1.md); P5 (W1, G1, G4, L4); Logan only if the lead judges that G2, G4 or L2 changes a decision.
