# cs7-reader's ledger (round 1)

Append only. Each heading's time is taken from `date`.

## 2026-10-06 11:23:59 -0700 - cs7-reader: what CS7 holds for this round, and its gaps against the drafted wave-1 briefs (ParcelRound CASE-STUDY-7.md at 894d125, 751 lines)

Measured:

How to read this. "L" is a line of CS7 unless prefixed (CS5, CS6, PLAN, REQ, lead.md, README, zip README, a script's name, or a file of the ledger). 195 citations below were checked by script against their sources before this entry was written. A line starting "->" is my inference, so it is believed; the rest was read from a source or counted by a command. I read CS7 and CS6 whole through `git show` (my scratch extracts are byte-identical to their blobs), three passages of CS5 the same way, the plan, and `archive/round7-cost-scripts.zip` at 894d125 (a README and 8 scripts, extracted in my scratch). Before this entry I re-read the whole ledger directory, including the drafted wave-1 briefs, verifier-P0's verdict and the lead's entries to 11:21:19. The test escalation went to main first (SendMessage: queued for main's next turn). I did not enter `cft-worktrees`, ran no git command that writes, made no network call, and read no environment variable. CS7's map: setting L58-120, run measured L121-181, step 6 timeline L183-209, eleven observations L211-462, cost L464-520, nine proposals L522-582, state at the writing L584-609, checking L614-751.

**Against the drafted wave-1 briefs** (`briefs/_common.md`, `briefs/P1.md` and `briefs/P2.md` as I read them for this entry; I did not review them)

Already in the drafts: the hand-back and desktop rules (briefs/_common.md L46-47, briefs/_common.md L168-169); the shared files named as the lead's, with P1's `qs/suites/__init__.py` left empty (briefs/_common.md L33-41, briefs/P1.md L106-107); a clone, not the worktree, for the gate run (briefs/P2.md L87-92); entries cited by stamp, not by line (briefs/P1.md L125-126); design first with an intent echo (briefs/_common.md L105-128); a request for what the brief got wrong (briefs/_common.md L179).

Gaps, each argued below:
- (a) The send-back rule is in none of the three. I searched them for "send-back", "regression" and "wrong answer". briefs/_verifier.md L58-66 has it, and CS7's briefs without it were mostly parcels' (L83-91).
- (b) briefs/P2.md L87-92 names f42242e but does not ask P2 to assert that its clone is at it (HEAD and tree hash) before mounting, nor to run the gate on the host at that commit and compare its verdict with the container's. Prefer `--mount type=bind,readonly` to `-v`, since a missing source then refuses instead of being created (prior knowledge, not CS7). Carry all three into P4's brief.
- (c) A resume note at each step, for P2 at least. Neither `_common.md` nor `P2.md` asks for one.
- (d) briefs/P2.md L27-30 has the loop record every message but not what it writes when a tool call or the sandbox raises. verifier-P0's first sent-back finding is that a run that raises loses its billed spend (verifier-P0.md L60-71), and it says a loop raising inside `run_item` takes the same path (verifier-P0.md L34). P0's fix plan makes the spend line per call and the batch summary unconditional (lead.md L254-258). P2's brief should still say what the loop records when its own tool call or the sandbox raises.
- (e) The verifier briefs for P1 and P2 are not written yet. Give each a pass budget, and scope its re-checks to the previous diff.

Later: the replay's 40 M cap may truncate a weaker verifier (wave 2). For the case study, count by script, include the lead's own session, and take each agent's model from its responses.

**1. The round in brief**
- What and when. One lead session on cft-fp256, an FPGA floating-point tile project (L60-65): a discussion on 09-24, then eight rounds from 09-25 to 10-05, each rolling into the next (L1, L3-5). They built certificates, a seventh RTL revision, an auditor in C, a language and compiler for dynamical systems, and step 6 (L67-75). Step 6 is recorded closely, with its two-day pause and its resumption (L7-9, L183-209).
- Scale and duration. 8 rounds, 130 ledger files, 42,448 ledger lines, 118 briefs (L125-135); 419 commits, 259 agent runs (L149); 129 agents, 241.4 agent-hours (L493-499). Step 6 alone: 44 agents, 14,273 ledger lines (L134), a 2,642-line lead ledger (L441-443). 11 days, with breaks of about 38 and 44 hours at the owner's word (L160-163) and five shorter stops, two of them usage limits (L164-174).
- Models and roles. CS7 names no model except the owner's "Sonnet" (L389). The parcels stay on the "larger" model, and from 10-05 the verifiers moved to the "smaller", the reverse of CS6's pairing (L113-117; CS6 L48-49). 43 parcels, 71 larger-model and 6 smaller-model verifiers, 9 others (L493-499), and an integration verifier on the lead's merges in every round (L106-109). Measured: both CS7 commits (8b6d6d4 and 894d125) carry the trailer Claude Opus 5.5, and REQ says so of every cft-fp256 trailer since 09-23 (REQ L56). Believed: "larger" is Opus 5.5. The parcels' model is not stated.
- Ending. None. It was written during the run (L3), with its state at 10-05 about 10:40 plus an addendum to about 12:45 (L584-609), and it will gain a section when the round ends (L611-612). Four smaller-model verifiers checked it in four passes, 282 minutes in all (L618, L652-653, L691-692, L739-740).

**2. What bears on this round**

The method's rules
- Briefs. The send-back rule has been practised since 09-27 (L81, L83-85). 94 of 112 briefs state it, and 15 of the 18 that do not are parcels' (L83-91). The hand-back rule is in 17 of step 6's 44 briefs as the owner's full sentence and in 36 in all, by a verifier's count, and all 44 carry the desktop rule (L92-97). CS7 itself gives 18 (L86-90) and 19 (L437-439, L687-689) for the briefs without the send-back rule. The point stands either way.
  -> gap (a). The hand-back and desktop rules are already in the drafts.
- The lead's work. Six findings stopped a push on 10-05, four of them in the lead's own work (L230-241), and every round had a verifier on it (L106-109). Proposal 3 has the lead read each constant, count and list member from the code when it restates a decision (L535-542), and both findings of the second pass were such restatements (L277-280).
  -> the plan's integration verifier and its verifier on the lead's code (PLAN L501, PLAN L559-560) are not optional. R1's first verifier pass on P0 sent back five findings and restated eight (verifier-P0.md L53-55). PLAN L551-552 (values from commands) covers restated decisions in briefs too.
- Re-check loops. A text loop converged in 3, 2, 0 findings once each re-check was scoped to the previous diff (L265-280). Proposal 4 lets a re-check use the smaller model and gives it a budget (L543-549). CS7's own checking loop did not reach zero: 17, then 11, then two wrong sentences and five misleading ones (L709-712, L739-747). It stopped on a pass budget, stated as a known limit (L714-715, L746-747).
  -> gap (e). Expect the lead's fixes to bring new errors in their own wording: R1's 10:50:24 correction of a line citation was itself corrected at 10:50:32 (lead.md L139-149).
- Design stops, probes, pending items. Three plans went to the owner before code, and every answer CS7 shows took the recommended option (L110-112, L190, L193, L194-195). Probes took about three hours of box time against 2.6 to 7.5 hours per image and changed the plan twice (L370-386). All nine proposals are the owner's to settle (L522), and proposal 8 asks that carried notes reach an entry (L570-576).
  -> matches R1's approval (PLAN L667-668; data for REQ H16.4, REQ L977-980) and its single flash run first (PLAN L530-531). Cite proposals as proposals, never as METHOD rules (the fault of CS6 L114-150). lead.md should record what wave 1's briefs took from this report, which is such a note.
- Shared indices. All six of the lead's merges on 10-05 conflicted on a document index of counts, and once taking one side whole dropped a parcel's edits (L315-329, L524-534).
  -> a skim of P0's tree at f680bfd (not a review) found none: suites are classes, run records are one file per suite, the gate globs `git ls-files`, `registry.json` lists endpoints, and the drafts keep wave 1 off `README.md`.

Model behaviour
- Smaller-model (Sonnet) verifiers, the owner's trial from 10-05 (L388-439; direction at L389). Six had finished by the writing (L393-402), 32 to 180 minutes each. No false finding, and five of the six found what an earlier check had missed (L404-405). They kept their briefs' rules, with one departure they disclosed (L406-409). Per first run they used more tool uses and more cache reads for the same time: medians 228 against 165 tool uses, 81 M against 51 M cache reads, 53 against 55 minutes (L414-419). CS7 itself calls six runs few, in two groups with the median between them (L425-427), and says any saving is the price per token (L428). Then VC34 found a narrow wrong answer and four coverage gaps in 215 minutes, and VCS7's own report held a wrong count, the first such error found (L429-439).
  -> the best Claude-side datum on Sonnet in the verifier role: code parcels as well as text, and no invented findings. If R1 moves a verifier to Sonnet, record its yield by model (proposal 7, L562-565). verifier-P0 is on Opus (lead.md L93-96).
- No plants, no threat model, no other models. The word "plant" does not occur in CS7, "threat" occurs only as a pointer to CS6 (L275), and no DeepSeek, Qwen, GPT, Gemini or open-weight model is named. The nearest Sonnet plant datum is CS5: two Sonnet verifiers each caught their 2 of 2 planted faults, one pair by diffing a tip the ledger named, and the lead later caught what they had missed (CS5 L158-165, CS5 L381-384).
  -> PLAN L61-63's ten of ten is Opus only. CS7 adds nothing to the planted baseline, and the replay stays the first measurement of the method on a non-Claude model.
- A long-running lead. Its context was continued 14 times from a summary by the writing (L285-286). CS7 speaks of continuations, not compactions, and found its draft's claim of a compaction unsupported (L636). It read its ledger after 14 of 15 continuations and a memory file after 7, by a verifier's count (L300-304). On 10-05 it slipped on seven mechanical items (L242-251), and guards stopped three of them before anything was built (L253-257). API failures stopped agents mid-task on five days (L287-289), and twelve notifications carried no usage because the run was cut off (L477-485).
  -> slips happen with notes in place (see "the guard, not the note"). A cut-off run loses its figures unless usage is kept per call. CS7's runs with no usage notice and verifier-P0's first sent-back finding (verifier-P0.md L60-71) are one shape: gap (d).

Cost and tokens
- Figures (L493-500), agents only: 129 agents, 259 runs, 241.4 agent-hours, 36,953 tool uses, 386.7 M fresh tokens, 14.42 G cache reads. Step 6 alone: 43 agents, 62.9 hours, 83.4 M fresh tokens. The 77 verifiers and the 43 parcels used about the same fresh tokens, a parcel about twice a verifier at 4.5 M against 2.5 M (L504-510). There is no money figure anywhere. The lead's own session is in no row (L485-486), though CS6 counted it (CS6 L319; 30 percent of CS6's output, CS6 L322-324).
  -> Claude-side scale only. R1's table should count the lead.
- How measured (L466-491). From each agent's own transcript, once per message; fresh tokens are input, cache writes and output, with cache reads apart (L474-476). The draft had summed task notifications and was wrong: a notification's token figure is the context size at the run's end, and 22 of 277 repeat a run (L469-474). By run, 168.9 M "tokens" and 277.0 hours became 154.8 M and 238.2 hours, plus 3.2 hours from four runs with no notice (L511-515). The scripts are archived but read unpublished transcripts (L488-491).
  -> a meter needs a second source that can say no. R1's balance reconciliation is one (PLAN L336-337). Archive the extracts behind R1's figures so they can be remade. A live instance of the trap: lead.md L197 records the runtime's token figure for verifier-P0 as its usage, and by L469-474 that figure is context size at the run's end, so the case study should take tokens used from the transcript.
- Reusing the scripts (read, not run). They read Claude Code's session files, the lead's JSONL and `subagents/agent-<id>.jsonl` with its `.meta.json` (zip README L12-14). To change first: classes come from cft-fp256's agent descriptions (cost2.py L43-52), UTC-7 and step 6's start are constants (cost2.py L22-23), the model is guessed from the meta file, "sonnet" in it or else "opus" (cost2.py L46-47, cost3.py L24-26), and the lead is not counted.
  -> a third model would be labelled opus, from dispatch metadata and not the response (REQ L934-939; CS5 L385-386).
- The replay's cap, and cache share (derived). The cap is 40 M tokens read (PLAN L521-523) against CS6's Opus verifiers at 16.6 to 22.6 M (PLAN L519-520), so the cap is 1.8 to 2.4 times their reads. CS7's Sonnet verifiers read 1.6 times its larger-model ones (L414-419; six runs against 71), which on CS6's tasks gives 26 to 36 M, so the cap would be only 1.1 to 1.5 times the need. Cache reads are 97.4 percent of all tokens counted, and 97.0 percent for the larger-model verifiers (L495-499).
  -> a capped DeepSeek verifier may stop short, recorded as stopped (PLAN L590-593). A loop mostly re-reads its history, so the plan's 90 percent hit assumption (PLAN L524-527) is plausible in shape. DeepSeek's cache is best-effort, and the first flash run measures it (PLAN L530-531).

Verification
- Layers. Each of five layers caught a class the others missed (L213-228). Two carry over: a gate that failed only on Linux, because a new check wrote a private key under the umask, which Windows does not test (L221, L228), and an integration regression that each parcel was consistent with alone (L196, L221).
  -> P2's sandbox is Linux and the desktop gate is Windows, so the host gate cannot see container-side failures: gap (b).
- A sentence a change made false. VI5 found one that a merge made false (L222). Applied here: P0's README says there is no code yet (README L8) and later that `qs/` is the first code (README L37). verifier-P0 found the same (verifier-P0.md L111, and the lead's fix plan covers it, lead.md L283), among eight restated claims in P0 (verifier-P0.md L97-114), the shape of the nine in the lead's own work in CS6 (CS6 L254-257).
  -> read README and the case study against each merged tree, and restate from the code (proposal 3).
- The checkers' findings in CS7's own draft: a cost method that summed the wrong quantity, a miscounted directory, universal claims the records did not support (L625-640), and a finding credited to one finder where the record shows two (L655-660). A fourth pass still found seven (L739-747). The lead wrote it in a checkout whose main was behind the remote and briefed its three passes with the same premise (L717-723): a remote's state read from a local copy (L725-726).
  -> for R1's case study: count by script, say whose count each figure is (L674-687), avoid universals, and measure outside state at dispatch. lead.md L47 gives GitHub main as f42242e, as CS7 did on 10-05 (L724-725). I did not re-measure it (no network use), so a `git ls-remote` before the ledger is published would settle it.

Long-round lessons
- Interruptions. Two breaks, five stops, fourteen continuations and API failures cost nothing that was written down (L282-313). A dropped agent was resumed by message with its context and 8 files of uncommitted work, and after its third drop was asked for a resume note at each step (L290-293). Each break began when the agents had wrapped up (L162-163). On 09-30 every agent committed and wrote a resume note within nine minutes, yet the agents did not survive the pause and were dispatched again from brief plus note (L294-297).
  -> gap (c), and expect re-dispatch from brief plus note.
- Long ledgers. The lead's 2,642-line file stayed usable through dated headings, a memory file of state and resume list, and briefs that cite lines (L441-447). Whole reads happened only at 31 to 328 lines, and the integration verifiers read 851 and 989 lines over several reads (L448-452; verifiers' counts).
  -> the drafts cite entries by stamp, which suits an append-only file. `lead.md` is 305 lines now, against CS7's largest whole read of 328 (L448-452), and briefs/_verifier.md L42 has every verifier read it whole. For the P1 and P2 verifiers, point to the entries that matter by stamp.
- Limits and batches. Two usage limits stopped the round and cut off four runs (L164-170, L482-484). The bottleneck was the owner's answers and the box, not the agents (L454-462). When the desktop was busy the lead built a batch runner: an agent lists its runs, and the lead runs each in a fresh copy of its commit and returns the results (L596-609; proposal 9, L577-582).
  -> R1 has this shape (lead.md L24). A Claude usage limit stops the lead but not a runner already started, so the prepaid balance and the guard are the stop that does not depend on the lead (PLAN L253-257, PLAN L331-347).

Harnesses, tools and automation
- The guard, not the note (L345-368; proposal 5, L550-555). Three traps recurred on 10-05 though written down: a Windows make's flags, WSL re-parsing arguments, and an unquoted heredoc that runs backticks (L346-352). The lead's memory held two of the four and the briefs' ground rules the other two, but the project's CLAUDE.md none (L353-358). Two were new: a git worktree's `.git` file names a Windows path that Linux git cannot follow, and a running script cannot be edited safely (L361-365). What worked were scripts that assert the commit, the tree hash and the content before they build (L366-368).
  -> R1's thesis (PLAN L73-76) seen on Claude. For P2 and P4 see gap (b), and fail closed: a failed clone once left a build in the main checkout (L245-246, L254-257). Trust a runner once it reproduces a known red (L606-607). The heredoc note is already in the drafts (briefs/_common.md L163-164; lead.md L103-107), and will recur anyway.

**3. What CS7 updates or contradicts**
- Models. CS6 had parcels on Sonnet 5.5 and verifiers on Opus 5.5 (CS6 L48-49). cft-fp256 reversed that pairing from 10-05 (L113-117). R1 runs parcels and verifiers on Opus (PLAN L288-290; lead.md L93-96), which matches neither, and rung 0 (PLAN L61-63) is no longer one reference.
- Cost. CS6's tally counts the lead and reads input plus cache reads and writes (CS6 L295-297, CS6 L319). CS7 omits the lead and splits fresh tokens from cache reads (L474-476, L485-486). PLAN L519-520 rests on CS6's rows and stands by its definition.
- Loops. CS6 obs 1 and 2 are cited correctly (L272-276; CS6 L84-112) and extended to text loops (L265-270, L709-715). PLAN L590-593 limits DeepSeek's loop by turns and tokens, and Claude-side verifier passes also need a pass budget.
- Unchanged. Ten of ten planted faults stays the only planted baseline, since CS7 has none. METHOD sections 2, 5 and 7 keep their numbers at f42242e (L54-57). I found no CS6 fact contradicted, and nothing touching the plan's provider facts or spend arithmetic.
- REQ's forced full ledger read after a pause (REQ L650-654, REQ L690-695) did not match CS7's practice: whole reads stopped at a few hundred lines (L444-452), and the lead's file alone was 2,642 (L441-443). The state card (REQ L634-638) should carry the resume state.

**4. Quotations I rely on** (CS7, exact, each under 15 words)
- L81: "Only a regression or a wrong answer sends a parcel back."
- L262: "the lead is the agent with the least pre-checked work"
- L389 (the owner): "switch to Sonnet models for verifiers"
- L404-405: "Five of the six found something an earlier check had missed"
- L428: "Any saving is the smaller model's price per token, not a lighter task."
- L366: "What worked was not the note but the guard"
- L535-536: "reads every constant, count and list member from the code"
- L714: "The third pass was the budgeted last one."
- L725-726: "a remote's state read from a local copy, not measured"

Believed:
- Every "->" line, and "larger" meaning Opus 5.5 (the trailers show the lead only).
- Gaps (a), (c), (d) and (e) rest on searches of the drafts that found nothing, run by the script. Gap (b) rests on my reading of briefs/P2.md L87-92. The drafts are as I read them at this entry's stamp, and the lead may have edited them since.
- The cap's margin and the cache share are my arithmetic on CS7's table and CS6's rows. They carry the caveats stated with them: six runs against 71, two groups, different work.
- CS7's two counts of briefs without the send-back rule (18 and 19) are unresolved. I did not recount them, since the briefs are not published.
- Several CS7 figures are a verifier's count, not the lead's (hand-back wording L94-95, continuations and ledger reads L303-304, ledger read sizes L450-452). I name them as such where I use them.
- The skim of P0's tree is not a review of P0, and my reading of the drafts is not a review of them.

For: the lead, before wave 1's briefs are final (the gaps list). Again for wave 2 (the cap, the replay's sandbox) and for the case study (cost method, shapes to avoid).

## 2026-10-06 11:25:15 -0700 - closing: the model I run on, and no background processes

Measured:
- My system prompt names the model as Sonnet 5.5, model ID claude-sonnet-5-5.
- I started no background command, watch, server or container, so none needed stopping.
- The test escalation "cs7-reader: channel test" went to main first. SendMessage reported it queued, and the lead recorded receipt at 10:46:31 (lead.md).

Believed: nothing.
For: the lead
