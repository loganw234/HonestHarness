
## 2026-10-08 18:53:01 -0700 - verifier-I2: channel test

Measured: the README; lead.md from its 2026-10-06 22:00:27 entry to its last entry, 2026-10-08 18:51:07; briefs/_verifier.md; briefs/verifier-I2.md. The ledger listing, taken at 18:51, shows that after 14:00 today only lead.md and briefs/verifier-I2.md changed. The model is Haiku 5.5, claude-haiku-5-5, as my system prompt names it. Pass 1 has not started.
Believed: nothing yet about round1 at 3ba21fb. This entry only tests the channel.
For: the lead, which is asked to confirm receipt of this test before the clone and the first pass begin.

## 2026-10-08 18:54:18 -0700 - pass 1 opens: the lead confirmed the channel test at lead.md 18:53:08; the clone at 3ba21fb; a brief error in item 5

Measured:
- The lead's message, received in conversation, says the channel test was received (recorded at lead.md 18:53:08) and that I should clone round1 and start pass 1.
- The clone is `<scratch>/r1-vI2/round1`, made with `git clone --no-hardlinks` from the P0 worktree and checked out at 3ba21fb. `git rev-parse HEAD` prints 3ba21fb3f794781c10220b4356fd8eafcc3cad28, and `git status --porcelain` prints nothing. I ran no git command in the P0 worktree; the clone reads it only.
- `briefs/verifier-I2.md` item 5 says "Read item 11 (Haiku)", but the list has ten items and no item 11. I read that sentence as the case study's Haiku claims, checked against lead.md 11:30:06, 12:49:09, 13:18:10 and 14:02:40, and its round-end claims against 18:12:17 and 18:24:09. The rest of my list is unchanged.

Believed: nothing yet about the work.
For: the lead; verifier-I2 at pass 1

## 2026-10-08 19:03:01 -0700 - pass 1, items 1 to 3 and the table of item 4: no regression or wrong answer found; two restates and one known limit to state

Measured (each from a command I ran in my clone at 3ba21fb; scripts in `<scratch>/r1-vI2/`):
- **Item 1, the merge 022abee.** Its parents are bd92fd5 and c3be1ef. c3be1ef is the tip verifier-P5 found READY in its pass 2 (verifier-P5.md, 23:11:21). `git merge-tree --write-tree --no-messages bd92fd5 c3be1ef` exits 0 and prints tree 877d9340ad6a6585fdaecdda767495ba36873bfb, which is the committed tree. Against its first parent 022abee adds 14 files and 6,067 insertions.
- **Item 1, the planted copy.** I fetched the copy commit ea8ba0b0e14956eaa34ec78532c4be4a70176f2c read-only from its clone into my clone. Its parent is the base 17757655aa069077287acd6d36014d08db5ff96f. Its real tip, which the key names, is 54ce53f; c3be1ef differs from 54ce53f by 7 files, 225 insertions and 26 deletions, which are verifier-P5's pass-2 fixes. `git diff -U0 54ce53f ea8ba0b` names exactly two files, qs/suites/qs4h.py (one line) and qs/suites/qs4h_items.json (two in_view lines): plant B and plant A's two edits, as keys/key-ea8ba0b.json gives them. The key's SHA-256 is 02c28ebcca437e79adce8415be5bc70fb56b864f5e77e559c9bb63a7d9212aaa, equal to the hash lead.md sealed at 17:13:05.
- **Item 2, the eight unread commits.** I read each diff in full. Each changes what its entry says: 48d1008 (1 file), db94d41 (5), b0157ce (2), 86235a7 (4), 0af47f7 (5), 1775765 (1, tests), dfb7b25 (2) and 85c7c31 (2). Each restated sentence I checked is true of its code:
  - table.py's "a batch is listed from its summary line in batches.jsonl" holds: load reads batches.jsonl, and select refuses a named batch that is absent from it;
  - "grep -n puts no space": `printf 'a\n' | grep -n a` prints `1:a`, and the read script writes "N: " (sandbox.py, scripted.py);
  - hold() and recheck() match their restated docstrings: hold returns None for ok or concurrent, and recheck refuses a concurrent batch;
  - the retry docstring: a call is retried once per delay (suite.py:277-285), and the batch stops when a call has no delay left or the allowance is spent;
  - dfb7b25's "No match or count reads the class": the recorded class is copied into the score (qs4h.py:920), but no match reads it, and counts() tallies only the model's own finding classes (:929).
- **Item 3, the judgements.** bd92fd5 commits 89 QS4 judgements, all checked_by verifier-J. I compared each with verifier-J.md's per-judgement list (lines 90 to 254): 85 verdicts agree, with no mismatch in any verdict or in any matched recorded id. The four settled verdicts are committed as settled: 190152Z p2-real f3 is a match to P2-r1; 132806Z p5-planted f3, 151656Z p5-real f3 and 151656Z p5-real f5 are new and true. a065686 commits 87 QS4h judgements, all checked_by verifier-JH. I compared each with verifier-JH.md's per-run list (its FINAL entry, 08:37:51): all 87 agree, including the recorded ids. Both files pass their suite's judgement_problems, with zero problems. The counts: QS4 caught 31, missed 9, match 15, new and true 19, false alarm 15; QS4h caught 31, missed 1, match 28, new and true 25, false alarm 2.
- **Item 4, the table, in part.** `python tools/table.py --json` from my clone reproduces TABLE.md below its 7-line header, 240 lines, after carriage returns are removed. On this host the script's own stdout carries 240 CR bytes, and TABLE.md carries none. The selection holds 82 included and 34 named batches left out. 6 probes have no runs and are not named. All 122 batch summaries agree with their run records: the run count and the spend-line count match, and computed_usd equals the sum of the call lines, in every case (0 mismatches).

Believed (not measured):
- The eight QS4 exclusions with an I/O error reason (qs4-p1-real 170750Z and 172454Z, qs4-p2-real 170750Z, qs4-p3-real 170750Z, qs4-p4-real 173035Z, qs4-p5-planted 174903Z, qs4-p3-planted 172638Z and qs4-p4-planted 174423Z) are left out for the reason given. The committed records hold no I/O error text for them, so the reason rests on lead.md 11:03:35 and on verifier-J's transcript check (15:17:50). I did not read the transcripts.

Restates and limits, by my classes (no sent-back finding yet):
- **R-I2-1, restate.** "byte for byte" (lead.md 18:51:07, "TABLE.md is tools/table.py's output below a header, byte for byte") holds only after line endings are normalised. On this host the script writes CRLF. Say "line for line" or name the normalisation.
- **K-I2-1, known limit.** The drafts named by SHA-256 in lead.md (14:10:01 and 07:54:20) match no file now, as lead.md 18:51:07 discloses. The committed verdicts trace through verifier-J's and verifier-JH's per-judgement lists, not through those hashes. Keep the disclosure with any citation of those hashes.
- **N-I2-1, note for verifier-P5's text.** Its limit-17 restate (dfb7b25) says nine mutants survive on the Docker lines and names five groups. verifier-P5.md's enumeration of those groups totals eight mutants (2+1+1+2+2). The restate states no count, so it is not wrong, but one survivor is unnamed.

Next: the gate (background, one run then --control), then the case study (item 5), the notes (6), privacy (8) and item 9.

For: the lead; verifier-I2 pass 1

## 2026-10-08 19:13:41 -0700 - pass 1, items 4 to 6, 8 and 9: the numbers hold where the records reach them; the case study has eleven sentences that claim more than their source, and two note figures to fix; two privacy items to settle before the archive

Measured (my clone at 3ba21fb; each value was computed by a command or read from a named file):
- **Item 5, values checked against their sources (30 or more).** Each is named by its source; a value matches unless I say otherwise.
  1. QS4: 31 of 40 plants caught; 24 of 24 figure or reference plants; 7 of 16 meaning or shape plants; by pass 8, 8, 8 and 7 (start-order rank). Source: bd92fd5's committed judgements.
  2. QS4: 49 findings, split 15 match, 19 new and true, 15 false alarms (bd92fd5).
  3. QS4: P1-r1 matched in 6 of P1's 8 runs; P4-r1 in 2 runs, one of them a real tip (194018Z) (bd92fd5).
  4. QS4: 18 of 20 real-tip runs reported; 8 READY (table.json, the qs4 rows).
  5. QS4: the 40 scored batches computed $5.7367 (case study $5.74), read 468,845,407 tokens at 98.83% hits (469M, 98.8%), and wrote 5,872,937 output tokens (5.9M). The 18 left out computed $2.4667 ($2.47).
  6. QS4 spend, all QS4 batches including interrupted ones: $8.652055 (the cost table's $8.652).
  7. QS4h: 31 of 32 plants by judgement and 26 by screen (table: judged sum 31, screen sum 26). Source: a065686.
  8. QS4h: seven plants caught in all four runs; P3-B missed once, in pass 4 (091310Z) (a065686).
  9. QS4h: 55 findings = 28 match on 8 recorded ids + 25 new and true + 2 false alarms (a065686; the 25 include the 2 replay findings).
  10. QS4h: of the 19 in-view recorded findings (RECORDED in tests/test_qs4h_data.py), 6 were matched at least once; P1-v6 in 6 of 6 reported P1 runs, P4-v1 in 8 of 8, P2-v2 in 5 runs.
  11. QS4h: 14 real tips reported; 4 READY (table).
  12. QS4h: the 30 scored runs computed $7.3838 (case study $7.38), read 449,137,741 tokens at 98.97% hits (99.0%), and wrote 5,137,673 output tokens (5.1M). The 7 lost computed $2.3027 (case study $2.30). The total is $9.764658 (case study $9.76, with the interrupted runs).
  13. The spend file's totals by suite: QS1 $0.073711, QS6 $0.810723, diagnostics and probes $0.003125, all $19.304271 (case study $0.074, $0.811, $0.003 and $19.304).
  14. QS4h: 37 run records, all version 2, all naming dfb7b25.
  15. Haiku, as stated at 11:30:06, 12:49:09, 13:18:10 and 14:02:40: QS4h 7 of 8 plants, 60 findings (35 match, 20 new, 5 false); QS4 9 of 10, 47 findings (21, 13, 13); 16 of 18 across both; DeepSeek 62 of 72 (31 + 31); Claude verifiers 18 of 18 (10 + 8). The sums are right. I did not re-judge the Haiku runs.
  16. Findings per run: Haiku's 47 over 10 runs is 4.7; DeepSeek's 49 over 38 reported runs is 1.3; false alarms 13 of 47 and 15 of 49.
  17. QS1's included thinking-on batch: 15 refused (table). QS6: 659 of 660 exact (table). QS1: 43 of 101 turns with empty reasoning (lead.md 15:00:40).
  18. Two runs ended on WinError 10054 (records qs4h-h3-real and qs4h-h4-planted). h3-real cost $0.500965 at peak (its record). h4-planted's record ends at 09:12:59 UTC, which is 02:13 local, as the notes say.
  19. verifier-P4: 265 mutants, 212 killed (lead.md's stamp 21:47:05 in verifier-P4.md). QS4's run budget: 6,000 s (qs4.py:80).
  20. The lead's 14:08:26 figures: 3,055 attempts, 346 closed with no reply, 11.3%. I did not re-derive them (no transcripts read).
  21. Timeline stamps in the ledger: 17:08:40, 18:35:19, 19:11:24, 19:37:52, 12:26:15, 15:00:40, 20:33:53 and 18:12:17. The 18:12:17 quotation matches lead.md's text word for word.
  22. The table: 122 batch rows; 82 entered, 34 named and left out, 6 probes unnamed.
- **Item 4, the exclusions checked against the records.** All 7 QS4h exclusions and 10 of the 18 QS4 exclusions (the 8 I/O-error runs are under Believed). Each stated reason matches its record:
  - the two content-filter refusals (100101Z and 101508Z, status error, "Content Exists Risk");
  - 100330Z, a pass whose run record time (10:12:53 UTC) precedes db94d41's commit (10:33:54 UTC);
  - 104245Z, with 10 closes at its allowance of 10;
  - 144815Z and 154444Z, stopped on one call's third close, with 14 and 5 closes below their allowance of 30;
  - four runs at an allowance of 23 (183548Z, 195306Z, 200042Z and 200155Z: 23 closes each);
  - the QS4h runs stopped at their allowances (h4-real 28; h1-real 075642Z and h2-real 113521Z, 40 each) or after their retries were spent (h1-real 100017Z and 110550Z, 35 and 39 closes, below 40), and the two connection resets (h3-real and h4-planted).
- **Item 4, the records.** All 122 batch summaries agree with their run records (run count) and their spend lines (line count, and the sum of the call lines, which equals computed_usd in every case). The gate's schema check reads 11,657 record lines, all valid.
- **Item 6, the notes.** All 11 HH:MM:SS stamps cited in harness-notes.md exist as headings of ledger files. Of the four HH:MM times: 01:20 is in lead.md's 18:35:19 text; 02:13 is the h4-planted record's end time; 06:01 (note 51) and 09:41 (harness-notes.md line 170) appear in no ledger file or committed record.
- **Item 8, privacy.** I scanned the 55 ledger files, and the 63 files committed since 866a292 with their commit messages. No absolute path with a drive letter, no key shape, no assigned secret and no owner address. Emails are only example.invalid placeholders and the anthropic.com addresses in attribution lines. The owner's name appears in the ledger and in committed files, as his words or as names the repository already carries.
- **Item 9, verifier-I's first pass.** R1 holds: verifier-P3's F1 (qs6_items.json:27-29, item L06) is plant B, and its F2 (:75-77, item R09) is plant A, per keys/key-83ee196.json. R2 holds: batch_rows, the footer and the limit all say "every batch with a summary line", and load reads batches.jsonl. R3 holds in the committed selection ("billed at about half; a holiday is believed"). The case study still states the holiday as fact (C1 below).
- **Item 7, the gate so far.** `python tools/check.py` at 3ba21fb, with DOCKER_HOST at the closed port and GIT_OPTIONAL_LOCKS=0: "tests ok 805 passed, 40 skipped in 252.65s"; schema ok, 11,657 record lines; guard ok, 26 fixtures; privacy ok, 131 files and 55 commit messages; livegate ok, 68 Python files; "PASS: 5 of 5 checks hold"; exit 0. The control run and the skip reasons are still to come.

Restates and fixes. No finding is sent back; each is a sentence that claims more than its source holds.
- **C1, case study lines 186-188 and 453-454, and timeline line 57.** "A Chinese public holiday is billed off-peak all day", and "a Chinese public holiday is billed off-peak, at about half (18:35:19)". 18:35:19 measures the bill (about half) and believes the cause: its "Believed" section says no calendar was read. Fix: "the bill was about half the peak computation for 2026-10-07; a Chinese public holiday would explain it (believed, lead.md 18:35:19)".
- **C2, lines 263-264 and 447-448.** "agreed to the cent" (14:08:26). lead.md 18:47:34 withdrew "to the cent" as premature. Fix: drop it, or say "within the balance's rounding, two minutes after the last call".
- **C3, lines 180-181, 358-361 and 451-452.** "QS4h settled it for its own runs", and "The closed requests were not billed". 08:25:11 concluded it from two reads 32 minutes apart, but lead.md 18:47:34 reopened the question, and the usage export is not in hand (still open, per 18:12:17 and the case study's own close). Fix: "the balance, read 10.5 and 42 minutes after the last call, shows no charge for them to within rounding; the usage export has not yet confirmed it".
- **C4, lines 445-446.** "Each check the meter faced agreed with the bill, within its tolerance. The batches reconciled alone." The records show 16 batch summaries with a first-read mismatch (13 QS6 batches, qs4-p3-real 121519Z, qs4-p4-real 130515Z, qs4h-h3-planted 061843Z). All 16 were later rechecked (7) or acknowledged (9). 71 of the 122 batches are marked concurrent, so they were reconciled only with the others. Fix the sentence to say so.
- **C5, lines 173-174.** "Below 64K, none of over 500 runs met one." lead.md 19:11:24 says none in 264 calls at 16K and 32K. The 264 QS6 runs there carry no unmetered field, so the records cannot show it, and no source gives 500. Fix: state the 264 and their source.
- **C6, lines 258-259, and harness-notes.md line 338 (note 45).** "the failed requests' median was 161 and 180 messages, against 131 and 123". 161 and 131 are lead.md 13:26:42 (200042Z). 180 and 123 have no source in the ledger. Source them or drop them.
- **C7, lines 248-249.** "it reported twice, in 103 and 122 turns". 122 is lead.md 08:57:42 (151656Z). 103 has no source in the ledger.
- **C8, lines 204-205.** "The first two ran one at a time, the rest in three lanes at once (09:32:39)". Pass 2's last three runs (P2 real and its two reruns) ran in the lanes from 09:57:22. Fix: "the first pass ran one at a time, and the second mostly so".
- **C9, lines 455-457.** "the Claude sessions, the Haiku agents among them, are outside it (PLAN.md §5, decision 7)". PLAN.md decision 7 reads "Lead's reading: yes. Logan's words do not say." Fix: say it is the lead's reading, and that Logan has not settled it.
- **C10, lines 125-126.** "the lead ran candidates against each suite and kept only survivors". The ledger's own wording (lead.md 22:00:27) is "chosen so that only reading finds them", and I found no entry where candidates were run against the suites. Source it or use the ledger's wording. harness-notes.md line 251 repeats it.
- **C11, lines 138-139.** "found all five of the lead's sealed suspicions and about fifteen more". lead.md 11:21:04 gives "five sent back, eight restated, seven limits", and I found no count of fifteen. harness-notes.md line 47 repeats it.
- **N1, harness-notes.md line 336 (note 45).** "Three long runs on real tips met it, two of them P5's". The records show four runs at an allowance of 23: three of P5's real tip (183548Z, 195306Z, 200042Z) and one of P3's (200155Z). lead.md 14:08:26 counts the same four. Fix the count.
- **N2, note 46.** It repeats C2 and C3 as history, with the conclusion withdrawn, which is right. Its own line on the usage export should say the question is open.

Believed (not measured):
- The eight I/O-error exclusions (the lane runs at the first path) are left out for the reason given, but the committed records carry no I/O-error text for them. The reason rests on lead.md 11:03:35 and on verifier-J's transcript check (15:17:50). I did not read the transcripts.
- 06:01 (note 51) and 09:41 (harness-notes.md line 170) are times with no source in the committed material. Their sources, if any, are local.

Privacy items for the lead, before the archive. I decided neither.
- **P1.** lead.md line 2497 has "under `AppData\Local\Temp`". It is a partial path that names the owner's machine, and the README asks for <scratch>. Rename it before the archive. The same word appears in verifier-I.md line 85 and verifier-P5.md line 33, but there it names the scan's pattern.
- **P2.** The committed records (batches.jsonl: 122 summaries, each with balance_before and balance_after) hold the account's balance readings. The owner's ruling of 03:00:44 covers his words, not these readings, and the README says no file holds personal data. Logan's word is needed on whether the balance series is published.

For: the lead (C1 to C11, N1, P1, P2); Logan (P2, and C9's decision 7).

Still open for my pass: the gate's control run and the skip reasons (item 7), item 10, and the final verdict.

## 2026-10-08 19:22:36 -0700 - pass 1 verdict: NOT READY on the case study and the notes; READY on the code, records, judgements, table and gate; findings classed, two privacy items for the lead, one for Logan

Pass 1 of 2, final. Model: Haiku 5.5 (claude-haiku-5-5). Work: round1 at 3ba21fb, in my clone under `<scratch>/r1-vI2/round1`.

Measured (item 7, the gate, run in my clone with DOCKER_HOST at the closed port and GIT_OPTIONAL_LOCKS=0):
- `python tools/check.py`: "tests ok 805 passed, 40 skipped in 252.65s"; schema ok, 11,657 record lines; guard ok, 26 fixtures; privacy ok, 131 files and 55 commit messages; livegate ok, 68 Python files; "PASS: 5 of 5 checks hold"; exit 0.
- `python tools/check.py --control`: "controls: 9 of 9 caught"; exit 0.
- `python -m pytest -rs -q tests`: the 40 skips (summed from the counts pytest prints): 17 Docker tests, because the daemon is unreachable at the closed port, as the dispatch sets it; 22 tests that need inputs absent from my clone (QS6 11, QS4 4, QS4h 4, and QS4h's Docker tests that need its built image 3); 1 symlink test, because this account cannot make a symlink. The lead's checkout holds those inputs and reports 23 skips; I did not compare the two sets. No test failed.

Verdict: NOT READY. The code, records, judgements, table and gate are READY. The case study and the harness notes are not, and the archive waits for them.

Findings by item of my list (classes as `_verifier.md` has them: sent back, merged as a known limit, restated):
1. The merge 022abee: held. A fresh merge-tree of bd92fd5 and c3be1ef gives the committed tree (877d9340...); c3be1ef is the tip verifier-P5 found READY in its pass 2. The copy ea8ba0b differs from its real tip 54ce53f by the key's plants alone: two in_view lines in qs4h_items.json and one line in qs4h.py. No finding.
2. The lead's commits, 48d1008, db94d41, b0157ce, 86235a7, 0af47f7, 1775765, dfb7b25 and 85c7c31: each changes what its entry says. No regression and no wrong answer. Each restated sentence I checked is true of its code. Note N-I2-1, below, is about verifier-P5's text, not the code. Known limit, already stated at 11:37:12: the read_file description changed at 0af47f7, after QS4's passes, so earlier runs read the earlier text.
3. The judgements, bd92fd5 and a065686: each committed verdict equals the verdict its verifier agreed (verifier-J's 85 and verifier-JH's 87), or the settlement at 15:17:50 for the four settled verdicts. Both files pass judgement_problems with zero problems. The drafts named by SHA-256 are gone, so the traceability runs through the verifiers' per-judgement lists. Known limit, disclosed at 18:51:07 and in the case study's proposal 14.
4. The records, the selection and the table, 9e9cd06: the records validate and all 122 batch summaries agree with their run records and spend lines. Every QS4h exclusion, and 10 of the 18 QS4 exclusions, match their records; the 8 I/O-error exclusions cannot be checked against the records, see Believed. TABLE.md equals tools/table.py's output below its 8-line header after carriage returns are removed. Correction to my 19:03:01 entry, which says 7 lines: the header is 8 lines. Restated: R-I2-1 ("byte for byte" holds only with line endings normalised; the script writes CRLF on this host). Restated, minor: N-I2-2 (lead.md 18:51:07 says the table "gives" 31 of 40, 31 of 32 and 659 of 660; it prints per-run and per-cut rows, and the totals must be summed).
5. The case study, d487c8f: I checked more than 30 values, named in my entry of 2026-10-08 19:13:41 (values 1 to 22), and most hold. Restated, must fix before the archive: C1 (the holiday stated as fact, lines 186-188, 453-454 and timeline line 57; 18:35:19 believes it), C2 ("agreed to the cent", lines 263-264 and 447-448; withdrawn at 18:47:34), C3 ("QS4h settled it" and "were not billed", lines 180-181, 358-361 and 451-452; the usage export is not in hand), C4 ("each check ... agreed" and "the batches reconciled alone", lines 445-446; 16 first-read mismatches, all later resolved, and 71 concurrent batches), C8 (lines 204-205), C9 ("outside it (PLAN.md §5, decision 7)", lines 455-457; the decision is marked as the lead's reading). Unsourced, to source or drop: C5 ("none of over 500 runs", lines 173-174), C6 (180 and 123, lines 258-259), C7 (103 turns, lines 248-249), C10 (the "ran candidates" method, lines 125-126), C11 ("about fifteen more", lines 138-139).
6. The harness notes: the 11 HH:MM:SS stamps all exist; of the 4 HH:MM times, 01:20 and 02:13 are verified, and 06:01 and 09:41 are in no committed material. Restated, must fix: N1 (note 45 says three long real-tip runs met the allowance of 23, two of them P5's; the records show four, three of them P5's). Notes 43, 46, 47, 48 and 50 to 52 hold on the figures I checked. I did not check the file counts in note 44 (git) or the pass-1 screen count in note 49. The unsourced figures in notes 45 and 47 are the same as C6 and C11.
7. The gate at 3ba21fb: 5 of 5 and controls 9 of 9, with the skip reasons above. Holds.
8. Privacy: no absolute path with a drive letter, no key shape, no assigned secret, and no owner address, in the ledger's 55 files or in the 63 files committed since 866a292. Two items for the lead, not findings: P1 (lead.md line 2497 has "under `AppData\Local\Temp`", a partial path to the owner's machine; rename it before the archive, to <scratch>); P2 (the committed batches.jsonl carries the account's balance before and after each batch, 122 summaries; the owner's ruling of 03:00:44 covers his words, not these readings; his word is needed on whether the balance series is published).
9. verifier-I's first pass: R1 holds (verifier-P3's F1 is L06, plant B, and F2 is R09, plant A, per keys/key-83ee196.json). R2 holds (the table's footer and batch_rows say "every batch with a summary line"; the footer total equals the batch rows, 18.777486312). R3 holds in the committed selection; C1 is the same concern, still open in the case study.
10. Anything else. Brief error: item 5 says "item 11 (Haiku)", but my list has ten items; I read it as the case study's Haiku section (noted at 18:54:18). Note N-I2-1: verifier-P5's pass-2 R1 says nine mutants survive on the Docker lines and names five groups; its enumeration totals eight (2+1+1+2+2). The restate in dfb7b25 states no count, so it is not wrong, but one survivor is unnamed. Scope: I read the directory listing (only lead.md and briefs/verifier-I2.md changed after 14:00), and the files my list cites; I did not read the parcels' own ledger files P1 to P5 in full. For item 1, I fetched the copy commit read-only from the lead's copy clone; this is disclosed here.

Believed (not measured):
- The 8 I/O-error exclusions (the lane runs at the first path) are left out for the reason given. The committed records hold no I/O-error text for them; the reason rests on lead.md 11:03:35 and on verifier-J's transcript check (15:17:50). I did not read the transcripts.
- The times 06:01 (note 51) and 09:41 (harness-notes.md line 170) have no source in committed material.

What pass 2 should check (scoped to the fixes): the case study's C1 to C11 and the note N1 (each new sentence against the source I named); P1's rename; R-I2-1's wording; N-I2-2's wording; and the notes 45 and 47 figures. The code, records and judgements need no second pass.

Background processes: the gate, the control and the test run have all finished. None of mine is left running; the Python processes still alive are other sessions' and I did not touch them.

For: the lead (C1 to C11, N1, P1, R-I2-1, N-I2-2 before the archive); Logan (P2, and C9's decision 7).

## 2026-10-08 19:22:47 -0700 - correction to 19:13:41 and 19:22:36: both entries quote the path fragment that P1 asks lead.md to rename

Measured: lines 103 and 129 of this file repeat the partial path fragment that P1 names, which names the owner's temp folder under the Windows user profile. I should have named the fragment without quoting it. The archive should take this file with the quoted fragment removed, as P1 asks of lead.md. No other claim in those two entries changes.

For: the lead, before the archive

## 2026-10-08 19:43:12 -0700 - pass 2, the last, at 86679fe: NOT READY on two sentences (the QS6 half-price sentences; note 33's over 500); C7, C9, the round-2 corrections and the gate hold; I do not accept P1 as written

Pass 2 of 2, the last. Model: Haiku 5.5 (claude-haiku-5-5). Work: round1 at 86679fe, fetched read-only from the P0 worktree into my clone, checked out detached. 86679fe is one commit above 3ba21fb and changes only CASE-STUDY.md and harness-notes.md (diff stat: 75 insertions, 59 deletions).

Verdict: NOT READY, on two sentences. Each is a restate the lead's 19:24:02 entry says is fixed, and each is not. The code, records, judgements, table and gate are READY. Once the two sentences below change, the case study and notes hold on every item I checked, and the minor items below can follow.

Measured:
- Gate at 86679fe: `python tools/check.py`: tests ok 805 passed, 40 skipped (the same skips as at 3ba21fb); schema ok, 11,657 record lines; guard ok, 26 fixtures; privacy ok, 131 files and 56 commit messages; livegate ok, 68 Python files; "PASS: 5 of 5 checks hold"; exit 0. `--control`: "controls: 9 of 9 caught"; exit 0.
- C4's counts, from records/batches.jsonl: first reads 35 ok, 71 concurrent, 16 mismatch. Of the 16, 7 later rechecks read ok and 9 were acknowledged; the 16 are all resolved.
- QS6, last reads (table.json, billed over computed at peak): the nine acknowledged batches are at 41 to 56 per cent (015555Z 41, 030203Z 44 [excluded], 031458Z 45, 012554Z 46, 025049Z 49, 033726Z 49, 032238Z 49, 033052Z 51, 030758Z 56). The other five reconciled ok at their last read: 012012Z 77, 015103Z 61, 020307Z 86 [excluded], 025612Z 34 [excluded], 020712Z 0 [excluded; computed $0.011]. The tolerance is $0.02, and at these amounts that cannot tell half from full.
- C5's count: the QS6 runs at 16K and 32K made one call each (132 + 132 runs, calls = 1 for all 264), so "264 calls" is right.
- C7: records/runs/qs4-p5-real.jsonl, outcome.data.agent.turns: 151656Z = 122, 202615Z = 103. The pass-1 run 134511Z = 169, which the case study also cites.
- C9: PLAN.md on main, the Approved section (lines 654 to 668; the answer at 661 to 663): "on the ceiling, 'API bills, Qwen inside (Recommended)': decision 7. The $250 covers what the measured models' APIs bill, Qwen included, and not the Claude sessions building the harness."
- verifier-P2: verdict at 14:47:32 sends back five, F1 to F5. F1 and F2 are the plants; F3 and F4 are the view's V3 and V4; F5 is new. Pass 2 at 17:04:41 marks F3, F4 and F5 each "Fixed" and gives READY at c7b99d6. Merge at 17:10:43 (c6c1a6e).
- P4: design at 17:45:13 says four of five copies do not reproduce by the brief's method. lead.md 17:47:24 runs draft 4's method and gets five MATCH. P4.md 17:48:54 corrects the design: its probe dropped each copy's first plant; the method and the brief are not at fault.
- verifier-P0: its first-pass verdict (verifier-P0.md, 11:18:52, reported at lead.md 11:21:04) has five sent back, eight restated and seven limits, twenty in all. Its pass 2 (verifier-P0.md, 12:04:36) sends back S1' and S2'. lead.md line 240 says it found all five of the lead's suspicions.

Item 1, each of C1 to C8, C10, C11, N1 and N2 against its source:
- C1 (holiday): the believed status is now right (18:35:19). NOT FIXED on QS6. CASE-STUDY.md lines 191 to 192 say "QS6's batches on 2026-10-07 were billed at about half what the price table computed for peak hours", and lines 463 to 464 say "QS6's batches on 2026-10-07 billed at about half the peak computation". The records do not say that of all of QS6: nine of fourteen batches are at 41 to 56 per cent, and five reconciled ok at their last read (above). The timeline at line 57 is right for the two batches held at 18:35 (together they billed about half of their peak computation, $0.05 against $0.09, per 18:35:19).
- C2 ("within the balance's rounding", 14:08:26; "to the cent" withdrawn at 18:47:34): fixed. Minor: line 274 says "The usage export settles it", which is 18:47:34's wording for an export not yet in hand; say "will settle it".
- C3 (QS4h's reads and the open question; "still open" at lines 180 to 186, "show no charge" at 364 to 367 and 461): matches 18:47:34 and the 08:25:11 reads.
- C4 (counts): fixed. The counts are right. Minor: line 454 says the seven agreed "once their bills had posted". The records show that the recheck read ok; they do not say a bill had posted. Say what the recheck read.
- C5: fixed in the case study (lines 177 to 178: "none of the 264 calls at 16K and 32K met one (19:11:24)"). NOT FIXED in note 33, harness-notes.md line 233: "and none of over 500 below 64K" is still there. Replace it with the case study's sentence.
- C6 (161 against 131, 13:26:42): fixed, and right.
- C7 (122 and 103, run records): fixed, and right (item 3).
- C8 (the first pass ran alone, the second mostly so): fixed, and right. Pass 2's last three runs ran in the lanes from 09:57:22.
- C10 ("chosen so that only reading finds them", 22:00:27): fixed, and right.
- C11 (twenty first-pass findings, 5 sent back, 8 restated, 7 limits, 11:21:04; two more sent back in pass 2, S1' and S2'; "all five" at lead.md 240): fixed, and right.
- N1 (note 45: four runs at 23, three of P5's real tip and one of P3's; 14:08:26): fixed, and right.
- N2 (note 46: the billing question stays open; the usage export has not confirmed it): fixed, and right.

Item 2, C9: yes, it settles decision 7, in both halves. The $250 covers the measured models' APIs, Qwen included, and not the Claude sessions building the harness. The citation is right: "API bills, Qwen inside" is the answer's label, and "(PLAN.md, Approved)" names the section. One caveat, not a blocker: the answer does not name the Haiku agents. Line 467 says "the Haiku agents among them, are outside it", and that rests on the first clause (the measured models' APIs only), with item 11's "the harness metered none of them". The parenthesis could say so.

Item 3, C7: yes. outcome.data.agent.turns is 122 for 151656Z and 103 for 202615Z. The case study's "in 122 and 103 turns (the run records of 151656Z and 202615Z)" is right.

Item 4, P1: I do not agree with keeping the fragment as written. I agree that it has no user name and no drive letter, and that the privacy scan finds no full path. But the README's rule is about places: "Name every place relative to <repos> or <scratch>". The 11:03:35 entry names the lead's scratch, a long path under the Windows temp folder, which the README says to name <scratch>. "AppData\Local\Temp" is the tail of the owner's profile path, so it does show the owner's machine's layout, and "not absolute" is too narrow a test for the rule's purpose. The fix costs one appended line: the place is <scratch>. Logan may rule either way. My own entries at 19:13:41 and 19:22:36 repeat the fragment (lines 103 and 129 of my file), and my 19:22:47 correction repeats it too. I would treat them the same way.

Item 5, the two round-2 corrections:
- (a) verifier-P2: right. Its real findings are three, F3 to F5, not V3 and V4. The citation at CASE-STUDY.md line 143 gives 14:50:58, which records the send-back and the lead's check at ceef2e2, but not the fix. Add 17:04:41 (each "Fixed") and 17:10:43 (the merge). The lead's own lead.md 22:00:27 entry still says "Its V3 and V4 were real, sent back, and fixed before P2's merge"; that is wrong now, and the lead's ledger needs an appended correction, since it is append-only.
- (b) P4: right. Four of five copies did not reproduce in the design (17:45:13); the draft 4 method gives five MATCH (17:47:24); the fault was in P4's probe (17:48:54), so it is not a brief error. Minor: line 160 and harness-notes.md line 170 say "Ninety seconds later P4 found the fault". 17:48:54 is the time of P4's correction entry, not a measured time of discovery. Say: "P4's correction, entered ninety seconds later, names the probe's fault".

Item 6, the gate at 86679fe: 5 of 5 and controls 9 of 9, as above.

The two sentences to change:
1. CASE-STUDY.md lines 191 to 192, and 463 to 464 (the QS6 sentences). Suggested text: "nine of QS6's fourteen batches billed 41 to 56 per cent of the peak computation at their last reads (the nine acknowledged); the other five reconciled ok at their last read, within the $0.02 tolerance, which at these amounts cannot show a half."
2. harness-notes.md line 233 (note 33). Replace "none of over 500 below 64K" with "none of the 264 calls at 16K and 32K (19:11:24)".

Minor, with the same edit: CASE-STUDY.md lines 274 ("will settle it") and 454 (the recheck's reading, not "once their bills had posted"); lines 160 and harness-notes.md line 170 (P4's timing); line 143 (add 17:04:41 and 17:10:43); line 467 (say the Haiku agents are outside by the first clause); and an appended correction in lead.md for the 22:00:27 V3 and V4 sentence.

Limits of this pass: I did not read the transcripts; I did not re-check the parcels' own files beyond the lines cited; I cannot check the two edits myself, since this is my last pass, so the figures above are for the lead to check against.

Background processes: none of mine is left running. The gate and the control run both completed (exit 0).

For: the lead (the two sentences, the minor items, the 22:00:27 correction); Logan (P1's ruling; P2, as the lead has it).
