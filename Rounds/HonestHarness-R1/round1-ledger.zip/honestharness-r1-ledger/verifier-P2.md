# verifier-P2: the ledger of round 1's verifier of P2 (the agent loop and its sandbox)

Append only. Each heading's time is taken from `date`. Pass 1 of at most two. Roots are
written as `<repos>` and `<scratch>`.

## 2026-10-06 14:06:57 -0700 - pass 1, start: the channel test is sent, the work is read, and the gate runs at 5 of 5 on the planted copy

Measured:
- I run on Sonnet 5.5 (claude-sonnet-5-5), as my system prompt names it.
- The test escalation "verifier-P2: channel test" was sent to main with SendMessage, and the tool reported it queued.
- Read before forming a view: the README, `lead.md`, `briefs/_verifier.md`, `briefs/verifier-P2.md`, `briefs/P2.md` and `briefs/_common.md`. Not yet read: `P2.md`, and any other agent's file (R2).
- The copy, at `<scratch>/r1-vP2/copy`: HEAD `8214694`, base `0692de3`. `git diff --stat 0692de3..HEAD` reads 12 files changed, 2666 insertions: six under `qs/agent/`, `sandbox/controls.py` and five test files. Nothing of P0's, P1's or the plan's is in the diff.
- `docker ps` before I started a container: none running. `docker ps -a --filter name=hh-`: none. The pinned image is present: `docker image inspect` on the image reference in `qs/agent/sandbox.py` answers, with RepoDigests `python@sha256:3d36...6b96`, linux/amd64, 1109118638 bytes.
- `python tools/check.py` in the copy, temp directories pointed into my scratch with TMP and TEMP set by me: tests "254 passed in 92.89s", schema ok with 3 record lines, guard ok with 26 fixtures, privacy ok with 54 files and 13 commit messages, livegate ok with 34 Python files; "PASS: 5 of 5 checks hold".
- `python tools/check.py --control` in the copy: "controls: 9 of 9 caught".

Believed: the gate holds on this copy, which says nothing yet about content. The plants, if any, are in behaviour the 254 tests do not hold.

For: the lead

## 2026-10-06 14:07:08 -0700 - correction to the 14:06:57 entry: the digest abbreviation I typed ended in the wrong characters

Measured: `docker image inspect --format {{index .RepoDigests 0}}` on the pinned reference prints `python@sha256:3d361d7fea344d55ac7a0f51ed7faa99213808ccc96fc9b9170adb95b6570b96`, and `--format {{.Id}}` prints `sha256:720762d97dcd513c0e9e578cbc6cd97bb633f8f9e268ef75b73fd4f4621ea200`. The 14:06:57 entry abbreviated the digest by hand and ended it "6b96"; that was a typed value, which the README forbids. This entry corrects it. From here every value is pasted from the command that printed it.

For: anyone citing the 14:06:57 entry

## 2026-10-06 14:16:59 -0700 - pass 1, my view before I read P2.md (R2): three findings on the loop, one on the one command, and the isolation held under every probe

Written before I opened `P2.md`, so the lead can compare my yield with what the author's file says (R2). Every number below was printed by the probe named. My probes live in `<scratch>/r1-vP2/`: `probe_isolation.py`, `probe_loop.py`, `probe_loop2.py`, `probe_units.py`, `probe_gate.py`. They import the copy and change nothing in it.

Measured (findings, each with its input and what came back):
- **V1, the retry limit counts malformed calls in total, not in a row.** `qs/agent/loop.py`: `streak = 0` is set once (line 195), incremented at line 283, and never reset after a call that ran. The docstring says "the 4th malformed call in a row", `budgets.py` says "malformed calls in a row answered", and the stop's cause text says "{streak} malformed calls in a row". Input (probe_loop.py S1): a scripted model that alternates a malformed call and a good call, four times, then reports; retry limit 3. Result: `outcome=stopped budget=malformed_retries turns=7 malformed=4`, cause "4 malformed calls in a row; the last: ...". No two malformed calls were adjacent, and the run would have reported at turn 9. A long run therefore ends as `stopped` after its fourth malformed call of any spacing.
- **V2, the run-time budget is checked once per turn, not before each tool call.** `qs/agent/budgets.py` line 12: "checked before each model call and each tool call". In `loop.py` the only check is at the top of the turn loop (line 200). The loop's own docstring limit says a run can pass the budget "by one model call and one tool call". Input (probe_loop.py S2): one turn of three shell calls, the first takes 2000 s of a 1000 s budget, on a fake clock. Result: all three calls ran (`sandbox commands=[one, two, three]`), then `stopped run_seconds` at the next model call. With `max_calls_per_turn` 16 and a 120 s call limit, a turn can pass the budget by up to 16 calls.
- **V3, model text reaches the published record through `cause` and `detail`.** `loop.py` docstring: the published summary holds "No tool output, no model text, no host path". But the retry-limit stop's cause holds the last malformed call's error, and that error quotes what the model sent: a jsonschema message carries the instance's full repr, and an unknown tool's name is the model's. Input (probe_loop2.py S5, S5b): four malformed calls whose argument is a 400-character value, and four calls to a tool named by the model. Result: `ItemResult.detail` and `data.agent.cause` both carry "MODEL-CHOSEN-TEXT-xxx..." and "MODEL_TOOL_NAME_yyy..." (published length 1831 bytes for one 400-character value; the message is not truncated). The plan's rule for P3 and P4 is that no model text goes into published records (`lead.md` 13:03:51).
- **V4, the one command crashes when the docker command is absent.** `sandbox/controls.py` line 152 runs `docker ps` before `docker_status()`. With the docker command off the path (a PATH I built from the Windows system directory only), `python sandbox/controls.py` ends in a `FileNotFoundError` traceback, exit 1, where its docstring says "refuses if Docker or the pinned image is absent" and `main` has a `REFUSED` path with exit 2. The tests do skip and say why in that state: "SKIPPED ... docker: the docker command is not installed", 13 skips, and the other 241 tests pass.

Measured (what held):
- **Isolation, from inside a container the copy's own `DockerSandbox` started** (`probe_isolation.py`, one container, default limits, removed afterward: `{'removed': True, 'detail': None}`): the only interface is `lo`, with no route; DNS fails (`rc=2` for example.com, host.docker.internal and gateway.docker.internal); TCP to 192.0.2.1, 192.168.65.254, 192.168.65.2 and 172.17.0.1 gives "Network is unreachable"; raw sockets are refused (EPERM); no docker socket anywhere (`find / -name '*.sock'` is empty); uid 65534, all capability sets 0, NoNewPrivs 1; every write outside `/work/scratch`, `/tmp` and `/dev/shm` fails ("Read-only file system" or "Permission denied"), including both read-only mounts, a link through a link made in the scratch, and `mount -o remount,rw`; `/tmp` is `rw,nosuid,nodev,noexec` and an executable copied there will not run; the environment holds the image's own variables plus P2's and HOSTNAME, with no credential and HOME=/tmp; no `.ssh`, `.aws`, `.docker`, `.claude` or `.config` in the image's filesystem; `docker inspect` reads `NetworkMode none`, `ReadonlyRootfs true`, `CapDrop [ALL]`, `no-new-privileges`, `Privileged false`, `Init true`, `NanoCpus 2000000000`, `Memory` and `MemorySwap` both 2147483648, `PidsLimit 256`, an `fsize` ulimit of 536870912, three bind mounts of which only the scratch is `RW true`, and no devices, extra hosts or ports.
- **Timeout:** a call of `sleep 3 & sleep 3` with a 2 s limit returned `exit 124 TIMED OUT`, and no `nobody` sleep survived it.
- **The one command**, `sandbox/controls.py` against the ParcelRound clone read through the P0 worktree: "13 passed in 46.48s", then G1 to G5 as its docstring says, the clone's HEAD and tree equal to the source's `f42242e^{tree}` (`bbc8b20d204f19c9e35a3fe219338cf0cdf4cee2`, which I also read myself with `git rev-parse` in the source with `GIT_OPTIONAL_LOCKS=0`), the gate "PASS: 10 of 10 checks hold" on the host and in the container with every check line the same, "controls: 2 of 2 held", exit 0, no container left.
- **The mounted-gate control's comparison and fail-closed branches fire** (`probe_gate.py`, stand-in repositories I built in my scratch, the control's commit constant pointed at them in my own process): same pass held; host PASS against container FAIL, an extra check line in the container only, and an exit code that differs only in the container were each `NOT HELD`; 200 KB of output (beyond the capture) and no verdict line were `NOT HELD`; a source that is not a repository, and a commit the source lacks, each stopped at G1 with "the control stops, with no fallback".
- **Helpers against references:** `Capture` against a reference over 3000 random chunkings, no difference; `render_output` bounds over 2000 random cases, no difference; every name in `CREDENTIAL_NAMES` is refused as a mount path in lower and upper case; the control-token patterns replace each token in TC §3.4, §7.4 and §7.9 that I tried, and leave `<tool_response>` and `[/TOOL_CALLS]` alone.
- **P0 untouched, no live mode:** the diff against the base lists 12 files, all P2's; `grep` finds no `live=` and no key variable's name in P2's files; no home path in any form I know of in any tracked file.

Believed (not yet measured):
- V1 and V2 are the kind of fault a gate that runs 254 tests would not see: no test sends a malformed call after a good one, and no test spends the budget inside a turn.
- The mounted-gate control asserts the clone's tree at G2, before the host run at G3 and not again before the mount at G4. A gate that wrote into the clone on the host would reach the container unasserted. I have not built that.
- A gate that fails identically on both sides reads "held" (probe_gate.py variant 2): the control compares and does not require PASS.

For: the lead, P2

## 2026-10-06 14:17:19 -0700 - addendum to the 14:2x view entry on V3: the model text is not truncated at any length I tried

Measured (probe_loop3.py, the same four-malformed-calls input with the argument a list holding one string of n characters): n = 400 gives a `detail` of 550 characters; n = 5000 gives 5150; n = 60000 gives 60150, with all 60000 of the model's characters in it. `data.agent.cause` carries the same text again, so the whole published dict is 120993 characters at n = 60000. So V3's "not truncated" is measured, not only read from the code (`parse_arguments` truncates the schema's expected value to 200 characters and nothing else).

For: the lead, P2

## 2026-10-06 14:38:11 -0700 - pass 1, resume note: what I have run since my view, and what held

Measured (probes of mine in `<scratch>/r1-vP2/`; none writes in the copy, the repository or any worktree):
- **The plan's five controls, each with its guard removed in a copy of the copy** (`mutate.py`, which plants one text replacement per mutation, checks the text occurs once, and runs the tests that should catch it, with pytest's basetemp inside my scratch):
  - the no-Docker mutations, 18 of them, were all caught: the loop's scratch-only check, the turn budget, `tools_in_request`, control-token replacement, truncation, the retry limit, a stop mapped to pass, host-path redaction, `ctx.stop_reason` ignored, the nudge limit off by one, the scratch budget, the top-of-turn run-time check, unknown tools, the judge asked about a stopped run, tool-call ids, provider conditions, the per-turn call limit, calls after `report`;
  - the Docker mutations, 14 of them, were all caught: `--network none`, `--read-only`, `readonly` on the mounts, the missing-source pre-check, `--user`, `safe.directory`, `--cap-drop` with no-new-privileges, the in-container `timeout`, `--pids-limit`, the memory limits, the `fsize` ulimit, an extra read-only mount, an extra environment variable, and `stop()` not removing;
  - mutations not caught across both groups: 0. The mutation that leaves containers (`stop()` not removing) left some `hh-sbx-` containers from my own test run; I removed exactly the names that appeared during that run and were not there before it, and `docker ps -a --filter name=hh-` lists none now.
- **Removal on every ending I could build** (`probe_removal.py`, the real sandbox under the real loop, `docker ps` empty before each): a normal end, a call that times out and the run goes on, a suite tool that raises, a 503 mid-run, the turn budget, a model that never reports, malformed calls, and a dropped reply. Each recorded `removed=True` and `docker ps -a --filter name=^<its name>$` found nothing.
- **The built-in tools through the real sandbox** (`probe_tools_real.py`): `read_file` with and without `start_line` and `line_count`, past the end, an empty file, no trailing newline, UTF-8, a directory, a missing file; `write_file` with write, append, overwrite, UTF-8, a nested new directory, and a 5 MiB content whose host-side SHA-256 equals the sent one; the three refusals (outside the scratch, `..`, the scratch itself) before the sandbox. All as the descriptions say. One behaviour to know: a link made by `shell` from the scratch to `/tmp` lets `write_file` pass its lexical check and land in `/tmp`, which is in memory and gone with the container, the limit the sandbox's docstring states; the scratch manifest then lists the link as kind `link` and nothing from `/tmp`.
- **The limits in effect** (`probe_limits.py`, default limits, cgroup v1 on this desktop): CPU quota 200000 per 100000, memory and memory+swap both 2147483648, pids 256; six busy processes for 4 s of wall time used 8.2 s of CPU.
- **The download.** `docker manifest inspect` on the pinned digest (a registry metadata read, no layer pulled) printed 7 layers, 411620271 layer bytes and 6519 config bytes, so 411626790 bytes compressed, and the config digest `sha256:720762d97dcd513c0e9e578cbc6cd97bb633f8f9e268ef75b73fd4f4621ea200`, which is the local image's ID. `P2.md` 13:03:40 records the same layer count and byte counts, the source as Docker Hub's official `library/python`, before its 13:04:46 pull entry. So the image was recorded before it was pulled, from the official source, at the size recorded.
- **No Docker:** with the docker command off the path, the tests skip with "docker: the docker command is not installed", 13 of them, and the rest pass. The one command does not skip: see V4.

Believed: nothing new. Next: read `P2.md` against the copy, then the pass-1 verdict.

For: the lead

## 2026-10-06 14:38:23 -0700 - correction to the entry stamped 2026-10-06 14:17:19 -0700: its heading names the view entry by a time I typed from memory

Measured: the heading of the addendum stamped 2026-10-06 14:17:19 -0700 says "the 14:2x view entry". The view entry it adds to is stamped 2026-10-06 14:16:59 -0700, read now from this file. The addendum was written before I opened `P2.md`, and so was the view entry; my first read of any part of `P2.md` was after both. (My 14:17:19-stamped command also listed `P2.md`'s headings, after both entries were written.)

For: anyone citing the addendum

## 2026-10-06 14:47:32 -0700 - verdict, pass 1 of at most two: NOT READY at 8214694; five findings sent back, six limits to state, three sentences to restate

This entry follows the view entry (14:16:59), which I wrote before I opened `P2.md`, and the resume note (14:38:11). Line numbers are at the copy's commit `8214694`. Probe scripts are in `<scratch>/r1-vP2/`.

**Verdict: NOT READY.** The gate holds as it says (5 of 5, 254 tests; `--control` 9 of 9), the isolation held under every probe, and the plan's five controls each fail when their guard is removed. Two behaviours the author's own design lists are not in the code (F1, F2), and three other wrong answers are small.

### Sent back (a wrong answer: code that does not do what its docstring, brief or design says, or that records wrongly)

- **F1. A well-formed call does not reset the malformed-call count.**
  - Evidence: `qs/agent/loop.py:195` sets `streak = 0` once; `:283` adds to it; `:285-287` stops the run on it and writes the cause "{streak} malformed calls in a row". Nothing sets it back. The claims: `loop.py:25` ("the 4th malformed call in a row"), `budgets.py:15` ("malformed calls in a row answered; the next stops the run"), and `P2.md` 12:57:36, L6: "A well-formed call resets the count."
  - Input (probe_loop.py S1): a scripted model that sends a malformed call, then a good one, four times, then reports; retry limit 3.
  - Result: `outcome=stopped budget=malformed_retries turns=7 malformed=4`, cause "4 malformed calls in a row". No two malformed calls were adjacent, and the run would have reported at turn 9.
  - Why the gate misses it: no test sends a malformed call after a good one (`test_malformed_arguments_go_back_as_errors_and_a_retry_goes_on` has two in a row and then a good call).
  - Evidence that one missing statement is the whole cause: in a copy of the copy (`work/fixdemo`), one `streak = 0` before the handler call makes S1 report at turn 9, and the loop, tools, runner and sandbox test files all pass.
- **F2. The run-time budget is not checked before each tool call.**
  - Evidence: `budgets.py:12` says "checked before each model call and each tool call". The only check is `loop.py:200`, at the top of the turn loop; the per-call loop (`loop.py:262-324`) has none. `P2.md` 12:57:36 says the same as `budgets.py`, and its report (13:46:43) says the budgets stop a run "with no call past them". The limit the loop states (`loop.py:48-50`, "pass it by one model call and one tool call") understates it.
  - Input (probe_loop.py S2): one turn of three shell calls; the first takes 2000 s of a 1000 s budget, on an injected clock.
  - Result: all three calls ran (`[one, two, three]`), then `stopped run_seconds` at the next model call. With `max_calls_per_turn` 16 and a 120 s call limit, a turn can pass a 1800 s budget by up to 32 minutes.
  - Why the gate misses it: the one test of the budget (`test_the_run_time_budget_stops_the_run`) is stopped by the turn-level check.
  - In the same copy of the copy, a check before each call (the same stop, then `continue`) makes S2 run only the first call, and the four test files pass.
- **F3. Model text reaches the published record, unbounded.**
  - Evidence: `loop.py:287` puts the last malformed call's error into `cause`, and `AgentResult.detail()` (`:97-99`) and `summary()` (`:111`) publish it. The error quotes what the model sent: a schema message carries the instance's repr (`tools.py:123`), and an unknown tool's name is the model's (`loop.py:278-279`). The claims: `loop.py:44-46` and `:107-108`, "No tool output, no model text, no host path"; the plan's rule for wave 2, `lead.md` 13:03:51.
  - Input (probe_loop2.py S5, S5b; probe_loop3.py): four malformed calls whose argument is one string of n characters; four calls to a tool the model names.
  - Result: with n = 60000, `ItemResult.detail` is 60150 characters holding all of them, and `data.agent.cause` holds them again (the published dict is 120993 characters). The tool name the model chose appears in the published `detail` too.
- **F4. The one command crashes where its docstring says it refuses.**
  - Evidence: `sandbox/controls.py:152` runs `docker ps` before `docker_status()` (`:155`), and `:5` says "refuses if Docker or the pinned image is absent"; `main` has a REFUSED path with exit 2 (`:156-158`). `P2.md` 12:57:36, section 8: "the one command refuses".
  - Input: the docker command off the path (a PATH I built from the Windows system directory alone).
  - Result: a `FileNotFoundError` traceback from line 152, exit 1. The tests do skip and say why in that state ("docker: the docker command is not installed", 13 skips, 241 passing).
- **F5. Two parse failures escape `parse_arguments` and end the run as `error`, not as a tool-result error.**
  - Evidence: `tools.py:111-114` catches only `json.JSONDecodeError`. The docstring (`tools.py:17-20`) and the brief say malformed arguments are answered as tool-result errors.
  - Input (probe_loop5.py): `'{"command": ' + '[' * 50000` raises `RecursionError: maximum recursion depth exceeded while decoding a JSON array from a unicode string`; an integer of 5000 digits raises `ValueError: Exceeds the limit (4300 digits) for integer string conversion: value has 5000 digits`. Through the loop the second gives `outcome=error malformed=0 cause='the agent loop failed: ValueError: Exceeds the limit (4300 digits)...'`, and the model is told nothing. (A 1500-level nested array that closes parses and is answered as a schema error.)

### To state as limits (the behaviour conceded; none is stated in the copy)

- **L1. A `shell` command of about 32 KB or more ends the run as `error`, with the container alive.** `sandbox.py:462-465`: `Popen` raises `FileNotFoundError` once the whole `docker exec` command line passes Windows's 32767 characters, and `:464-465` turns it into `SandboxDied("docker could not be run: FileNotFoundError")`, which the loop (`loop.py:297-301`) ends as `error`. Measured (probe_longcmd.py): commands of 31989 characters ran; 39989, 99989 and 299989 each gave `SandboxDied`; `alive()` read True afterwards. `write_file` sends its content on stdin and has no such limit. A verifier that writes a long heredoc through `shell` meets it.
- **L2. A NUL in a `shell` command or a `read_file` path, and a lone surrogate in `write_file` content, end the run as `error`.** `Popen` raises `ValueError: embedded null character` (`sandbox.py:462`; the `except` at `:464` is `OSError`), and `.encode("utf-8")` at `tools.py:204` raises `UnicodeEncodeError`. The loop (`loop.py:302-304`) records "the tool shell failed: ValueError", a model-made input as a broken tool (probe_nul.py).
- **L3. A `start()` that raises something other than a `SandboxError` skips `stop()`.** `loop.py:184-190` sets `started` only after `start()` returns or raises a `SandboxError`; the outer `except` (`:331`) then ends the run with no stop. The docstring (`:33-35`) says "removed on every path". The container's own timer removes it within its lifetime (probe_loop4.py S10). Eight other endings I built (probe_removal.py) all removed it.
- **L4. The container's lifetime is fixed, not tied to the run budget.** `sandbox.py:279` defaults `lifetime_s` to 5400; `P2.md` 12:57:36 plans `sleep <max_run_seconds + 3600>`. A suite that sets `max_run_seconds` above that meets "the container stopped" mid-run. For P4.
- **L5. The mounted-gate control asserts the clone's tree before the host run, not again before the mount.** `sandbox/controls.py:91-100` (G2) comes before G3 (`:101-104`) and G4 (`:105-110`). A gate that wrote into its own tree on the host would reach the container unasserted. Round 6's gate does not: `git status --porcelain` in the clone printed 0 lines after the real run.
- **L6. A gate that fails identically on both sides reads "held".** `controls.py:136-138` compares and does not require PASS (probe_gate.py, variant 2). The brief asks for the comparison.

### To restate at the merge

- `P2.md` 13:46:43 and the commit message say the budgets stop a run "with no call past them": not so for the run-time budget until F2 is fixed. `loop.py:48-50` understates the same overshoot.
- `loop.py:33-35`, "removed on every path": see L3.
- `controls.py:5` and `P2.md` section 8, "the one command refuses": see F4.

### Nits (no class)

- `tools.py:114` builds "starting at at line" when `json`'s own message already ends in "at".
- `controls.py:140-141` prints "verdicts differ" when the cause is a truncated capture (probe_gate.py, variant 5); the result, NOT HELD, is right.

### What reading `P2.md` added to my view

- F1 and F2 are not only mismatches with the copy's own comments: both are in the author's design as behaviours (L6: "A well-formed call resets the count"; Budgets: "checked before each model call and each tool call"), and the report's "no call past them" claims the second.
- Every constant, flag and list I could compare with the design matched: the limits, `ENV`, the credential list, the budgets' defaults, the head and tail sizes, the lifetime's 5400 s (= 1800 + 3600), the image digest and size, the ParcelRound commit and tree, the 132 tests (collected: 37, 4, 49, 29 and 13 in P2's five files) and P0's 122.
- Measured, not matched with anything of mine: `lead.md` 13:53:53 and `P2.md` 13:46:43 each record 2673 insertions for P2's own tree; `git diff --shortstat 0692de3..HEAD` in the copy reads 2666. Believed, not measured: F1's missing statement (one line) and F2's missing check (a short block) would account for about that difference. I have not seen P2's tree, and any other edit that keeps the line count would not show in it.

### What held (measured; details in the 14:16:59 and 14:38:11 entries)

- Gate 5 of 5, `--control` 9 of 9, in the copy.
- Isolation from inside the container (network, writes, mounts, ambient, limits, timeouts), each as stated; the CPU, memory and pids limits in effect.
- The plan's five controls, with their guards removed in copies: 18 no-Docker and 14 Docker mutations, all caught.
- Removal on eight endings. The one command, 2 of 2, with the gate "PASS: 10 of 10 checks hold" on host and container. The mounted-gate control's comparison and its fail-closed branches.
- The download: recorded in `P2.md` 13:03:40 before the 13:04:46 pull, from Docker Hub's official `library/python`, with a registry read of the digest's manifest matching the recorded layer count and bytes.
- The seam and privacy: the diff adds only P2's 12 files; no `live=`, no key variable's name; no home path in any tracked file.

### What I ran, in order

`python tools/check.py`, then `--control`, in the copy; `probe_isolation.py`; `sandbox/controls.py` against the ParcelRound worktree's clone; `probe_loop.py` (S1-S4), `probe_loop2.py` (S5, S6), `probe_loop3.py`, `probe_loop4.py` (S7-S12), `probe_loop5.py`; `probe_units.py`; `probe_gate.py` (seven stand-in variants and two fail-closed cases); the one command and the tests with the docker command off the path; `mutate.py` (fast, then docker); `docker manifest inspect` on the pinned digest; `probe_removal.py`; `probe_tools_real.py`; `probe_limits.py`; `probe_flood.py`; `probe_nul.py`; `probe_longcmd.py`; a fix-demonstration copy (`work/fixdemo`, in my scratch) for F1 and F2.

### Disclosures

- Two of my own entries were corrected by appended entries: a digest abbreviation I typed (14:07:08) and a time I typed in a heading (14:38:23).
- Every process of mine that makes temp directories (the gate, its control copies, pytest's basetemp, the control runs and the mutation runs) ran with `TMP`, `TEMP` and `TMPDIR` set by me to a directory in my scratch. My other probes name their working directories under `<scratch>/r1-vP2/work/` themselves and call no tempfile function; I did not measure that nothing else wrote to the system temp.
- I ran the gate inside the planted copy; that wrote `__pycache__` (git-ignored) only, and `git status --porcelain` there prints 0 lines.
- The `docker manifest inspect` is a network read of Docker Hub's registry metadata; nothing was pulled, and no request went to any model provider's host.
- The mutation that stops `stop()` from removing left some `hh-sbx-` containers from my own test run. I removed those that were not there before the run began, by exact name, and nothing else; `docker ps -a --filter name=hh-` lists none now.
- One container at a time throughout, with `docker ps` empty before each run.

For: the lead, P2

## 2026-10-06 14:49:15 -0700 - closing: nothing of mine is running, and no container is left

Measured: `docker ps -a --filter name=hh- --format {{.Names}}` lists 0 containers. I started no background process: every run of mine was in the foreground and has ended. The pulled image is untouched. The planted copy has `git status --porcelain` empty, and I changed nothing outside `<scratch>/r1-vP2/` and this file. Pass 1 is complete; a pass 2, if the lead asks for one, would be scoped to the diff that fixes F1 to F5 and states L1 to L6, and I would re-run `probe_loop.py` S1, S2, S5 and S5b, `probe_loop5.py` and `probe_loop4.py` first, then the mutations.

For: the lead

## 2026-10-06 15:48:16 -0700 - pass 2 (the last in my budget), resume note: the diff is read, the gate holds at the fix, and the probes of each fix are run

Scope, from the lead's message (`lead.md` 15:15:46): the diff `ceef2e2..c7b99d6`. I read the commits from a clone of P2's branch made in my scratch with `git clone --no-hardlinks`, which writes nothing in the source, and checked out `c7b99d6` detached. `git rev-parse` in the clone prints `c7b99d6`, and its parent `ceef2e2`. I have read the diff in full, and not yet `P2.md`'s fix entries (15:08:41, 15:15:01): I am forming my view of the diff first, then I will read them against it. I write nothing here about F1 and F2, as the lead asked.

Measured:
- **The diff:**  9 files changed, 306 insertions(+), 56 deletions(-). The files are `qs/agent/loop.py`, `sandbox.py`, `scripted.py`, `tools.py`, `sandbox/controls.py`, and four test files. No file of P0's or P1's is in it.
- **The gate at `c7b99d6`, in my clone, temp directories in my scratch:** `tests ok 271 passed in 76.58s (0:01:16)`; `privacy ok 54 files and 14 commit messages read`; `PASS: 5 of 5 checks hold`. `python tools/check.py --control`: `controls: 9 of 9 caught`.
- **Each fix against the code, by probe** (outputs are in my scratch; the verdict entry will cite them):
  - F3: four malformed calls, with the model's text in a schema value, an unknown tool's name, a parse error, an extra property's name and a non-object, at 400 and 60000 characters: the published `detail` and `data` hold none of it, the cause reads "4 malformed calls in a row; the last was <kind>", and the local log keeps the text. The model is still told what failed.
  - F4: the one command with the docker command off the path, with the daemon unreachable (`DOCKER_HOST` set by me to a dead local port), and with a copy whose image digest is not present (nothing pulled): each prints one REFUSED line, exits 2, prints no traceback, and prints no "== docker ps".
  - F5: 87 argument strings (closed and open nesting from 500 to 200000 levels in five positions, integers, floats and exponents of 4299 to 100000 digits, NaN and Infinity, lone surrogates, NUL escapes, a BOM, empty and bare values, a 10 MB string, a 1 MB key): `parse_arguments` raised on none. Through the loop, an unclosed 50000-level array and a 5000-digit integer each cost one malformed call, and the run went on and reported.
  - L1: 21 commands each run short (as a `bash -c` argument) and padded past the threshold (through stdin, from a file in /tmp): 20 pairs have identical exit code and output; the one that differs is a "command not found" message, which names the file instead of "bash: line 1". The boundary is 8000 and 8001 characters. A long call that times out, one that ignores TERM, and one that removes its own file each leave no command file behind. With /tmp full, the long command returns the `cat` failure.
  - L3: `stop()` ran, and the container was gone, when `start()` raised a RuntimeError after `docker run`, and when it raised a KeyboardInterrupt (which propagates); and when `docker run` itself failed.
  - L4: a real container started by the loop with `max_run_seconds` 1000 and `call_timeout_seconds` 60 ran `sleep 4660`.

Process: the lead's 15:35:17 rules reached me while a mutation run of mine was in the background. I stopped that task; no process naming my scratch was left, and `docker ps` was empty. From then on every test, gate and script runs through `shared/lowprio.py`, one heavy process at a time, with one small container at a time.

Believed: nothing new yet. Next: each fix removed in a copy, to see its test fail; the one command against the ParcelRound clone; `P2.md`'s fix entries against what I measured; then the verdict.

For: the lead

## 2026-10-06 17:04:41 -0700 - verdict, pass 2 (the last in my budget): READY at c7b99d6, for the diff ceef2e2..c7b99d6; nothing sent back

This follows my pass-2 resume note. Scope, from the lead's message (`lead.md` 15:15:46): the diff `ceef2e2..c7b99d6` (9 files, all P2's), read from a clone of P2's branch in my scratch. I wrote nothing here about F1 and F2, as the lead asked. Probe scripts and outputs are in `<scratch>/r1-vP2/`; every count below was printed by the command named.

**Verdict: READY at `c7b99d6`, for the diff `ceef2e2..c7b99d6`.** I found no regression and no new wrong answer in the diff, and send nothing back. Every fix the lead listed does what P2's entries say, and each has a test that fails without it, which I checked with removals of my own. What follows the lead's list is for the merge: two limits whose statements are narrower than the behaviour, five values no test pins (each held by a check of mine), one test that now passes by another route, and one sentence in `P2.md` to restate.

### The lead's list, item by item

- **F3, the published record holds none of the model's text. Fixed.**
  - Probe (probe2_loop.py, F3): four malformed calls ending in each of six shapes (a schema value holding the text, an unknown tool's name, an unterminated string, a non-object, an extra property named by the model, no arguments), at 400 and 60000 characters. In all 12 the published `detail` and `data` held none of it; the cause was 55 to 59 characters, "4 malformed calls in a row; the last was <kind>"; the published dict was 881 to 889 characters; the local log kept the text in every shape that had some. The model is still told what failed.
  - End to end through P0's `Runner` with a real container (probe2_misc.py): record status `stopped`, detail "stopped by the malformed_retries budget: 4 malformed calls in a row; the last was against the schema", record bytes 2063, the record carrying the model's text: False, the local transcript keeping it: True.
  - Removal (`mutate_inproc.py`, F3a, the cause quoting the error again): 3 failed, the three cases of `test_no_model_text_reaches_the_published_record`.
- **F4, the one command refuses without Docker. Fixed.**
  - With the docker command off the path (a PATH I built from the Windows system directory alone), with the daemon unreachable (`DOCKER_HOST` set by me to a dead local port), and with a copy whose image digest is not present (nothing pulled): each printed one REFUSED line, exited 2, printed no traceback and no "== docker ps".
  - Removal (F4a, `docker ps` before `docker_status()`): 1 failed, `test_the_one_command_refuses_when_docker_is_missing`.
- **F5, arguments too deep or too long to read are answered. Fixed.**
  - Probe (probe2_loop.py, F5): 87 argument strings (closed and open nesting from 500 to 200000 levels in five positions; integers, floats and exponents of 4299 to 100000 digits; NaN and Infinity; lone surrogates; a NUL escape; a BOM; empty and bare values; a 10 MB string; a 1 MB key). `parse_arguments` answered 83 with an error and accepted 4 (valid arguments: two lone surrogates, a NUL escape, the 10 MB string), and raised on none. Through the loop, an unclosed 50000-level array and a 5000-digit integer each cost one malformed call, and the run went on and reported.
  - Removals: F5a (the `RecursionError` answer at the parse) 2 failed; F5b (the `ValueError` answer) 2 failed; F5d (a kind outside `MALFORMED_KINDS`) 4 failed.
  - F5c, the `RecursionError` guard around the schema check, removed: nothing fails, and nothing could. With it removed in a copy (probe2_f5c.py), no argument I built raised, over closed nesting from 100 to 8000 levels in four positions; `json.loads` accepts up to 2950 levels in this run, and the schema check took every one of them. The guard is defence in depth that no input reaches here.
- **L1, long shell commands go in through stdin. Fixed.**
  - 21 commands each run short (a `bash -c` argument) and padded past the threshold (stdin to a file in /tmp, then `bash`): 20 pairs have identical exit code and output, among them stderr, `exit`, `set -e`, `pipefail`, a here-document, an empty stdin, kill -9 of itself, nested bash, a background job, Unicode and the environment. The one pair that differs is a "command not found" message that names the file where the short form says "bash: line 1". `$0` and `BASH_SOURCE` name the file; `ls -A /tmp` shows it while the call runs. These are the stated limit.
  - The boundary is where the constant says: 7999 and 8000 characters run inline, 8001 from a file. A long call that times out (exit 124), one that ignores TERM (exit 137, after the 5 s grace), and one that removes its own file each leave no command file in /tmp. A command of 104,545 characters runs. With /tmp full, the long command returns the `cat` failure ("No space left on device") and a short one still runs.
  - Removals: L1a (no stdin path) 2 failed, the unit test and the Docker test `test_a_command_past_the_command_line_limit_runs`; L1u (the same, unit test alone) 1; L1b (no NUL refusal) 2, both lengths; L1c (the file not removed) 1.
- **L3, `stop()` runs whatever `start()` raises. Fixed.**
  - A scripted sandbox whose `start()` raises RuntimeError, SandboxUnavailable or OSError: the run ends `error` ("the sandbox did not start: ..."), `stop()` called. KeyboardInterrupt and SystemExit propagate, with `stop()` called (probe2_loop.py).
  - With a real container (probe2_misc.py): `start()` raising RuntimeError after `docker run`: error, container gone. KeyboardInterrupt: propagated, container gone. `docker run` itself failing (a 1 MB memory limit Docker refuses): error, container gone.
  - Removals: L3 1 failed (`test_stop_runs_whatever_start_raises`); L3d with the Docker test 1 failed (`test_a_start_that_raises_after_docker_run_still_removes_the_container`).
- **L4, the container's lifetime comes from the run's budget. Fixed.**
  - A real container started by the loop with `max_run_seconds` 1000 and `call_timeout_seconds` 60 ran `sleep 4660` (1000 + 60 + 3600), as the model saw it. Given to `start()` for 7200 and 300: 11100; for 86400 and 120: 90120; for floats 0.5 and 2.5: 3603.
  - Removals: L4a (the loop passes no lifetime) 1 failed; L4b (`start()` ignores it) 1 failed.
- **L2, L5 and L6 stated as limits.** L5 and L6 are stated accurately, in `sandbox/controls.py`'s docstring, with the measurement of the clone cited (`P2.md` 14:56:59). L2 is stated in three docstrings and is true as far as it goes: see the first item below.
- **No regression, no new wrong answer.**
  - The gate at the fix, in my clone with temp directories in my scratch: `tests ok 271 passed in 76.58s`, `schema ok 3 record lines`, `guard ok 26 fixtures`, `privacy ok 54 files and 14 commit messages`, `livegate ok 34 Python files`, "PASS: 5 of 5 checks hold". `--control`: "controls: 9 of 9 caught". The tests collected: P2's five files hold 44, 52, 4, 34 and 15 (149), and the other files 122.
  - The one command, whole, against the ParcelRound clone read through the P0 worktree: "15 passed in 36.61s", G2's HEAD and tree as before (the clone's tree equal to the source's), G5 "held: the verdicts match (PASS: 10 of 10 checks hold)" with every check line the same, "controls: 2 of 2 held", exit 0.
  - The mounted-gate control's seven stand-in variants and two fail-closed cases (probe_gate.py): each result is as in pass 1, and the 200 KB case now says "the container's output was cut short or timed out, so the verdicts cannot be compared".
  - My pass-1 isolation probe at the fix: its 366 output lines differ from pass 1's only in names, ids, times, process numbers, a disk-free figure and the order Docker lists the three mounts; `docker inspect` reads the same network none, read-only root, cap-drop ALL, no-new-privileges, 2 CPUs, 2 GiB, 256 pids, and the mounts' read-write flags are the same (only the scratch). The tools, limits and removal probes at the fix give the pass-1 results; all eight endings remove the container.
  - My pass-1 mutations re-planted at the fix: 17 of the 18 non-Docker ones, all caught, none missed (the 18th, X4, was not planted: its text did not match exactly once at this commit); all 14 Docker ones caught. The Docker group left containers from my own test runs (one in one mutation, eleven in the one that stops `stop()` removing); I removed those that were not there before the run, by exact name.
  - A trial merge of `round1` at its current tip into the fix (`git merge --no-commit` in a scratch clone): no conflict, and the gate on it: `369 passed in 82.16s`, `468 record lines read`, "PASS: 5 of 5 checks hold". These are the figures `P2.md` 15:15:01 gives.
  - `P2.md` 15:08:41 lists seven removals with their failures; my own removals gave the same counts (F3 3, F4 1, F5 4, L1 2, L3 2, L4a 1, L4b 1).

### Not sent back: to state, to pin or to restate

- **To complete in the stated limit L2.** Two more behaviours of the same kind, measured through the loop with a real container (probe2_path.py): a NUL in a `write_file` path ends the run as `error` ("the tool write_file failed: ValueError: embedded null character"); and a `read_file` or `write_file` path of 40000 characters ends it as `error` ("the sandbox failed during read_file: docker could not be run: FileNotFoundError"), the Windows command-line limit that L1 closed for `shell` alone. The stated limit names a NUL in a shell command and in a `read_file` path, and a lone surrogate; it names neither of these.
- **No test pins these values; each is held by a check of mine, so they are limits and not faults:**
  - the cap on every cause (`CAUSE_CHARS`, 500): removed, 134 tests pass. A 2000-character tool name gives a cause cut to exactly 500 characters, published detail and data alike (probe2_cap.py);
  - `INLINE_COMMAND_CHARS` (8000): raised to 40000, no test fails, because both long-command tests use 100000 characters. A value above Windows's 32767 would bring back the failure for commands between the two; the boundary probe above shows 8000 and 8001 split as intended;
  - `LIFETIME_MARGIN_S` (3600): set to 0, no test fails, because the lifetime test adds the module's own constant;
  - the early return when the file write fails: removed, no test fails (my /tmp-full probe shows what it does);
  - the schema check's guard (F5c, above).
- **A test that now passes by another route.** `test_a_sandbox_that_will_not_start_ends_the_run_before_any_call` defines `NoDocker.start(self)` with no argument, and the loop now calls `start(lifetime_s=...)`, so the test's run ends on a `TypeError` ("the sandbox did not start: TypeError: ... unexpected keyword argument 'lifetime_s'") and not on the `SandboxUnavailable` it names (probe2_loop.py, the old test's class). The assertions hold either way. A start that raises a `SandboxError` and takes the argument gives "the sandbox did not start: docker: not there"; I measured that, and no loop test does.
- **To restate in `P2.md` 15:08:41:** "17 more tests, 15 of them Docker tests". The 17 new tests are 7 in `test_agent_loop.py`, 3 in `test_agent_tools.py`, 5 in `test_sandbox.py` and 2 in `test_sandbox_docker.py`; the Docker file holds 15 in all.
- **A nit.** When the long command's `cat` fails, the partial file stays in /tmp (memory only, gone with the container).

### Not re-run

- P2's own removal file for C1 to C20 (it is in P2's scratch, which I do not read); the pass-1 lists above are my own.
- The pass-1 verdict's other items are not repeated here.

### Disclosures

- The lead's 15:35:17 rule (everything through `shared/lowprio.py`, one heavy process at a time) reached me while a mutation run of mine was running in the background at normal priority. I stopped it, and no process of mine was left. At low priority the machine was saturated (one pytest process had used about 3.5 CPU seconds in six minutes), so I stopped three low-priority runs (two that started one pytest per mutation, and a first single-process version that copied the tree for each mutation) and replaced them with one Python process that runs `pytest.main` per mutation, patching the source in place and restoring it. That run (nine fix removals; its unmutated control passed 23 tests in 83 s) finished at low priority. The lead then lifted the rule, and the rest ran at normal priority.
- A process listing I ran in PowerShell passed the tool's 120 s limit under that load and finished in the background. It listed process names, ids and CPU seconds only.
- I read the commits from a clone made with `git clone --no-hardlinks`, which writes nothing in P2's worktree. The trial merge and its gate ran in a second clone in my scratch. `git status --porcelain` in my first clone prints 0 lines.
- Every temp directory, pytest's basetemp included, was inside my scratch (TMP, TEMP and TMPDIR set by me for those processes). I scanned every pass-2 output file for key-like text, by count only, and found none. No test of P2's prints an environment now: the new parametrized cases carry short ids.
- One container at a time throughout, `docker ps` empty before each. The image and every container that is not mine are untouched.

For: the lead, P2

## 2026-10-06 17:04:50 -0700 - closing, pass 2: nothing of mine is running, and no container is left

Measured: `docker ps -a --filter name=hh- --format {{.Names}}` lists 0 containers, and `docker ps` lists none. Every background task of mine has ended (two finished; the others I stopped, as the verdict entry says), and no python, pytest or docker process whose command line names my scratch is running. The pulled image is untouched. I changed nothing outside `<scratch>/r1-vP2/` and this file. Pass 2 was the last in my budget.

For: the lead
