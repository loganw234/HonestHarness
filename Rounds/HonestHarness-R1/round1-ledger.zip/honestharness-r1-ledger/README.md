# The round ledger (HonestHarness, round 1)

This is the round's record, while it runs and after it. The plan of record is
`Rounds/HonestHarness-R1/PLAN.md` in HonestHarness, approved at `2357035`. At
the round's end the ledger is archived with its timestamps beside the round's
case study, in HonestHarness. **Everything here will be published.** No file
holds a secret or any personal data.

Your dispatch message gives the ledger's absolute path, as
`<repos>/honestharness-r1-ledger/`.

**No absolute paths, here or in any commit.** A path names the owner's
machine. Name every place relative to `<repos>` or `<scratch>`, which your
dispatch message defines.

**No key, ever.** The provider's API key lives in an environment variable.
Never print, log, copy or quote any environment variable's value, nor any
part of one. Only the lead makes paid API calls, through the runner in live
mode. Every parcel and verifier works against local fake endpoints.

## The rules

**One file per author, append only.** Yours is named in your brief: `lead.md`,
`P1.md`, `verifier-P1.md`, and so on.
- Read every file here, and write only to your own.
- Never edit an entry. Correct one by appending a new entry that says which
  entry it corrects.

**Stamps come from the clock, never from memory.** Write every heading with
`date`:

    printf '\n## %s - <headline>\n\nMeasured: ...\nBelieved: ...\nFor: ...\n' "$(date '+%Y-%m-%d %H:%M:%S %z')" >> <your-file>.md

**Values come from the command that measured them**: SHAs, counts, times.
Never type one.

**Read the whole directory at three moments.** They are the floor, whatever
else brings news:
1. before you start;
2. before you design anything that touches a file your brief calls shared
   or forbidden;
3. before you write your report.

**Write an entry when it would change another agent's work, or the lead's.**
That means:
- environment facts;
- a brief that turned out wrong, the moment you find it;
- a finding about shared code.

Mark which claims you **measured** and which you only **believe**.

**Escalation.** Write the question in your own file first, then message the
lead and wait for its answer. If your runtime cannot message, stop, and make
the question your report. Never hold a problem back for your final report.

**The lead's messages.** Every message the lead sends you is in `lead.md`
first, and its decisions are there before they reach you.

**Verifiers** read only `lead.md` and this README until they have formed their
own view of the work. After that, they read the parcel's file to check its
claims.

**Planted faults.** A verifier may be given a copy of a parcel's work that
holds faults the lead planted. The key's hash goes in `lead.md` before
dispatch. Keys, and any description of their plants, stay out of this ledger
until the round's last planted-copy verifier has reported.

**Your scratch directory** is named in your brief. Work only there, outside
your worktree.

**If a pause is announced**, write an entry saying exactly where you are
before you stop.

**Before you report**, stop every background process of your own: watches,
servers, containers and long runs. Say in your report that you did.

## Entry format

    ## <date time zone> - <one-line headline>

    Measured: ...
    Believed: ...
    For: <who this is likely to matter to, or "anyone">
