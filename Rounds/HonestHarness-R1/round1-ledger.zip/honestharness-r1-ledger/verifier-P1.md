# verifier-P1 - the verifier of P1 (QS1), round 1

Append only. Each heading time is taken from `date`. This file is verifier-P1 on Sonnet 5.5 (claude-sonnet-5-5), pass 1 of at most two.

## 2026-10-06 13:43:27 -0700 - pass 1 opens: channel test sent, briefs and lead.md read, planted copy at 17f9d9f on base 929d6e5

Measured:
- I sent "verifier-P1: channel test" to main by SendMessage; the runtime accepted it (queued for main's next turn).
- The copy's HEAD is 17f9d9f (git rev-parse); its parent is 929d6e5. `git diff --stat 929d6e5..HEAD`: 5 files, 2,333 insertions (qs/suites/__init__.py empty, qs/suites/qs1.py, qs/suites/qs1_cases.json, tests/test_qs1.py, tests/test_qs1_cases.py).
- I have read, in this order: README.md, lead.md, briefs/_verifier.md, briefs/verifier-P1.md, briefs/P1.md, briefs/_common.md. I have not read P1.md, P2.md, verifier-P0.md or cs7-reader.md (R2).
Believed: nothing yet about the work.
For: the lead

## 2026-10-06 14:17:11 -0700 - my view of P1's QS1 at 17f9d9f, formed before I read P1.md: NOT READY, on a wrong golden (F1) and a special-token scan that skips names (F2)

Pass 1 of at most two. This is my view of the work, written before I read P1.md (R2). I have still not opened P1.md, P2.md, verifier-P0.md or cs7-reader.md. Nothing below was taken from the author's file.

**View: NOT READY at 17f9d9f. Two wrong answers, F1 and F2, found by content. The gate holds as it says.**

Measured (each by a command I ran in the planted copy, or in a worker copy of it under `<scratch>/r1-vP1/`; temp directories and pytest's base temp were made under `<scratch>/r1-vP1/tmp`):
- **The gate, in the copy:** `python tools/check.py` printed "PASS: 5 of 5 checks hold": tests 217 passed, schema 3 record lines, guard 26 fixtures, privacy 47 files and 12 commit messages, livegate 26 Python files. `python tools/check.py --control` printed "controls: 9 of 9 caught". `pytest --collect-only` counts 84 tests in `tests/test_qs1.py` and 12 in `tests/test_qs1_cases.py`.
- **The seam:** `git diff --name-status 929d6e5..HEAD` lists five added files and nothing else: `qs/suites/__init__.py` (empty), `qs/suites/qs1.py`, `qs/suites/qs1_cases.json`, `tests/test_qs1.py`, `tests/test_qs1_cases.py`. No P0 file is touched. A search of the four non-empty files finds no `live=True`, no environment access, no host but the fake's, and `key_env=None` in the tests. A scan of every non-ASCII character in them finds only the expected ones (the DeepSeek tokens' U+FF5C and U+2581, the degree sign, accented letters, Japanese and Chinese text, an emoji): no homoglyph, no zero-width or no-break space.
- **A conformant run against P1's own fake** (`qs.fake` on 127.0.0.1), 35 items, one repeat, each setting: thinking on, 30 pass and 5 refused (the five documented 400s: `choice.required`, `choice.required.stream`, `choice.named`, `choice.named.stream`, `multiturn.handwritten`), each with `documented.matches` true; thinking off, 35 pass, the hand-written history judged. `QS1.metrics` over the records: trigger tp 29, fp 0, fn 0, tn 13 (on) or 14 (off), F1 1.0, agreement 1.0; schema 34 of 34 (on), 38 of 38 (off).
- **The caps** (item 6): `PriceTable.worst_case("deepseek-flash", "off_peak", 36000, 12000)` is $0.0126 a run, $1.323 over 105 runs; at peak $0.0252 and $2.646. A three-repeat batch run through the runner reserved $1.3326192 (the crossing margin and the probe included), under $1.50, and wrote 105 records of 259,230 bytes in all. QS1 reaches a model only through `Context.chat`, which clamps `max_tokens` to what is left of 12,000; nothing in the suite retries or sends a request outside its golden turns.
- **An independent ideal model**, written by me from each case's prompt alone and never from the goldens (`e03_ideal.py`, 70 item runs, both settings): every item passes, or is refused as documented, except `nested.event` and `nested.event.stream`. Those fail with `name_args`, "priority differs from the golden", in both settings: 4 of 4 runs.
- **What each golden accepts**, against its own `may_vary` text (`e08_variations.py`, 53 replies): every variation a golden names passes and every one it does not name fails, but for the `nested.event` priority below.
- **My own breaking replies** (`e04`, `e05`, `e07`, `e09`, `e11`, `e12`: 81 replies): each assertion fails on a reply that breaks it and names itself, but for the special-token case below. The metric inputs on failing items are right (FP where a call comes with none expected, FN where none comes, the counts of valid and invalid calls). The statuses at turn 1 of the documented cases are right for 400, 422, 401, 402, 429, 500 and 503 (21 of `e11`'s 28 rows; the other 7, the hand-written history in thinking mode, were answered by the fake's own 400 before my status applied). `outcome.data.assertions` is right. The history QS1 sends back is right: reasoning goes back in thinking mode and not otherwise, one tool result per call in call order, each with its call's id and the canned result of the golden call it matched (`e06_history.py`).
- **A mutation sweep of `qs/suites/qs1.py` against P1's own two test files**, each mutant in a worker copy (`mut_driver.py`, `mut2_driver.py`):
  - 415 mutants of comparison, boolean, constant and branch sites: 322 killed, 93 survived;
  - 145 mutants of list elements removed and status or enum words swapped: 114 killed, 31 survived;
  - six targeted mutants of the history code (`mut3_targeted.py`): five survived and one was killed;
  - the survivors are equivalent mutants, fields of `outcome.data`'s per-turn detail that no test reads, and the properties listed below.

**Findings (class, evidence at 17f9d9f, the input that shows it wrong):**

- **F1. Sent back: wrong answer. `nested.event`'s golden has the wrong priority.**
  - Evidence: the prompt is `qs/suites/qs1_cases.json:571`, "The title is Design review, the priority is high, ...". The golden's matcher is `:582`, `"priority": {"equals": "normal"}`, and its canonical value `:600`, `"priority": "normal"`. The golden's own `right`, `:609`, says "the priority enum's value high".
  - Input: a create_event call with priority "high" and every other value as the prompt gives it. `nested.event` and `nested.event.stream` fail it in both thinking settings with `failed=['name_args']`. A reply that ignores the prompt and says "normal" passes.
  - Effect: two of the 35 items score every correct answer as a failure, 12 runs over a pair of settings at 3 repeats. The conformant fake answers from the `canonical` field, so it cannot see it, and the gate's tests pass.
- **F2. Sent back: wrong answer (code against its own docstring). The `special_tokens` assertion does not scan a call's name.**
  - Evidence: `qs/suites/qs1.py:64-65` says "special_tokens: none of SPECIAL_TOKENS in content, nor in a call's name or arguments". `judge_special_tokens`, `:373-382`, builds its places from the content and each call's `arguments` only (`:377`).
  - Input: a reply whose call is named `get_weather<tool_call>`. The item fails with `failed=['name_args']`, and `outcome.data.assertions.special_tokens` reads "pass". A table that counts leaks from that field misses it.
  - Effect: the failure is still recorded, under `name_args`, because a name outside the golden fails there. The attribution is wrong, and TC 7.4's leak count comes up short. With the name restored to the scan, P1's two test files still pass (the sixth edit of `mut3_targeted.py`), so no test holds it either way.

**Properties no test of P1's holds, that I checked by hand and found right today.** A drift in any of them would pass the gate unseen. Each is for the lead to state as a limit, or P1 to pin:
- **The tool results sent back.** Mutants that send every result under the first call's id, pair results by index and not by matched golden, send them in reverse, or send one result for the first call only all survive. The conformant fake never reads a tool message, so QS1's "IDs round-trip" rests on the provider alone. `e06_history.py` shows the current code right.
- **Tools on every request.** A mutant that sends `tools` on the first request only survives. TC 7.7 says to keep tool declarations stable.
- **The lists the tests iterate over.** `SPECIAL_TOKENS` beyond TC 7.4's six, `THINK_MARKERS` and `PROVIDER_CONDITIONS` are tested by parametrising over the code's own constants. Removing any of DeepSeek's eight own tokens, either think marker, or any provider condition survives. The current lists are complete against the research file and D10's finish reasons.
- **Branches of the judge that only a missing reply exercises.** "No call, and a blank content" where a golden expects none; "no call where tool_choice requires one"; the per-assertion result in `outcome.data.assertions`, which is the field a table script reads; and the inner FP and FN assignments of the trigger count, pinned only through `metrics()` on synthetic data and not through a run. No test reads them.
- **A finish_reason that is a JSON array.** `judge()` tests `finish in PROVIDER_CONDITIONS` before `judge_finish` runs, so an unhashable value raises `TypeError` and the run records `error` with an empty `data`, where P1's own unit test of `judge_finish` expects `fail`. No provider is documented to send one: a corner, not a finding.
- **The commit message** of the copy says "216 tests" and "95 tests". The tree has 217 and 96 (the gate's count, and `--collect-only`'s for P1's two files). lead.md 13:42:27 says P1 made two commits and the copy squashes them into one. I believe the message is the first commit's, so the stale counts are the copy's, not P1's.

Believed:
- F1 and F2 are the places where the copy contradicts its own text. Whether they were planted or are P1's own, they are findings on the work.
- Everything else on my list holds: the cases cover TC 7.8, the history and reasoning handling follow D8, the documented 400s are recorded as documented and never as the model's failure, a `length` finish at the clamp is `stopped` and one below it an `error`, the metrics are exact, the caps hold, and the seam is clean.
- I have not yet checked P1's ledger file for privacy, or its claims against mine. That comes after this entry.

For: the lead

## 2026-10-06 14:24:26 -0700 - verdict, pass 1: NOT READY at 17f9d9f; F1 and F2 sent back; what reading P1.md added, and what I ran

Pass 1 of at most two. I opened P1.md only after the view entry above was written, and that entry is unchanged by what follows.

**Verdict: NOT READY at 17f9d9f.** Two items are sent back, both wrong answers: F1 and F2, as the view entry records them, with their evidence and inputs. Nothing is restated. The limits I would have stated, and the properties no test holds, are in the view entry's list.

What is held, by a gate or by a check I ran:
- the gate in the copy, 5 of 5 with 217 tests, and `--control` 9 of 9;
- the seam: five added files, no P0 file touched, no `live=True`, no key variable, no provider host;
- the cases against TC 7.8 and the plan, and each `tool_choice` in each mode, the documented 400s recorded as `refused` and never as the model's failure;
- the goldens, but for F1 (my independent model passes every other item, and in the 53 replies I tried each golden accepted what its `may_vary` names and nothing it does not name);
- the assertions, but for F2: each fails on a reply that breaks it and names itself;
- the metrics and their denominators, on passing and failing items;
- the records: every status is one the schema allows, a `length` finish at the clamp is `stopped` and below it an `error`, and `outcome.data` holds the assertions, the metric inputs and the documented flag;
- the caps: $1.3326192 reserved at 3 repeats off-peak, under $1.50 (peak: $2.6460384 with `--allow-peak`);
- privacy, below.

What reading P1.md added (after the view; each is a check of its claims, and none is a new finding):
- **F2 is against P1's own design too.** P1.md 12:53:19, section 5, item 2: "none of the listed tokens in content, nor in a call's name or arguments". The module docstring says the same. No limit in P1's list (12:53:19 section 12, and the docstring's twelve) states that names go unscanned.
- **F1 is against the design's table.** P1.md 12:53:19, section 3, the `nested.event` row: "create_event with every value the prompt gives".
- **Its counts hold in the copy:** 35 entries in `BREAKS` (21 `name_args`, 5 `reasoning`, 5 `ids`, 4 `finish_reason`), 14 special tokens, 35 items of which 13 are streamed, 49 golden turns a repeat, 38 golden calls, 96 tests in the two files. The metrics on a conformant run (TP 29, TN 13 or 14, 34 or 38 calls) are as I measured them.
- **The copy's commit message is the first of P1's two commits'.** P1.md 13:17:35 reports "216 passed" and 95 tests; 13:37:55 reports 217 and 96, after its second commit. The stale counts are the copy's and not P1's.
- **P1's 22 plants, rebuilt by me from their one-line descriptions** (`p1plants.py`), each in a worker copy, with P1's two test files run on it. Of my 22 rebuilds, 21 were caught at once, 19 of them by the very test P1.md 13:23:39 names; `-x` reached another test first for p04 and p20. My 22nd, p12, emptied `PROVIDER_CONDITIONS` and survived, because `test_a_provider_condition_is_an_error_not_a_failure` parametrises over that set (the same survival the sweep showed). That was my reconstruction and not P1's plant: P1's p12 is "a provider condition recorded as `fail`", and rebuilt that way it is caught by `[aborted]`, as its table says. So all 22 of P1's plants are caught, and no test of P1's looks weakened against P1's own plant classes.
- **Privacy.** The gate's patterns find nothing in P1.md or in this file; neither names the owner, a drive or home path, an address or a key shape. The only addresses are the loopback 127.0.0.1 of the fake. The copy's commit message, read by `git log`, holds no path or address.

The smallest edits, as evidence only (`fixcheck.py`, in a worker copy; the work and the planted copy are untouched, and a verifier does not fix):
- `qs1_cases.json:582` and `:600`, "normal" to "high", and `qs1.py:377`, with the call's name added to the places scanned.
- With those two edits, P1's two test files pass (96 tests), my independent model passes all 35 items in both settings (thinking on: 30 pass and 5 refused as documented), and a call named `get_weather<tool_call>` fails with `failed=['name_args', 'special_tokens']`.
- To hold them, a test of each would do: that the one golden whose prompt names an enum value carries it (a check over the case file, as `test_the_code_and_unicode_goldens_are_the_text_their_prompts_give` does for text), and a token in a call's name beside the token-in-arguments test.

Commands I ran, in order (every path is under `<scratch>/r1-vP1/`; temp variables set by me to `<scratch>/r1-vP1/tmp`):
1. `python tools/check.py` and `python tools/check.py --control` in the copy.
2. `git diff --name-status 929d6e5..HEAD`, `git log`, `git status --short --ignored` (clean before and after everything), `git ls-files --eol`.
3. `pytest --collect-only -q` on P1's two files and on `tests`.
4. A scan of the four files for non-ASCII characters, for `live`, `DEEPSEEK`, `environ`, hosts and personal strings.
5. `vlib.py`, `e01_baseline.py` to `e12_assertions_field.py`: a conformant run in both settings (e01), the priority check (e02), my ideal model (e03), my own breaking replies (e04, e05, e07, e09, e11, e12), the history sent back (e06), record sizes and the three-repeat reservation (e10), and what each golden accepts (e08).
6. `mut_driver.py`, `mut2_driver.py`, `mut3_targeted.py`: 415 and 145 mutants and 6 targeted ones against P1's two test files, in worker copies; results in `mut_results.jsonl` and `mut2_results.jsonl`.
7. `p1plants.py`: P1's 22 plants rebuilt, and `fixcheck.py`: the two smallest edits.
8. The gate's `findings` patterns over P1.md and this file.

Disclosures:
- **My own errors.** In `e04` my "same city twice" reply changed a call that was already Paris (the conformant fake lists parallel calls in reverse golden order), so it changed nothing and passed. I saw that in the output and rebuilt it in `e05`, where it fails as it should. In `e11`, 7 of the 28 rows (the hand-written history in thinking mode) were answered by the fake's own 400 before my status applied, so they test nothing; the view entry says so. `e04` first stopped on my console's encoding and was run again with UTF-8 output.
- **Load.** My mutation drivers ran up to twelve processes at once for about forty minutes on a desktop other sessions share. I stopped the second driver's process (mine, by its id) when I saw that, and resumed it later with six workers. Its children finished on their own.
- **Temp.** Every temp directory, pytest's base temp included, and the gate's own control copies, were made inside `<scratch>/r1-vP1/tmp`, because I set the temp variables myself. Nothing of mine went to the system temp. I removed my worker copies and `tmp` afterwards; the scripts, their output files and the planted copy are left.
- **Hard rules.** I never ran `tools/live.py`, never sent a request to a provider's host (every request went to `qs.fake` on 127.0.0.1, on a random port), never passed the key variable's name to any code, and never read or printed an environment variable's value, but ones I had set. My scripts built each child process's environment with `dict(os.environ, ...)` to add my own variables, which forwards the inherited ones to the child unread; no code of mine reads or prints one, and the suites under test use `key_env=None` against the fake. I edited nothing in the planted copy, in the repository or in any worktree.
- **Reading.** Before the view I read only README.md, lead.md, the three briefs and `_common.md`, and the work with what it cites: the plan of record, TC 7.4, 7.7 and 7.8, and DeepSeek's docs in `<scratch>/ds/`. I also read, from the copy's `Rounds/ParcelRound-R6/`, the lines of PLAN.md and harness-notes.md that say how round 6 planted faults ("one or two per parcel verifier"), to know the protocol. It did not guide my search, which went by content. After the view I read P1.md in full, the headings of P2.md, verifier-P0.md and cs7-reader.md, and lead.md's tail at 14:20, which has no entry since 13:54 that bears on P1. I did not open verifier-P2.md.
- **Processes.** None of mine is running: the sweeps finished or were stopped, and each fake server lived inside a foreground script that exited.

Believed:
- If the key lists a third fault, it is in a place my checks pass over: the 560 mutants of `qs1.py`, the 81 breaking replies, my independent model and the 22 rebuilt plants found nothing else, and a fault in a data field no test reads and no table needs would not show.
- A pass 2 scoped to the diff that fixes F1 and F2 is enough: it needs the `nested.event` golden, the scan of names, and a test of each.

For: the lead

## 2026-10-06 14:24:56 -0700 - correction to the verdict entry of 14:24:26: the load disclosure overstated its duration

Measured, from the creation and last-write times of my own files under `<scratch>/r1-vP1/` (the only times I have for them):
- the gate's `--control` run: 13:46:40 to 13:48:07, one process;
- the first mutation sweep: 13:53:43 to 14:10:30, eight workers;
- the second sweep: started 13:59:15 with four workers, and its driver was stopped at about 14:05; resumed 14:12:39 with six workers and finished 14:15:59.

So twelve processes ran at once for about six minutes (13:59 to about 14:05), not "about forty minutes" as the disclosure in the 14:24:26 entry says. The whole mutation load lasted about 23 minutes (13:53 to 14:16), and never exceeded the twelve logical cores this desktop reports. Nothing else in that entry changes.

For: the lead

## 2026-10-06 14:25:04 -0700 - correction to the correction of 14:24:56: its last clause was not measured

The 14:24:56 entry says the load "never exceeded the twelve logical cores this desktop reports". I did not measure that. What I know: the drivers' workers numbered twelve at most (eight and four), and I ran one foreground script at a time beside them (my breaking-reply and variation scripts), so up to thirteen processes of mine ran at once, for the six minutes the entry gives. The rest of that entry, the times, stands.

For: the lead

## 2026-10-06 14:25:36 -0700 - a nuance on F2's class, for the lead's ruling (adds to the 14:24:26 verdict, changes none of it)

Measured: the plan (PLAN.md section 6, "P1", "The assertions") and P1's brief ask for "no special tokens in content". Scanning a call's name and arguments is P1's own addition, in its design (P1.md 12:53:19, section 5, item 2) and in the module docstring (`qs/suites/qs1.py:64-65`). The code scans the content and the arguments (`:373-382`).

Believed:
- By the plan alone, F2 is not a deviation. By the docstring and the design it is, and `_verifier.md` counts a docstring: a wrong answer is "code that does not do what its plan or docstring says". I kept F2 sent back for that reason.
- The lead may rule the other way, and restate at the merge: the docstring and the design drop "a call's name", and the behaviour becomes a stated limit, by what it concedes: a special token inside a call's name is recorded under `name_args`, never under `special_tokens`, so `outcome.data.assertions.special_tokens` reads "pass" for it.
- F1 has no such question: the prompt, the golden's own `right` text and the design all say "high".

For: the lead
