# verifier-P1: QS1, tool calls through a provider's API

Read `_verifier.md` first. Everything there applies, the planted copy and the
pass budget included.

**The work:** P1's QS1, given to you as a planted copy at
`<scratch>/r1-vP1/copy`. Your dispatch message names the base commit it was
built on. P1's brief is `briefs/P1.md`. The plan's §6, "Wave 1", "P1", is the
authority, and its source is TC §7.8 in
`Research/open-weight-harness-research.md`.

## Your list

1. **The cases** against TC §7.8 and the plan.
   - Is every case there?
   - Does each run under both thinking settings, and judge what depends on
     the mode by it?
   - Does each multi-turn case carry the model's own earlier turns, with
     their reasoning [D8], and never an assistant tool call written by hand,
     except the one hand-written history kept in each mode?
   - Does each `tool_choice` behave as documented in each mode, the
     documented 400s included (D10, `ds/chat_completion_full.txt` lines
     463-466)?
2. **The goldens.**
   - Are they written from the documented format and the case's prompt,
     not recorded from a model?
   - Is each one right for its case?
   - Is what may vary, such as the order of parallel calls, accepted, and
     only that?
3. **The assertions.**
   - Can each one fail? Build a fake reply that breaks it, and see the suite
     fail and name it.
   - Is any assertion vacuous, or one that passes on a reply it should
     refuse?
4. **The metrics.**
   - Are schema accuracy and trigger similarity defined exactly, with their
     denominators?
   - Does the code compute what the definition says?
5. **The records.**
   - Is every status one the schema allows?
   - Is documented behaviour recorded as documented, never as the model's
     failure?
   - Is a `length` finish at the harness's clamp told apart from the
     model's own?
   - Does `outcome.data` hold what a table script needs?
6. **The caps.**
   - Recompute the batch's worst case at 3 repeats, off-peak and peak,
     with `PriceTable.worst_case`. It must be under $1.50 off-peak per
     thinking setting.
   - Can anything in the suite spend past the guard?
7. **The controls.** The conformant fake passes, each breaking fake fails,
   and the documented 400 is recorded as documented.
8. **The seam.**
   - Are P0's files untouched, and only P1's files added?
   - Is there no `live=True`, and no test naming the key's variable?
9. **Privacy** of the copy's commit, its message and P1's ledger file.
10. **Anything else.**

Your ledger file is `verifier-P1.md`. Your scratch directory is
`<scratch>/r1-vP1/`, which holds only the copy when you start.
