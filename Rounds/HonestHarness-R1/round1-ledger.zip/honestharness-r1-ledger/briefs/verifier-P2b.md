# verifier-P2b: read_file's line numbers, a scoped check

Read `_verifier.md` first. Everything there applies, except its planted-copy
section: this check is on the lead's real commit, and plants nothing.

**The work:** one commit of the lead's, `db94d41` on `round1`, on top of
`48d1008`. It changes the format of P2's `read_file` output, from `cat -n`'s
form (a six-wide line number and a tab) to `grep -n`'s ("N: text"). Clone it
into your scratch and work there. Check it with `git diff 48d1008..db94d41`.

**Why it exists** (`lead.md` 03:03:45 to 03:23:16): DeepSeek refused two QS4
runs' third request with HTTP 400 "Content Exists Risk", each just after
`read_file` returned round 6's verifier brief. The lead's two diagnostic
batches found the refusal deterministic in `cat -n`'s form, and absent in
`grep -n`'s. The diagnostics' code is in `<scratch>/r1-lead/diag/`, read-only
to you. Their records are in the lead's checkout, under
`records/runs/diag-filter*.jsonl`, read-only.

## Your list

1. **The format.** Do the in-container read script and `ScriptedSandbox`
   write the same form, on every path: a start line, a line count, the last
   line without a newline, an empty file, a file that is not UTF-8?
2. **The description.** Does `read_file`'s description say what the tool
   now returns?
3. **The tests.** Does each changed test fail with its side reverted? Does
   anything else, a QS4 scorer or parser among them, read line numbers back
   out of `read_file`'s output?
4. **The diagnostics.** Do the two diagnostic suites send what the ledger
   says they send, and do their records show what it says they show?
5. **Regressions.** Is any other behaviour of the loop, the tools or the
   sandbox changed?
6. **The claims.** Does the ledger, or the commit message, claim more than
   the diagnostics measured?

**Not yours:** QS4's live runs, which go on beside your check.

**Your budget:** one pass.

Your ledger file is `verifier-P2b.md`. Your scratch directory is
`<scratch>/r1-vP2b/`.
