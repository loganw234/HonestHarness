# verifier-P1b: QS1's reasoning fix, a scoped check

Read `_verifier.md` first. Everything there applies, except its planted-copy
section: this check is on P1's real commit, and plants nothing.

**The work:** one commit of P1's, `b43b1d6` on branch `r1-p1`, on top of
`726e618`. It changes only QS1's files. Read it read-only from
`<repos>/honestharness-worktrees/P1`, or clone it into your scratch.
Check it with `git diff 726e618..b43b1d6`.

**Why it exists** (`lead.md`, 15:00:40 and 15:09:18):
- Live, in thinking mode, DeepSeek returned `reasoning_content: ""` with 0
  reasoning tokens on 43 of 101 turns.
- QS1 failed those turns, because the lead's brief overreached D8 by asking
  that reasoning be "present".
- A separate fix in P0 (`726e618`) sends an empty field back on a
  thinking-mode turn that had none.

## Your list

1. **In thinking mode,** does an empty `reasoning_content` with 0 reasoning
   tokens pass `reasoning`, and is it recorded per turn?
2. **Do reasoning tokens counted with no reasoning text fail `reasoning`,**
   with a detail naming that case?
3. **Are the leak checks and non-thinking mode unchanged?**
4. **`metrics()`'s new reasoning rate:** is it defined exactly, with its
   denominator? Do records from before the fix leave it unchanged, as P1
   says?
5. **The per-turn record of how reasoning went back** (`text`, `empty` or
   `absent`): does it say what was sent?
6. **Does each new test fail without the fix?** P1 says 18 of the tests
   fail with `qs1.py` from `8d6ba72`.
7. **Is there any regression or new wrong answer** in QS1's other
   assertions, statuses or metrics?
8. **Against D8,** `<scratch>/ds/thinking.txt`: does the fix claim nothing
   the docs do not say?
9. **Live evidence:** the thinking-on batch's local transcripts are at
   `<repos>/honestharness-worktrees/P0/transcripts/qs1-20261006T215607Z/`.
   They are read-only. Does the fix judge those replies as P1 says it would?

**Not yours:**
- `verifier-P1.md` concerns a planted copy whose grading is sealed until
  the round's last planted-copy verifier reports. Do not assess its F1 and
  F2, nor write about them.

**Your budget:** one pass. If a second is needed, it is scoped to the fix of
this pass's findings.

Your ledger file is `verifier-P1b.md`. Your scratch directory is
`<scratch>/r1-vP1b/`.
