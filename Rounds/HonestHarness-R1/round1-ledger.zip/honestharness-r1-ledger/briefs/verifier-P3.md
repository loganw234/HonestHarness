# verifier-P3: the QS6 slice, and QS6's answer key

Read `_verifier.md` first. Everything there applies, the planted copy and the
pass budget included.

**The work:** P3's QS6 slice, given to you as a planted copy at
`<scratch>/r1-vP3/copy`. Your dispatch message names the base commit it was
built on. P3's brief is `briefs/P3.md`. The plan's §6, "Wave 2", "P3", is the
authority. It carries draft 3's design: `git show
52b1bd9:Rounds/HonestHarness-R1/PLAN.md`, in its "Wave 2" section.

**QS6's answer key** is at `<scratch>/r1-vP3/key/qs6_key.json`. It is the
only copy outside P3's scratch. You check it before any live run. Its
SHA-256 must equal `key_sha256` in `qs/suites/qs6_items.json`.

**To run the real-ledger tests,** work in a copy of the copy:
1. Run `python tools/qs6_extract.py --parcelround
   <repos>/parcelround-worktrees/P0`. It reads the archive through git,
   read-only.
2. Copy the key into `local/qs6/qs6_key.json`.

`local/` is gitignored.

## Your list

1. **The cuts.**
   - Each cut is every entry stamped at or before its time, in stamp order.
   - An unstamped file enters by its kept time, in the zone of the stamps.
   - `keys/` never enters.
   - The cut times are the ones the lead accepted (`lead.md` 15:25:54).
   - Each cut renders to its committed hash.
2. **The items.** There are 22: 12 in the length set and 10 in the reach
   set.
   - Is each question answered by the evidence it cites, and only by that?
   - Is each question unambiguous?
   - Does any question quote the owner?
   - Is each length item answerable in the smallest cut?
3. **The answer key, item by item:**
   - each value is read from its evidence;
   - "not in the input" is given where a cut lacks the evidence;
   - each straddling count has its per-cut values;
   - no value comes from CS6's figures or from commit times.
4. **The scorer:**
   - the answer field is taken from the content, never the reasoning, and
     from its last line;
   - each type is normalised;
   - the five classes are assigned correctly;
   - no model text goes into `outcome.data`.
5. **The statuses and caps.**
   - A cap, or a `length` finish at the clamp, is recorded `stopped`.
   - Provider conditions are recorded `error`.
   - Recompute each cut's reservation at 3 repeats, off-peak and with
     `--allow-peak`.
6. **The refusals.** A copy, a cut or a key whose hash differs is refused
   before any call.
7. **The tools.** `qs6_extract.py` and `qs6_key.py` each refuse a mismatch.
8. **The seam and privacy.**
   - Are P0's files untouched?
   - Is no ledger text committed?
   - Is there no home path or address?
9. **Anything else.**

Your ledger file is `verifier-P3.md`. Your scratch directory is
`<scratch>/r1-vP3/`. It holds the copy and the key.
