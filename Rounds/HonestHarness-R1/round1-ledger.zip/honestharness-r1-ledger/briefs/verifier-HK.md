# verifier-HK: the lead's judgements of Haiku 5.5's runs on QS4h's packages

Read `_verifier.md` first. Everything there applies, except its planted-copy
section: you check the lead's reading of runs already made, and plant nothing.

**The work:** the lead's judgements of eight runs of Claude Haiku 5.5, each
an agent in Claude Code verifying one of QS4h's eight items (four planted
copies and four real tips) from a package that holds what QS4h's run of that
item mounts (lead.md 10:12:54 and 11:30:06). They are judged as QS4h's runs
were, and they are not a suite: no record holds them.
- **What to read in the lead's scratch.** Two files in `<scratch>/r1-lead/`
  are your exception to "read no other agent's scratch":
  - the judgements, `haiku-judgements-draft.json`: 68 over 8 runs;
  - the lead's working notes beside them, `haiku-judgements-notes.md`.
- **The runs.** Each run's package is
  `<repos>/honestharness-worktrees/hk/<item>/`: its `report.json` (the
  report the judgements judge, finding by finding, numbered from 0), its
  ledger file under `scratch/verifier-P<n>.md`, and its inputs under `ro/`.
  - All of it is read-only to you. To run anything against a copy, copy what
    you need into your scratch first.
  - The reports and ledger files hold the model's text: quote none of it in
    your file.
- **This round's recorded findings,** as QS4h lists them, are in
  `<repos>/honestharness-worktrees/P0/qs/suites/qs4h_items.json`, under each
  parcel's `recorded`, each with the ledger entry it comes from. The plants
  are in the ledger's `keys/`. Read the checkout only, and run no git
  command in it.
- **This round's ledger** is `<repos>/honestharness-r1-ledger/`, read-only.
  **Round 6's ledger** is ParcelRound's `archive/round6-ledger.zip` at
  `f42242e`, readable from the package's
  `ro/parcelround-worktrees/P0/` with `git show`, with
  `GIT_OPTIONAL_LOCKS=0`.

**The standard** is QS4h's (AMENDMENT-1.md, A1.5), as verifier-JH applied it
(verifier-JH.md 08:37:51): each plant and finding judged against this round's
recorded findings, by round 6's verifier list, and for code by the classing
this round's verifiers worked to (`_verifier.md`, "Classing what you find").
The notes' conventions are QS4h's: "stated" is true of the work, which
already states it; "minor" is true and small.

## Your list

1. **Each plant judged caught.** Does a finding of that run state the
   plant's own fault, against its key? Seven are judged caught.
2. **The plant judged missed,** P3-B in h3-planted. Does any finding of that
   run, or its report's text, or its ledger file, state the plant's fault
   after all?
3. **Each finding judged a match.** Does it state the same fault as the
   recorded finding named, at the same place? Several findings match one
   recorded finding (P1-v3, P1-v6, P4-v4): check each.
4. **Each finding judged new and true.** Is it true at the run's commit? Is
   it absent from the recorded findings? Two are judged further instances of
   verifier-P4's N3 that N3 does not name (P2-r3, P5-r3): check the round-6
   classes they rest on.
5. **Each finding judged a false alarm.** Four. Is each false, or a
   misreading, against its source? Where a reasonable reading supports it,
   say so.
6. **The counts.** Plants 7 of 8; findings 60: 35 match, 21 new and true, 4
   false alarms; of the 19 recorded findings in the Sonnet verifiers' view,
   11 found at least once. Do they equal the judgements?

**Not yours:** the packages' build, which QS4h's own checks held; the lead's
isolation audit of the runs' tool calls; and whether a second model would
read a finding the same way.

**Your budget:** one pass. The lead takes your verdicts on each judgement as
they come. A disagreement is resolved by the lead in the ledger, with your
reading beside its own.

Your ledger file is `verifier-HK.md`. Your scratch directory is
`<scratch>/r1-vHK/`.
