# verifier-P4: the QS4 replay

Read `_verifier.md` first. Everything there applies, the planted copy and the
pass budget included. You are the round's last planted-copy verifier.

**The work:** P4's QS4 replay, given to you as a planted copy at
`<scratch>/r1-vP4/copy`. Your dispatch message names the base commit it was
built on.
- P4's brief is `briefs/P4.md`. The plan's §6, "Wave 2", "P4", is the
  authority.
- The lead's answers to P4's phase-1 questions are in `lead.md` 17:47:24.
- The base includes P0's bounded retry (`lead.md`, the entry that commits
  it). That change is verifier-P0r's, not yours, except where QS4 depends on
  it: its reservation.

**To run the real-input tests and the tools,** work in a copy of the copy:
1. `python tools/qs4_cut.py --parcelround <repos>/parcelround-worktrees/P0`
2. `python tools/qs4_rebuild.py --parcelround <repos>/parcelround-worktrees/P0 --repos <repos>`
   - It runs round 6's gate in Docker at all ten repositories, and takes
     about 15 minutes. It must end "0 not held".
   - Run `docker ps` first. Run one Docker job at a time, and never touch a
     container or image you did not start.
   - It reads the outside sources at their pinned commits with `git
     cat-file`, read-only. Never enter `<repos>/cft-worktrees/`.

`local/` is gitignored. P4's own build is in `<scratch>/r1-P4/integ/local/qs4/`:
compare against it only after you have built your own.

## Your list

1. **The planted copies.** Does each rebuilt copy reproduce its key's
   `copy_commit` SHA? Does a mismatch stop its item before anything is
   mounted?
2. **The replay repositories.** Does each hold only the objects its commit
   reaches, with no refs, remote or reflog, no archive and no case study 6?
3. **The cuts.**
   - Is each verifier's ledger cut at its dispatch, by round 6's own
     `lead.md`?
   - Are unstamped files entered by their kept time?
   - Do `keys/` and the parcel's own file stay out?
   - Is a real tip's one SHA substitution the only difference between its
     cut and its copy's?
   - Does verifier-P5's notice reach its dispatch message?
4. **The guards.** Is every input checked at construction and again in
   `run_item`, before anything is mounted? Does each check fail closed, with
   no model call?
5. **Round 6's gate on the host and in the sandbox.** Is the comparison
   complete: each check, each verdict, each exit code, each control line?
6. **The prompt.**
   - Does the reconstructed dispatch say what round 6's dispatches said?
     Check it against round 6's `lead.md`.
   - Does anything in it tell a planted copy from a real tip?
   - Does the adaptation change only what the sandbox needs?
7. **The score.**
   - Does each plant's span and marker set match its key?
   - Is a finding located only within the tolerance?
   - Does the screen match markers as whole words?
   - Are real tips scored at the tip's lines?
   - Are round 6's recorded findings, and their in-view marks, as round 6's
     ledger records them?
8. **The statuses.** Are they what the brief and the module docstring state,
   in every case? A planted item, a real tip, a stopped or errored run, and
   a run with no report.
9. **The records.** Does any model text reach `outcome.data`?
10. **Caps, budgets and the reservation.**
    - Recompute one run's reservation with P0's runner at QS4's caps, off-peak
      and with `--allow-peak`, and compare it with the pinned figures.
    - Is `max_run_seconds` under 2 hours? The lead's background jobs stop at
      2 hours.
11. **The tools.** Do `qs4_cut.py` and `qs4_rebuild.py` refuse anything that
    differs from what is pinned, and print no absolute path?
12. **The seam and privacy.**
    - Are P0's, P1's, P2's and P3's files untouched, apart from P4's merge
      of `round1`?
    - Is no ledger text committed?
    - Is there no home path or address?
13. **Anything else.**

**Not yours:**
- P0's retry, which verifier-P0r checks.
- The other planted-copy verifiers' findings, whose grading is sealed until
  you report.

Your ledger file is `verifier-P4.md`. Your scratch directory is
`<scratch>/r1-vP4/`. It holds the copy.
