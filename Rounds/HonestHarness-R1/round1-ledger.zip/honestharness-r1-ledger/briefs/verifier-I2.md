# verifier-I2: the round's integration after verifier-I's first pass, and the round's close

Read `_verifier.md` first. Everything there applies, except its planted-copy
section: you work on round1 itself, which holds no plants. The plan's §6
("The integration verifier remakes every merge and reads the lead's own
work") and §8 are your authority.

**Who you are.** verifier-I made this round's first integration pass, READY
at `866a292` (`verifier-I.md`, 2026-10-06 23:01:34). You make its second pass,
as a new verifier on Haiku, by Logan's rule of 2026-10-08 18:24:09 (lead.md).
Start from verifier-I's brief (`briefs/verifier-I.md`) and its file. Your scope
is what came after that pass, and the round's close.

**The work:** branch `round1` from `866a292` to its tip, which the lead's
dispatch names. Clone it into your scratch, and work there.
- The lead's checkout, `<repos>/honestharness-worktrees/P0`, holds the same
  commits, and also local transcripts and local inputs. Read it only where
  your list says. Never write there, and run no git command there.
- The records are committed now, in `records/`.

## Your list

1. **The merge after verifier-I's pass:** `022abee`, P5's.
   - Does a fresh `git merge-tree` of its two parents give its tree, with no
     conflict and no hand edit?
   - Is its second parent the tip that verifier-P5 found READY?
   - Does P5's planted copy differ from that tip by its key's plants alone?
     The key is in the ledger's `keys/`.
2. **The lead's commits that no verifier has read:**
   - `48d1008` (verifier-I's R2);
   - `db94d41`, `b0157ce`, `86235a7` and `0af47f7`;
   - `1775765` (verifier-P0v's F1 and F2, tests only);
   - `dfb7b25` (the restates at P5's merge);
   - `85c7c31` (the table's QS4h section).

   For each: does it change only what its ledger entry says? Is any part of
   it a regression or a wrong answer? Is each new sentence true of the code
   it describes?
3. **The judgements committed:** `bd92fd5` (QS4) and `a065686` (QS4h).
   - Does each committed verdict equal the one its verifier agreed? Where
     the verifier disagreed, does it equal the lead's settlement?
     - `verifier-J.md` and `verifier-JH.md` list their verdicts.
     - The settlements are lead.md 2026-10-07 15:17:50 and 2026-10-08
       08:46:40.
   - **The drafts as checked are gone.** The lead overwrote both drafts in
     its scratch with their settled versions after each check. So the
     SHA-256 values in the dispatch entries (2026-10-07 14:10:01;
     2026-10-08 07:54:20) match no file now. Say whether each committed
     verdict can still be traced to its check, and class the gap.
   - Does each pass its suite's `judgement_problems`?
4. **The records, the selection and the table** (`9e9cd06`).
   - Do the records validate, and agree with their batch summaries?
   - Is each batch the selection leaves out left out for the reason given?
     Check every QS4h exclusion, and at least five of QS4's.
   - Is `TABLE.md` exactly `tools/table.py`'s output, below its header?
5. **The case study** (`d487c8f`, `Rounds/HonestHarness-R1/CASE-STUDY.md`).
   - Check at least 30 of its values against the ledger, the records, the
     table, the judgements files and git, and name each value you checked.
   - Does any sentence claim more than its source holds? Read item 11 (Haiku)
     against lead.md 11:30:06, 12:49:09, 13:18:10 and 14:02:40, and the
     round's end against 18:12:17 and 18:24:09.
6. **The harness notes** (`Rounds/HonestHarness-R1/harness-notes.md`).
   - Does each ledger stamp the notes cite exist?
   - Does any figure in notes 43 to 51 disagree with its source?
7. **The gate at round1's tip:** 5 of 5, and `--control` 9 of 9. State the
   tests that skip in your clone, and why.
8. **Privacy, before the archive.**
   - Does any file in the ledger directory hold an absolute path, a key, or
     a personal address?
   - Logan's own words are kept by his ruling (lead.md 2026-10-07 03:00:44,
     item 2). Does any other personal data appear?
   - Does any file committed on round1 since `866a292` hold any of these?
9. **verifier-I's first-pass items.**
   - R1's correction is at lead.md 2026-10-06 23:06:38. Does it hold?
   - R2 was restated at `48d1008`, and R3 is in the committed selection. Is
     each true now?
10. **Anything else.**

**Not yours:**
- the QS4 and QS4h runs and the content of their judgements, which
  verifier-J and verifier-JH checked;
- the Haiku judgements, which verifier-HK and verifier-HK4 checked;
- Qwen, which did not run;
- round 2's plan.

**Your budget:** two passes. The second is scoped to the fix of the first's
findings.

Your ledger file is `verifier-I2.md`. Your scratch directory is
`<scratch>/r1-vI2/`.
