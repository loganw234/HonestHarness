# verifier-P5: QS4's code slice (QS4h)

Read `_verifier.md` first. Everything there applies, the planted copy and the
pass budget included. You are the code slice's only planted-copy verifier.

**The work:** P5's QS4h, given to you as a planted copy.
- **The copy** is a clone at `<repos>/honestharness-worktrees/vP5`, detached
  at the copy's commit. Your dispatch message names the base commit it was
  built on.
  - It is outside your scratch because Docker's binds fail under the
    scratch's long path (`lead.md` 11:03:35). That clone, and clones of it
    you make beside it, as `<repos>/honestharness-worktrees/vP5-<name>`, are
    yours to work in. That is an exception to "build every fault under your
    own scratch".
- **P5's brief is `briefs/P5.md`.** The authority is
  `Rounds/HonestHarness-R1/AMENDMENT-1.md` on HonestHarness's `main` at
  `b310f82`.
- **The lead's answers:** to P5's design, in `lead.md` 14:32:37; to its
  escalation about P4's Linux-only test and the sandbox's HOME, in 15:13:14.
- **What is not yours:** the base includes the records' code identity
  (`b79217a`, `efd4d17`, `1775765`), which verifier-P0v checked. It is yours
  only where QS4h depends on it.

**To run the real-input tests and the tools,** build your own inputs in the
copy:
1. `python tools/qs4h_rebuild.py --ledger <repos>/honestharness-r1-ledger --parcelround <repos>/parcelround-worktrees/P0 --repos <repos> --ds <scratch>/ds`
   - It rebuilds the eight replay repositories and runs the project's gate
     on the host and in the sandbox at each of them. Expect a long run,
     tens of minutes.
   - `<scratch>/ds/` is DeepSeek's documentation copies: you may read it,
     an exception to the scratch rule.
   - It reads the outside sources at their pinned commits, read-only. Never
     enter `<repos>/cft-worktrees/`.
2. `python tools/qs4h_cut.py --ledger <repos>/honestharness-r1-ledger`
3. **The sandbox image** `hh-qs4h-sandbox` is already on this desktop. Check it
   with `python tools/qs4h_image.py --check-only`. Do not rebuild it: a build
   downloads its wheels, and you download nothing.
- Run `docker ps` first, and one Docker job at a time. Never touch a
  container or image you did not start, except to check this one image.
  The `hh-sbx-*` and `hh-qs4h-*` containers you did not start are not yours.

## Your list

1. **The rebuild rule (A1.3).**
   - Does each of the four copies rebuild to its key's `copy_commit`?
   - Is each real tip built by the same rule, with the tip's tree?
   - Does a mismatch stop its item before anything is mounted?
2. **The replay repositories.** Does each hold only its commit's closure,
   with no refs, remote or reflog? Are the forbidden blobs, the other
   condition's planted files and the keys, absent?
3. **The cuts.**
   - Is each at its stamp, as `lead.md` records the copy and its sealed
     hash?
   - Are `keys/` and the parcel's own file out?
   - Are both SHAs mapped, so that the planted and real cuts differ only
     where the item's own commit stands?
   - Are the shared briefs rebuilt for P1 and P2 alone, exactly as pinned?
   - Is a cut refused that lacks a brief its verifier read, from the
     verifiers' own files?
4. **The inputs each verifier had.** Check them against `verifier-P1.md` to
   `verifier-P4.md`:
   - DeepSeek's copies for h1 and h3;
   - ParcelRound for h2 to h4;
   - the twelve outside files for h4.
5. **The guards.** Is every input checked at construction and again in
   `run_item`, failing closed, before anything is mounted or spent?
6. **The gate on the host and in the sandbox.**
   - Is the comparison complete?
   - Is P4's pinned Linux-only test held as the lead decided, and as
     nothing wider?
7. **The prompt.**
   - Does the rebuilt dispatch say what each original dispatch said? Check
     it against `lead.md`.
   - Does anything in it tell a planted copy from a real tip, or say more
     than the originals did?
8. **The score.**
   - Does each plant's spans match its key's edits, a deletion's join and
     each edit of a two-edit plant included?
   - Is a finding located only within its tolerance?
   - Do the markers name each plant's own change?
   - Are this round's recorded findings, their places and their in-view
     marks, as the four verifiers' own files record them?
   - Is a finding matched to a recorded one only as the module's docstring
     says?
9. **The statuses and the records.** Are the statuses those of the
   docstring in every case? Does any model text reach `outcome.data`?
10. **Caps, budgets and the reservation.** Recompute one batch's reservation
    with P0's runner at QS4's caps, off-peak and at N = 28, and compare it
    with the pinned figures.
11. **The tools and the image.**
    - Do the tools refuse anything that differs from what is pinned?
    - Do they print no absolute path?
    - Is the image what `sandbox/qs4h.Dockerfile` and its pinned wheels
      make?
12. **The seam and privacy.**
    - Are every other parcel's files and QS4's untouched, with QS4's version
      unmoved?
    - Is no ledger text committed?
    - Is there no home path or address?
13. **Anything else.**

**Not yours:**
- the records' code identity, which verifier-P0v checks;
- QS4's own judgements, which verifier-J checked.

Your ledger file is `verifier-P5.md`. Your scratch directory is
`<scratch>/r1-vP5/`.
