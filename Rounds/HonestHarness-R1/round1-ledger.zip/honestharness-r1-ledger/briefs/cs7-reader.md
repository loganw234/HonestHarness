# cs7-reader: what ParcelRound's case study 7 holds for this round

You are a reader, not an author or a verifier. Read one document and report
what in it bears on this round. Fix nothing. Write only your ledger file, and
files in your scratch directory, `<scratch>/r1-cs7/`, which exists and is
empty. For example, extract an archive there to read it.

**The document:** ParcelRound's `CASE-STUDY-7.md`, at commit `894d125` on the
local branch `case-study-7`.
- **Read it only through git's object store, from ParcelRound's round-6
  worktree:**
  `GIT_OPTIONAL_LOCKS=0 git -C <repos>/parcelround-worktrees/P0 show 894d125:CASE-STUDY-7.md`.
  The same works for any other file at that commit, such as
  `archive/round7-cost-scripts.zip`.
- **Never enter `<repos>/cft-worktrees/`**, where that branch is checked out.
  Another session works there.
- For background you may also read `CASE-STUDY-6.md` at `f42242e` the same
  way.

**This round:** HonestHarness round 1. Its plan is in HonestHarness at
`Rounds/HonestHarness-R1/PLAN.md`, read from `<repos>/HonestHarness`.
- It builds a runner, `qs/`, that measures a non-Claude model, DeepSeek over
  its API, on ParcelRound's method.
- It is the first rung of a step down from the Claude models the method was
  learned on.
- Parcels run on Opus, and the verifiers on Opus with planted faults.

## What to report

1. **The round in brief:** what it built, when, which models in which roles,
   its scale and duration, and how it ended. Give line numbers.
2. **What bears on this round,** each with its CS7 line and a one-line "so
   what":
   - the method's rules: new practices, broken rules, proposals;
   - model behaviour, especially any Sonnet, non-Claude or long-duration
     findings;
   - cost and token figures, and how they were measured;
   - verification: planted faults, verifiers' yield, gates, threat models;
   - long-round lessons: pauses, drift, context and compaction, resumption;
   - anything about harnesses, tools or automation.
3. **What CS7 updates or contradicts** in CS6 or in this round's plan's
   assumptions.
4. **Quotations** you rely on, exact, with line numbers. Under 15 words
   each.

Keep it compact: the lead reads it before writing wave 1's briefs.

Your ledger file is `cs7-reader.md`, in the ledger. Your report is your final
message. Stamps come from `date`. No absolute paths anywhere.
