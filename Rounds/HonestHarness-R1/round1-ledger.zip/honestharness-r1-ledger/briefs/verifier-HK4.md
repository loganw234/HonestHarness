# verifier-HK4: the lead's judgements of Haiku 5.5's runs on QS4's packages

Read `_verifier.md` first. Everything there applies, except its planted-copy
section: you check the lead's reading of runs already made, and plant nothing.

**The work:** the lead's judgements of ten runs of Claude Haiku 5.5, each an
agent in Claude Code verifying one of QS4's ten items (round 6's five planted
copies and five real tips) from a package that holds what QS4's run of that
item mounts (lead.md 2026-10-08 12:11:23, and the lead's entry that dispatches
you). They are judged as QS4's DeepSeek runs were, and they are not a suite:
no record holds them.
- **What to read in the lead's scratch.** Two files in `<scratch>/r1-lead/`
  are your exception to "read no other agent's scratch":
  - the judgements, `haiku4-judgements-draft.json`: 57 over 10 runs;
  - the lead's working notes beside them, `haiku4-judgements-notes.md`.
- **The runs.** Each run's package is
  `<repos>/honestharness-worktrees/hk4/<item>/`: its `report.json` (the
  report the judgements judge, finding by finding, numbered from 0), its
  ledger file under `scratch/verifier-P<n>.md`, and its inputs under `ro/`.
  - `ro/r6-vcopy-P<n>` is a git repository at the item's commit: read its
    history with `git show` and `git log` only, with `GIT_OPTIONAL_LOCKS=0`.
  - All of it is read-only to you. To run anything against a copy, copy what
    you need into your scratch first.
  - The reports and ledger files hold the model's text: quote none of it in
    your file.
- **Round 6's recorded findings,** as QS4 lists them, are in
  `<repos>/honestharness-worktrees/P0/qs/suites/qs4_items.json`, under each
  parcel's `r6_findings`, each with the entry it comes from; a real tip
  leaves out the ones marked `copy_only`. DeepSeek's QS4 judgements, which
  the notes cite for consistency, are in the same directory's
  `qs4_judgements.json`. Read the checkout only, and run no git command in it.
- **Round 6's keys and ledger** are in ParcelRound's
  `archive/round6-ledger.zip` at `f42242e`, read through
  `<repos>/parcelround-worktrees/P0` with `git show` and
  `GIT_OPTIONAL_LOCKS=0`, as verifier-J read them. Round 6's merged files
  (`ADOPTION.md`, `templates/`) at `f42242e` are read the same way. Run no
  other git command there.

**The standard** is QS4's, as verifier-J applied it to DeepSeek's runs
(verifier-J.md; lead.md 2026-10-07 15:17:50): round 6's own list in its
`briefs/_verifier.md` ("Your list", items 1 to 6). A finding that states a
plant is judged through the plant, as in `qs4_judgements.json`. The notes'
conventions are QS4's: "stated" is true of the work, which already states
it; "minor" is true and small; "known to round 6 outside its list" is true,
and recorded by round 6's parcel or lead though not by its verifiers.

## Your list

1. **Each plant judged caught.** Does a finding of that run state the
   plant's own fault, against its key? Nine are judged caught. A finding
   near the plant that states another fault does not catch it (QS4's
   limit 7).
2. **The plant judged missed,** P4-p1 in p4-planted. Does any finding of
   that run, or its report's text, or its ledger file, state the plant's
   fault after all? QS4's screen counts the run's finding 1.
3. **Each finding judged a match.** Twenty-one. Does it state the same fault
   as the round-6 finding named, at the same place? Two pairs match one
   recorded finding (P3-r4 in p3-planted, P4-r2 in p4-real): check each.
4. **Each finding judged new and true.** Thirteen. Is it true at the run's
   commit? Is it absent from round 6's verifiers' record? p5-real's finding
   1 rests on the lead's reading that CS2#28 is carried by no template at
   P5's tip, nor in round 6's merged templates at `f42242e`, whose
   ADOPTION.md names the checklists: check that reading hardest.
5. **Each finding judged a false alarm.** Thirteen, several marked
   contestable. Is each false, or a misreading, against its source? Where a
   reasonable reading supports it, say so.
6. **The counts.** Plants 9 of 10; findings 47: 21 match, 13 new and true,
   13 false alarms; round 6's recorded findings found, in view 10 of 31 and
   out of view 9 of 28. Do they equal the judgements?

**Not yours:** the packages' build, which QS4's own checks held; the lead's
isolation audit of the runs' tool calls; and whether a second model would
read a finding the same way.

**Your budget:** one pass. The lead takes your verdicts on each judgement as
they come. A disagreement is resolved by the lead in the ledger, with your
reading beside its own.

Your ledger file is `verifier-HK4.md`. Your scratch directory is
`<scratch>/r1-vHK4/`.
