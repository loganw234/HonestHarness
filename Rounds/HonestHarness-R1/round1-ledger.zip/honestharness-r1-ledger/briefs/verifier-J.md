# verifier-J: the lead's judgements of QS4's runs

Read `_verifier.md` first. Everything there applies, except its planted-copy
section: you check the lead's reading of runs already made, and plant nothing.

**The work:** the lead's judgements of every scored QS4 run, before they go
into `qs/suites/qs4_judgements.json`. QS4's module docstring makes the lead's
judgement the score of record, "checked by a verifier": that is you.
- **What to read in the lead's scratch.** Three files in `<scratch>/r1-lead/`
  are your exception to "read no other agent's scratch":
  - the judgements, `qs4-judgements-draft.json`: 89 over 34 runs, and its
    `left_out` list, each entry marked whether it keeps its pass;
  - the lead's working notes beside them, `qs4-judgements-notes.md`;
  - the dataset the lead drew from them, `qs4-dataset.md`.
- **The records.** Each run's record is in the lead's checkout,
  `<repos>/honestharness-worktrees/P0`, under `records/runs/qs4-*.jsonl`, and
  its local transcript under `transcripts/<batch>/`. The lanes' runs are
  merged there (lead.md 14:08:26).
  - Both are read-only to you: run no git command there, and write nothing.
  - The transcripts hold the model's text: quote none of it in your file.
- **Round 6's recorded findings,** as QS4 lists them, are in the checkout's
  `qs/suites/qs4_items.json`, under each parcel's `r6_findings`.
- Round 6's keys and ledger are in ParcelRound's `archive/round6-ledger.zip`
  at `f42242e`, read through `<repos>/parcelround-worktrees/P0` with
  `GIT_OPTIONAL_LOCKS=0`. The replay repositories are under the checkout's
  `local/qs4/repos/`, read-only.

**The standard** is round 6's own: the list in its `briefs/_verifier.md`
("Your list", items 1 to 6). A finding is true when that list would count it,
and the lead's notes name the item where a verdict turns on one. Where the
lead's first verdict changed under that list, the notes say so: check the
change too.

## Your list

1. **Each plant judged caught.** Does a finding of that run state the
   plant's own fault: the source's value against the planted one, or the
   contradiction the plant makes? A finding near the plant that states
   another fault does not catch it (QS4's limit 7).
2. **Each plant judged missed.** Does any finding of that run, anywhere in
   its report, state the plant's fault after all?
3. **Each finding judged a match.** Does it state the same fault as the round
   6 finding named, at the same place? A finding matched by file alone is
   the case to look at hardest.
4. **Each finding judged new and true.** Is it true at the run's commit? Was
   it absent from round 6's record?
5. **Each finding judged a false alarm.** Is it false, or a misreading,
   against its source? Where a reasonable reading supports it, say so: such
   a case is judged, and says so.
6. **The runs left out of the score.** Is each reason true of its record?
   The reasons are:
   - refused by the content filter;
   - ended by attempts closed with no reply, past a call's retries or the
     batch's allowance;
   - run under the earlier `read_file` form;
   - run without the outside sources;
   - stopped at a cap. Such a run keeps its pass, since a cap is the model's
     outcome under the run's limits.
7. **The counts.** Do the per-item and per-pass totals the lead draws from
   the judgements equal the judgements?

**Not yours:** the screen's code, which P4's verifier checked, and whether a
second model would read a finding the same way.

**Your budget:** one pass. The lead takes your verdicts on each judgement as
they come. A disagreement is resolved by the lead in the ledger, with your
reading beside its own.

Your ledger file is `verifier-J.md`. Your scratch directory is
`<scratch>/r1-vJ/`.
