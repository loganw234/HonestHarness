# verifier-P0r: P0's bounded retry, a scoped check

Read `_verifier.md` first. Everything there applies, except its planted-copy
section: this check is on the lead's real commit, and plants nothing.

**The work:** one commit of the lead's, `7b0dc64` on `round1`, on top of
`1b21e38`. It changes P0's runner, its fake endpoint, the run record's schema
and their tests. Check it with `git diff 1b21e38..7b0dc64`.
- Clone it into your scratch and work there. The lead's checkout,
  `<repos>/honestharness-worktrees/P0`, holds uncommitted live records under
  `records/`, `transcripts/` and `local/`: never write there, and never
  quote, copy or commit those records.
- One read there is yours: the two error lines in
  `transcripts/qs6-c064k-*/`, for item 9 below.

**Why it exists** (`lead.md`, 19:11:24, and the entry that commits it):
- Live, at peak, DeepSeek closed 2 of about 31 requests of 64K tokens with
  no reply at all, 18 to 25 s in. Each stopped its QS6 batch, as P0 was
  built to do.
- The lead decided on a bounded retry. Such an attempt is retried after a
  delay, at most twice for one call and three failed attempts for a batch.
  The reservation covers three unmetered calls, and the record counts them.

## Your list

1. **Only a request closed with no reply is retried.** Does every other
   failure still behave as before it: any other transport error, a stream
   cut short, a reply without usage, every provider status?
2. **The bounds.** Is a call retried at most as often as it has delays, and
   does a batch stop at its third failed attempt, whichever comes first? Can
   a suite that catches errors and retries send past either bound?
3. **The gate and the delay.** Does each retry wait its delay, then pass the
   peak gate again before it is sent?
4. **The reservation.** Is the unmetered margin exactly `max_unmetered` times
   the dearest single call at either period, in every batch? Work the pinned
   figures by hand: P0's tests, QS1's and QS6's.
5. **The record.** Are the run record's `unmetered_calls` and the summary's
   `unmetered_attempts` and `unmetered_margin_usd` what they claim? Do
   records written before the change still validate?
6. **Reconciliation.** When reconciliation is not ok after such attempts,
   does the summary's detail say they may have been billed? What can an
   unmetered bill still hide inside the tolerance?
7. **The ceiling.** After a billed drop, can the spend file hold less than
   was billed?
8. **The tests.** Does each new or changed test fail with its part removed?
   The lead's removal run is in the entry that commits the change.
9. **Live evidence.** Does the string the retry matches appear in the two
   live error lines, as recorded?
10. **Regressions.** Is any behaviour changed for a batch with no dropped
    request: QS1, QS6, and P2's agent loop, which calls `Context.chat`?
11. **The docstrings.** Do `qs/suite.py`'s module docstring and comments
    state the retry and its limits truthfully?

**Not yours:**
- QS4, on branch `r1-p4`: not merged, and checked by its own verifier.
- The planted-copy verifiers' findings, whose grading is sealed.

**Your budget:** one pass. If a second is needed, it is scoped to the fix of
this pass's findings.

Your ledger file is `verifier-P0r.md`. Your scratch directory is
`<scratch>/r1-vP0r/`.
