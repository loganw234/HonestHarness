# verifier-I: the round's integration, and the lead's own work

Read `_verifier.md` first. Everything there applies, except its planted-copy
section: you work on round1 itself, which holds no plants. The plan's §6
("The integration verifier remakes every merge and reads the lead's own
work") and §8 are your authority.

**The work:** branch `round1` at `866a292`, every parcel merged. Clone it into
your scratch and work there. The lead's checkout,
`<repos>/honestharness-worktrees/P0`, holds uncommitted live records under
`records/`, local transcripts and local inputs. Read them only where your list
says, and never write there.

QS4's live runs have not started, and Qwen waits for Logan's word. A scoped
second pass will cover what comes after them: the table's selection file, and
the case study.

## Your list

1. **The merges.** For each merge on round1's first-parent line (`d9b0973`,
   `da8095d`, `c6c1a6e`, `5cd0960`, `b5744e0`):
   - Does a fresh merge of its two parents give its tree, with no conflict
     and no hand edit?
   - Is the parcel tip it merges the one the ledger names as checked?
   - Where that check was on a planted copy, does the copy differ from the tip
     by its key's plants alone? The keys are now in the ledger's `keys/`.
2. **The restates** (`4c59e58`, `1b21e38`, `9a4cc8c`, `aeba900`): does each
   change only what its ledger entry says, and is each new sentence true of
   the code it describes?
3. **The lead's own commits that no verifier has read:**
   - `929d6e5` (fix 4), `0692de3` (`ItemResult.local`), `726e618` (fix 5) and
     `6f0d928` (`local/` ignored);
   - `866a292`, `tools/table.py` and its tests;
   - the record commits `0963e9f`, `9e9d78b` and `9d6628d`.

   Is any a regression or a wrong answer? Do the records validate, and agree
   with their batch summaries?
4. **The table script.** Draw the table read-only from the checkout's records,
   with the lead's draft selection,
   `<scratch>/r1-lead/table/select-draft.json`. Is each figure what the
   records hold? Is each batch left out for the reason given?
5. **The ledger against the data.** Check at least ten of the lead's measured
   values since 19:11:24 against the records, the spend file, the batch
   summaries, git and the keys. Name each value you checked.
6. **The grading** (`lead.md` 22:00:27). Is each plant matched to the
   verifier finding the lead names? Does each key's SHA-256 equal the hash
   sealed before its verifier's dispatch?
7. **The gate at round1's tip:** 5 of 5, and `--control` 9 of 9. State any
   tests that skip in your clone, and why.
8. **Privacy, before the archive.** Does any file in the ledger directory
   hold an absolute path, a key, a personal address, or words of the owner's
   beyond what the README allows? Does any committed file on round1?
9. **Anything else.**

**Not yours:**
- QS4's and Qwen's live runs, which have not happened;
- the case study, not yet written.

**Your budget:** two passes. The second is scoped to the fix of the first's
findings.

Your ledger file is `verifier-I.md`. Your scratch directory is
`<scratch>/r1-vI/`.
