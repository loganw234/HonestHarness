# verifier-JH: the lead's judgements of QS4h's runs

Read `_verifier.md` first. Everything there applies, except its planted-copy
section: you check the lead's reading of runs already made, and plant nothing.

**The work:** the lead's judgements of every scored QS4h run, before they go
into `qs/suites/qs4h_judgements.json`. QS4h's module docstring makes the
lead's judgement the score of record, "checked by a verifier": that is you.
- **What to read in the lead's scratch.** Three files in `<scratch>/r1-lead/`
  are your exception to "read no other agent's scratch":
  - the judgements, `qs4h-judgements-draft.json`: 87 over 30 runs, and its
    `left_out` list;
  - the lead's working notes beside them, `qs4h-judgements-notes.md`;
  - the dataset the lead drew from them, `qs4h-dataset.md`.
- **The records.** Each run's record is in the lead's checkout,
  `<repos>/honestharness-worktrees/P0`, under `records/runs/qs4h-*.jsonl`,
  and its local transcript under `transcripts/<batch>/`. The lanes' runs are
  merged there (lead.md, the entry that dispatches you).
  - Both are read-only to you: run no git command there, and write nothing.
  - The transcripts hold the model's text: quote none of it in your file.
- **This round's recorded findings,** as QS4h lists them, are in the
  checkout's `qs/suites/qs4h_items.json`, under each parcel's `recorded`,
  each with the ledger entry it comes from.
- **This round's ledger** is `<repos>/honestharness-r1-ledger/`, read-only:
  the parcels' and verifiers' files, `lead.md`, and `keys/`, whose four keys
  hold each copy's plants.
- **The copies and tips the runs read** are under the checkout's
  `local/qs4h/repos/`, named by the first twelve characters of their commit
  (`local/qs4h/built.json` maps each item to its repository), and each run's
  ledger cut under `local/qs4h/cuts/` (`cuts.json`). All read-only. To run
  anything, copy what you need into your scratch first.

**The standard** is amendment 1's (A1.5): each plant and finding judged
against this round's recorded findings, by round 6's verifier list as for
QS4's judgements, and, for code, by the classing this round's verifiers
worked to (`_verifier.md`, "Classing what you find"): a finding is true when
the code does not do what its docstring or plan says, or can spend, leak or
record wrongly, or when a sentence claims more than is true.

## Your list

1. **Each plant judged caught.** Does a finding of that run state the
   plant's own fault: the code's behaviour against what its docstring, data
   or brief promise? A finding near the plant that states another fault does
   not catch it.
   - Five catches are by judgement where the screen missed (P1-B twice, P2-B
     three times): the finding cites the promise's lines, or a check far from
     the edit, not the edited line (harness note 49). Check each against its
     plant's key.
2. **Each plant judged missed.** One, P3-B in `091310Z`. Does any finding of
   that run, or its report's text, or its ledger file, state the plant's
   fault after all?
3. **Each finding judged a match.** Does it state the same fault as the
   recorded finding named, at the same place? A finding the screen matched by
   file alone is the case to look at hardest; several such screen matches
   were judged new, not matches.
4. **Each finding judged new and true.** Is it true at the run's commit? Is
   it absent from the recorded findings? Three conventions to check:
   - "stated": true of the work, which already states it (QS4's precedent);
   - "minor": true, and small;
   - "replay": true of the run's inputs, not of the parcel's work, and
     counted apart. This is the lead's ruling, new in QS4h: QS4's judgements
     met no such finding. Say whether you would rule the same.
5. **Each finding judged a false alarm.** Is it false, or a misreading,
   against its source? Where a reasonable reading supports it, say so.
6. **The `status_basis` findings** (`092139Z` f1, `121314Z` f0) turn on a
   field whose values no docstring states. Do you read them as the lead does?
7. **The runs left out of the score.** Is each reason true of its record?
   The reasons are:
   - ended by attempts closed with no reply, past a call's retries or the
     batch's allowance;
   - ended by a connection reset;
   - interrupted at its start by the lead's restart, with spend lines and no
     summary.
8. **The counts.** Do the per-item, per-pass and per-plant totals in the
   dataset equal the judgements?

**Not yours:** the screen's code and QS4h's build, which verifier-P5
checked; and whether a second model would read a finding the same way.

**Your budget:** one pass. The lead takes your verdicts on each judgement as
they come. A disagreement is resolved by the lead in the ledger, with your
reading beside its own.

Your ledger file is `verifier-JH.md`. Your scratch directory is
`<scratch>/r1-vJH/`.
