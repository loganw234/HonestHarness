# verifier-P2: the agent loop and its sandbox

Read `_verifier.md` first. Everything there applies, the planted copy and the
pass budget included.

**The work:** P2's loop and sandbox, given to you as a planted copy at
`<scratch>/r1-vP2/copy`. Your dispatch message names the base commit it was
built on. P2's brief is `briefs/P2.md`. The plan's §6, "Wave 1", "P2", is the
authority.

## Docker on this desktop

- **Run `docker ps` before you start any container.** On this desktop, one
  run at a time (plan §8, B16).
- **Name your own containers with the prefix `hh-vP2-`,** and remove each
  one when you are done with it.
- **Never remove, prune or change** an image, container, volume or network
  you did not create. Other projects' images are here, and their sessions
  may be running containers.
- **The image P2 chose is P2's download.** If you need another, record its
  name, source and size in your ledger first.

## Your list

1. **The sandbox's isolation.** Try each from inside it:
   - the network: a DNS lookup, a TCP connection to a literal IP, and the
     host through `host.docker.internal`;
   - a write outside the scratch, and to the root filesystem;
   - the mounts: are they exactly what the run was given, all read-only?
   - nothing ambient: no Docker socket, no home directory, no credential,
     and no environment variable but those P2 sets;
   - the limits: CPU, memory and process count, and the per-call timeout;
   - removal: is each container gone after a run ends normally, on an
     error, and on a timeout?
2. **The mounted gate run.**
   - Does P2 assert the clone's HEAD and tree before mounting?
   - Does it mount with `--mount ... readonly`, so a missing source refuses?
   - Does it run the gate on the host and in the container, and compare
     the two verdicts?
   - Does it fail closed?
3. **The loop.**
   - Does it record every message and every tool execution?
   - Does it pass reasoning back with tools [D8], and never insert a tool
     call the model did not make [D9]?
   - Do its budgets (turns, tokens, wall clock) end a run as `stopped`,
     never as "found nothing"?
   - Does it record what P2's design says when a tool call or the sandbox
     raises?
   - Is `ctx.stop_reason` respected when the loop catches an error?
4. **Tool output.**
   - Is it delimited, with control tokens stripped?
   - Is it truncated to a size the code states?
   - Can it change any permission?
5. **Malformed arguments** go back as tool-result errors, within the retry
   limit.
6. **The controls** from the plan's §6:
   - the network attempt;
   - the write outside the scratch;
   - the budget refusal;
   - git and Python inside;
   - the gate in a mounted copy.

   Each must fail when its guard is removed. Build the removal in a copy of
   the copy.
7. **Without Docker,** do the tests that need it skip and say why? Does the
   one command for the Docker controls run them all?
8. **The download.** Was the image recorded in P2's ledger before it was
   pulled, from an official source?
9. **The seam and privacy.**
   - Are P0's files untouched?
   - Is there no `live=True`, and no test naming the key's variable?
   - Are there no home paths in Docker Desktop's forms, which the gate now
     catches?
10. **Anything else.**

Your ledger file is `verifier-P2.md`. Your scratch directory is
`<scratch>/r1-vP2/`, which holds only the copy when you start.
