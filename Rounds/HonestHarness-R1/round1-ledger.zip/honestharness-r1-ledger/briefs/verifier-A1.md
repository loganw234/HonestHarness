# verifier-A1: the plan's amendment 1, QS4's code slice

Read `_verifier.md` first. Everything there applies, except its planted-copy
section and its READY test: you check a plan, not code, and plant nothing.

**The work:** the lead's draft of amendment 1 to the plan of record, at
`<scratch>/r1-lead/plan-amendment-1.md`, SHA-256
`f8a3a83c7309c622989976d89e281569fd05160896aca59f27c8c8bd5a91fae8`. That one
file is your exception to "read no other agent's scratch". Check its hash
before you read it. It adds a replay of this round's own four planted copies
to DeepSeek's suite, at Logan's ruling (`lead.md` 12:41:38). It goes to Logan
for approval after your verdict.

- The plan of record is `Rounds/HonestHarness-R1/PLAN.md` at `2357035` on
  HonestHarness's `main`.
- The keys are in the ledger's `keys/`, published at 22:00:27.
- The round's code is `round1` at `0af47f7`. Clone it into your scratch, and
  rebuild any copy there.

## Your list

1. **Its facts.** Check each of these against git, `keys/` and `lead.md`:
   - the commits;
   - the dispatch stamps;
   - each plant's description;
   - the baseline (8 of 8, each in its first pass);
   - the reservation arithmetic ($23.87 at N = 23, $17.93 at N = 15);
   - the ruling stamps;
   - what verifier-P3 was given.
2. **The copies.** Does each copy rebuild from its real tip and its key, to
   its `copy_commit`, by the rule P4's `tools/qs4_rebuild.py` uses for round
   6's?
3. **What each verifier had.** From each planted-copy verifier's own ledger
   file, read after your view of the draft is formed: what did it read
   outside the repository, and does A1.3 name a way to give the replay each
   of those? Name any input the draft misses.
4. **The sandbox.**
   - What does the project need, to run its tests offline in
     `python:3.12-trixie`?
   - Which tests need Docker, or a network?
   - For each of the 8 plants: can it be shown in such a sandbox without
     Docker, by a test or a run? Try it in your clone, with Docker-needing
     tests skipped.
5. **Its risks.** What does it leave out?
   - Contamination, and QS6's withheld answer key.
   - The self-reference: P4's copy holds QS4's own code and prompt.
   - The swap test's needs (A1.8).
   - Cost, the balance, and anything that would make a run not "what that
     verifier had".
6. **Its claims.** Does any sentence claim more than is true?

**Not yours:** QS4's live runs and their judgements, which go on beside your
check, and the code the amendment would build.

**Your budget:** one pass. Class each finding as the plan's: a wrong fact to
correct, a gap to close before approval, or a limit to state.

Your ledger file is `verifier-A1.md`. Your scratch directory is
`<scratch>/r1-vA1/`.
