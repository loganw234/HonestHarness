# Round 1: what every parcel's brief shares

Read this first, then your own brief (`P1.md` or `P2.md` beside it). Where
your brief and this file disagree, say so in the ledger at once. Don't pick
one.

## The project

You are a parcel in HonestHarness's round 1, a round run on ParcelRound's
method.

**The repository.** HonestHarness (github.com/loganw234/HonestHarness, MIT)
is building `qs/`, a runner for **qualification suites**. A suite measures a
model reached through a hosted API, and its records are what decide which
models can hold which roles. The plan of record is
`Rounds/HonestHarness-R1/PLAN.md`, in your worktree; your parcel is under
§6, "Wave 1".

**P0, the lead's seam, is what you build on.** It is in your worktree, as
fixed after its verifier's three passes (`8108bb6`, `4c2456e`, `e8c99e5`)
and after P2's phase-1 finding (`929d6e5`, `lead.md` 12:55:45):
- `qs/suite.py`: the `Suite` interface and the `Runner`.
- `Context.chat`, the only way a suite reaches a model.
  - It meters every call as its reply arrives, and stops at the suite's
    `Caps` (`CapReached`) and before a peak window (`PeakReached`). Both
    are `RunStopped`.
  - It takes no `thinking` or `effort`: those are the batch's.
  - It clamps `max_tokens` to what is left of the run's output and to the
    provider's limit. A `length` finish at that clamp is the harness's cap,
    not the model's.
  - A reply that never arrives whole (`TransportError`, `IncompleteReply`)
    or a status the next request would meet too sets `ctx.stop_reason`.
    The runner stops the batch on it, even when a suite catches the
    exception.
- `qs/record.py`, with its schema: the run record.
- `qs/guard.py`: the spending guard.
- `qs/client.py` and `qs/keys.py`: the live gate.
- `qs/providers/deepseek.py`: the DeepSeek adapter.
- `qs/fake.py`: the local fake endpoint.
- `tools/check.py`: the gate, with its threat model stated in its docstring.

Read them before you design.

**What must not break:**
- **The seam is the lead's.** Never edit a file P0 made, and every file now in
  your worktree is P0's or older. That includes:
  - everything in `qs/`, `tools/`, `tests/` and `prices/`;
  - `registry.json`, `pyproject.toml`, `README.md`, `.gitignore` and
    `.gitattributes`;
  - everything in `Rounds/` and `Research/`.

  You add new files, and only the ones your brief lists as yours. Every other
  file is someone else's.
  - If your work seems to need a seam change, escalate. The lead makes it on
    `round1` and records it.
  - The same holds for a new Python dependency. The standard library, httpx
    and jsonschema are there already.
- **No paid call, ever.** Only the lead makes paid calls, through
  `tools/live.py`, after the merge.
  - Your code and tests reach models only through `qs/fake.py`, on
    127.0.0.1.
  - Never write `live=True`, in code or tests: the gate's livegate check
    fails on it.
  - Never name `DEEPSEEK_API_KEY` in a test.
  - Never read, print or copy the value of an environment variable you did
    not set yourself. A provider's key is in one.
- **The records must stay true.**
  - An item's id matches `^[A-Za-z0-9._-]+$`; the runner refuses any other.
  - An outcome's status is one the schema allows: pass, fail, error,
    stopped, refused or skipped.
  - A run a cap or budget stops is `stopped`, never a pass or a "found
    nothing".
  - A behaviour the provider documents is recorded as documented, never as a
    model failure.

## Places, and no absolute paths

Your dispatch message defines two roots:
- `<repos>`: the directory that holds HonestHarness, its worktrees and this
  ledger;
- `<scratch>`: the directory that holds your scratch directory.

This brief names places relative to them. **Never write an absolute path in
the ledger, a commit message or a committed file.** The repository is public,
a path names the owner's machine, and the gate's privacy check fails on one.
Write `<repos>/...` or `<scratch>/...` instead.

**DeepSeek's docs** are copied as plain text in `<scratch>/ds/`. It is the
one scratch directory besides your own that you may read. The plan cites them
as `[D1]` to `[D20]`, and its Sources section maps each to its page. Cite
them in the ledger as `ds/<file>:<line>`.

## Start here

1. **The plan of record**, all of it, then your parcel under §6's "Wave 1".
2. **P0's code**, and the gate's docstring with its threat model and stated
   limits.
3. **The research behind your parcel**, as your brief names it.

## The ledger

`<repos>/honestharness-r1-ledger/`. Read its README now: it is the round's
rules. In short:
- one file per author, named in your brief, append only;
- stamps from `date`, never typed;
- read the whole directory:
  - before you start;
  - before you design anything that touches a shared file;
  - before your report;
- mark what you measured and what you believe;
- nothing secret or personal in any file, because the ledger will be
  published.

**Escalation.** Write it in your file first. Then message the lead
(`SendMessage` to `main`) and wait. If `SendMessage` isn't loaded, load it
with the ToolSearch tool, query `select:SendMessage`.

**A resume note at each step.** At the end of each numbered step below, write
a short entry headed "resume note":
- where you are;
- what is done and committed, and what is not;
- what comes next.

Agents are dropped by API failures and paused by the owner. Round 7 found
that work resumed from a brief and a resume note survives, and work held only
in context does not (CS7 L290-297).

**Values come from the code or a command, never from memory.** That covers
every constant, count, SHA and list in your ledger, your commit message and
your report. Round 7's case study proposes this for the lead's restatements,
which its checkers found wrong where they were not read from the code at the
moment of writing (CS7 L535-542, a proposal).

## Your two phases (design first)

**Phase 1: read, echo, test the channel, design, then stop.**
1. **Your intent echo**, as your first ledger entry. In your own words:
   - what your brief asks;
   - which files you own, and what you must not touch;
   - your negative controls;
   - what would count as failing.
2. **A test escalation.** Send the lead one message, `"<you>: channel test"`,
   and record in your file that you sent it. This is how the round shows its
   escalation channel works (S3). The lead records its receipt.
3. **Your design**, in your ledger file:
   - your files, and each one's job;
   - the interfaces you take from P0, and anything in P0 you would need
     changed;
   - your items or behaviours, and how each is checked;
   - your controls, and what each plants;
   - your caps, with the batch's worst case worked out from P0's
     `PriceTable.worst_case`.

   Also list anything your brief got wrong.
4. **Stop.** Your final message for phase 1 is the design. Write no code
   yet. The lead compares your echo and design with the brief, then resumes
   you with "go", or with corrections.

**Phase 2, on the lead's "go": build, check, commit, report.**
1. **Build**, in your files only.
2. **Run the gate** in your worktree: `python tools/check.py`. It must hold
   5 of 5, and `python tools/check.py --control` 9 of 9.
3. **Run your own controls.** Each one shows a check of yours failing on a
   planted fault, in tests or in a copy under your scratch directory, never
   in your worktree. Report their outputs.
4. **Commit on your own branch.** The message says what you did and ends with
   a `Co-Authored-By:` trailer, with `<noreply@anthropic.com>`. It names the
   model you actually run as, taken from your own system prompt, not from
   this brief: round 5 found dispatches and transcripts naming different
   models. Check `git show --stat HEAD` against your message before you
   believe it.
5. **Stop every background process of your own**, containers included,
   then report.

## READY

READY means every property of your work is either:
- **held by the gate or by your tests**, which the gate runs; or
- **stated as a limit**, by the behaviour it concedes, where a fault built to
  evade your checks lands inside that limit.

Your verifier works to that standard. It will be given a copy of your work
with faults planted in it. "Found nothing" is an acceptable answer for you
too: if something cannot be built truthfully, say so rather than forcing it.

**The send-back rule.** Only a regression or a wrong answer sends your work
back.
- A *wrong answer* is code that does not do what its brief or docstring
  says, or that can spend, leak or record wrongly.
- A *regression* is behaviour that worked and no longer does.
- Anything else is merged as a known limit, stated by the behaviour it
  concedes, or restated at the merge where a sentence claims more than is
  true.

So state your limits yourself, by behaviour, before your verifier has to.

## Do not

- Push, merge, rebase, or commit to `main` or `round1`. Commit only on your
  own branch; the lead merges.
- Touch P0's files or another parcel's.
- Make a paid call, or write anything that could.
- Send a heredoc with backslashes through Bash: they get mangled here. Write
  scripts and test data with your file-writing tool.
- Pull an image or install a package without its ledger entry first: its
  name, source and size. Logan cleared downloads from official, trusted
  sources, open source preferred (`lead.md`, 10:26:10).
- Start a container without running `docker ps` first. On this desktop, one
  run at a time (plan §8, B16).
- Remove, prune or change any Docker image, container, volume or network you
  did not create. Other projects' images are on this desktop, and their
  sessions may be running containers.
- Run a test, gate or script at normal priority while `lead.md` says the
  owner is using the desktop. That rule was set at 15:35:17, lifted at
  16:39:34, and may be set again. Under it, run each through `python
  <scratch>/shared/lowprio.py <command>`, one heavy process at a time, with no
  worker pools, and expect slow runs.

## Report (phase 2)

- What you built: each file and its job.
- Each item or behaviour, and what holds it.
- The gate's output, and your controls' outputs: the actual lines.
- **Anything you found that this brief got wrong.**
- Any boundary you crossed, and why. A crossing you disclose and reason is
  fine; a silent one is not.
- Confirmation that your background processes and containers are stopped.
