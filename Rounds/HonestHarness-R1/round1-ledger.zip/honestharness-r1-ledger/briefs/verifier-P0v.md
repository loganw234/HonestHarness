# verifier-P0v: run records name their code, a scoped check

Read `_verifier.md` first. Everything there applies, except its planted-copy
section: this check is on the lead's real commit, and plants nothing.

**The work:** one commit of the lead's, `b79217a` on `round1`, on top of
`0af47f7`. It makes run records version 2, each naming:
- the commit its batch ran from;
- whether the checkout differed from it outside `records/`;
- a digest of the tools the run's requests sent.

Clone `round1` into your scratch and work there. Check the commit with
`git diff 0af47f7..b79217a`.

**Why it exists** (`lead.md` 12:41:38 and 12:48:48; harness note 43): no field
of any record moved when the lead changed `read_file`'s description at
db94d41. Qwen's swap test needs to tell a change Qwen needed from a change
made between runs.

## Your list

1. **The identity.** Does `code_identity` report HEAD's commit, and flag
   exactly the changes its docstring says, in each of these states:
   - a tracked change, staged and unstaged;
   - an untracked file;
   - a change under `records/`;
   - a detached HEAD;
   - a clone at another path;
   - no checkout?

   Does it write nothing in `.git`, and take no lock?
2. **The schema.** Does every record line already in the lead's checkout
   (`<repos>/honestharness-worktrees/P0/records/`, read-only to you) still
   validate? Does a version 2 record without `code` fail? Does the gate's
   schema check read both versions?
3. **The digest.** Is it of the tools as the request sent them, so that a
   change to a tool's description, as at db94d41, changes it? Is it stable
   across key order and repeated calls?
4. **The runner.** Does every run record of a batch carry the same commit
   and flag, and the summary too, on every path: a stop, an error, a
   refusal, a batch of no runs?
5. **Readers.** Does anything that reads records break on version 2 or the
   new field: `tools/table.py`, QS4's and QS6's tables, the gate's checks?
6. **The claims.** Does the docstring, or the commit message, claim more
   than is true?

**Not yours:**
- amendment 1, which verifier-A1 checks;
- QS4's live lanes, which run from clones at 86235a7 and never see this
  commit.

**Your budget:** one pass.

Your ledger file is `verifier-P0v.md`. Your scratch directory is
`<scratch>/r1-vP0v/`.
