# verifier-P0: the lead's seam

Read `_verifier.md` first. Everything there applies.

**The work:** P0, one commit, on branch `round1` of HonestHarness. Your
dispatch message names its SHA. Clone it into your scratch directory:
`git clone -q <repos>/honestharness-worktrees/P0 <scratch>/r1-vP0/clone`.
Then check out the commit detached. Never write in the worktree.

**What P0 is for:** every parcel builds on it, and the lead's live runs spend
money through it. The plan's §6, "P0", lists what it must hold.

## Your list

1. **The live gate.** Can any path make a paid call (a POST to a non-local
   host) without live mode and a guard reservation? Check:
   - the read-only reservation;
   - when the key is read;
   - that no key can reach a record, a transcript, an error message or a log.
2. **The guard.**
   - Can a batch spend more than it reserved, or more than the ceiling's
     remainder or the balance?
   - Check each run's worst case: the caps, `max_call_prompt_tokens`, and
     the client-side token estimate. The plan's §7 rests on it.
   - Check the reconciliation classes and tolerances, and the spend file.
3. **The DeepSeek adapter against DeepSeek's own docs.** The research agent's
   plain-text copies are in `<scratch>/ds/` (cite them as `ds/<file>:line`).
   Check against them:
   - the thinking field and effort;
   - reasoning passed back with tools;
   - the documented 400s;
   - the usage fields and finish reasons;
   - stream parsing (keep-alive lines, usage on the last chunk);
   - the balance (D18) and model-list (D17) formats.

   Where the docs leave a point open, the code says so, and P0's first live
   calls are to settle it. Check that each such point is marked.
4. **The run record** against the plan's §6 list. Does every field the plan
   names exist, and does the schema refuse a bad record?
5. **The runner:**
   - the peak refusal;
   - the probe;
   - a stop when the guard refuses mid-batch;
   - the caps;
   - error paths: a 400, a 402 or a dropped connection, during the probe or
     a run;
   - that every batch reconciles, or says why it did not.
6. **The gate.** Is its threat model true of its code? Can each check fail?
   Is each stated limit stated by behaviour?
7. **The fake.** Does it behave like the documented API wherever the tests
   lean on it?
8. **Privacy** of the commit, its message and the ledger.
9. **Anything else.**

## The cap on this loop

The owner's standing practice since ParcelRound's round 6 (CS6 obs 1-2):
once a pass's findings are mostly outside the threat model, the loop ends.
After that, a defect inside the model gets a scoped re-check of its fix
only.

Your ledger file is `verifier-P0.md`. Your scratch directory is
`<scratch>/r1-vP0/`, which exists and is empty.
